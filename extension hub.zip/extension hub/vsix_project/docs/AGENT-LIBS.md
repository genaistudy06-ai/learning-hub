# Agent Libraries — Documentation

## Overview

This extension ships with two categories of agent packs:

| Category | Namespace | Description |
|---|---|---|
| **SDLC Core** | `@sdlc-agents` | Software Development Lifecycle agents (all roles from PM to DevOps) |
| **Agent Libs** | `@abpy`, `@ang2react`, `@java2py`, `@tez2spark` | Specialized migration pipeline libraries |

Agent Libs are **completely separate namespaces**. They do not appear in the Copilot chat dropdown. You invoke them directly in chat using `@namespace.agentId`.

---

## Available Agent Libraries

### 1. ABPY — Ab Initio → PySpark Conversion (`@abpy`)

**License bit:** 5 (sixth entry in `f1a2` array)
**Bin file:** `f6b1.bin`
**Purpose:** Converts enterprise Ab Initio applications to production-grade PySpark — covering graphs, DML, KSH orchestration, memory management, partition strategy, join semantics, error handling, and full reconciliation.

#### Agents

| Agent | Invoke As | Role |
|---|---|---|
| Ab Initio Graph Analyzer | `@abpy.abpy-analyzer` | Entry point — 12-phase deep graph analysis |
| Schema & Config Converter | `@abpy.abpy-schema` | DML layouts → PySpark StructType + YAML config |
| PySpark Converter | `@abpy.abpy-converter` | Graph components → PySpark job code |
| Orchestration Agent | `@abpy.abpy-orchestration` | KSH scripts → Databricks Workflow / Airflow DAG |
| Validator | `@abpy.abpy-validator` | Reconciliation test suite |
| Performance & Security | `@abpy.abpy-perf-security` | Production hardening |
| Conversion Sign-off | `@abpy.abpy-signoff` | Final 20-item gate (terminal agent) |

#### Pipeline Order
```
@abpy.abpy-analyzer  →  @abpy.abpy-schema  →  @abpy.abpy-converter  (parallel: @abpy.abpy-orchestration)
  →  @abpy.abpy-validator  →  @abpy.abpy-perf-security  →  @abpy.abpy-signoff
```

#### Quick Start
```
@abpy.abpy-analyzer

Analyze the attached Ab Initio application. Do NOT write PySpark code.

[Attach: .mp graph files, .dml layout files, .ksh scripts, .mp param files]

Business context:
- Source system : Oracle / DB2 / Flat Files
- Target        : Databricks / EMR / on-prem Spark
- Data volume   : [rows and GB per run]
- SLA           : [minutes]

Run all 12 phases. Produce the complete HANDOFF BLOCK.
```

---

### 2. Angular → React Migration (`@ang2react`)

**License bit:** 6 (seventh entry in `f1a2` array)
**Bin file:** `g7c2.bin`
**Purpose:** Module-by-module Angular→React migration in NX monorepos using the Strangler Fig pattern. React modules coexist with Angular until migration is complete.

#### Agents

| Agent | Invoke As | Role |
|---|---|---|
| Migration Orchestrator | `@ang2react.migrate-orchestrator` | **Entry point** — drives all other agents |
| Scaffold | `@ang2react.migrate-scaffold` | One-time React project setup (run once) |
| Auditor | `@ang2react.migrate-auditor` | Pre-migration analysis per module |
| Coder | `@ang2react.migrate-coder` | Angular → React translation engine |
| Tester | `@ang2react.migrate-tester` | Vitest/Jest tests to 100% coverage |
| Reviewer | `@ang2react.migrate-reviewer` | 8-gate quality review + PR description |

#### Pipeline Order
```
@ang2react.migrate-orchestrator  (routes to all others automatically)
  → First time: @ang2react.migrate-scaffold (once)
  → Each module: auditor → coder → tester → reviewer
```

#### Quick Start
```
@ang2react.migrate-orchestrator

First time:
  scaffold

Each module:
  migrate [module-name]

Check status:
  status
```

---

### 3. Java → Python Migration (`@java2py`)

**License bit:** 7 (eighth entry in `f1a2` array)
**Bin file:** `h8d3.bin`
**Purpose:** Migrates Java codebases (Maven/Gradle) to Python. 10-phase pipeline with two approval gates. Preserves all business logic. Generates pytest tests, mypy-clean type annotations, and a comprehensive final report.

#### Agents

| Agent | Invoke As | Role |
|---|---|---|
| Pipeline Master | `@java2py.j2py-master` | **Entry point** — drives all 10 phases inline |
| Auditor | `@java2py.j2py-auditor` | Phase 0: codebase audit (standalone: audit only) |
| Java Parser | `@java2py.j2py-parser` | Phase 1: deep class structure extraction |
| Dependency Mapper | `@java2py.j2py-dep-mapper` | Phase 2: Maven/Gradle → PyPI mapping |
| Go/No-Go Reporter | `@java2py.j2py-gonogo` | Phase 3: feasibility score + **GATE 1** |
| Type Strategy Planner | `@java2py.j2py-type-planner` | Phase 4: Python typing strategy |
| Conversion Executor | `@java2py.j2py-converter` | Phase 5: Java → Python code |
| Test Generator | `@java2py.j2py-test-gen` | Phase 6: pytest suite (90%+ coverage) |
| Validator | `@java2py.j2py-validator` | Phase 7: pytest + mypy execution |
| Reviewer | `@java2py.j2py-reviewer` | Phase 8: code review + **GATE 2** |
| Final Reporter | `@java2py.j2py-reporter` | Phase 9: migration report (terminal) |

#### Quick Start
```
@java2py.j2py-master migrate src/main/java

# The master agent drives phases 0-2, then stops at GATE 1 for your approval.
# After "yes" → phases 3-8, then stops at GATE 2.
# After "yes" → phase 9 final report.
```

---

### 4. Tez → Spark Migration (`@tez2spark`)

**License bit:** 8 (ninth entry in `f1a2` array)
**Bin file:** `i9e4.bin`
**Purpose:** Migrates Apache Tez DAG applications to Apache Spark. 13-phase pipeline with two approval gates. Java business logic is never altered — only wrapped or invoked. Produces performance baseline comparison, data contract validation, and cutover/rollback plan.

#### Agents

| Agent | Invoke As | Role |
|---|---|---|
| Pipeline Master | `@tez2spark.tez-master` | **Entry point** — drives all 13 phases |
| Repository Auditor | `@tez2spark.tez-auditor` | Phase 0: Tez repository archaeology |
| Pre-Benchmark | `@tez2spark.tez-pre-benchmark` | Phase 1: Tez performance baseline |
| Report Agent | `@tez2spark.tez-report` | Phase 2 & 12: reports + approval gates |
| Config Translator | `@tez2spark.tez-config` | Phase 3: Tez → Spark config mapping |
| Java Interop | `@tez2spark.tez-interop` | Phase 4: Java class callability plan |
| Topology Mapper | `@tez2spark.tez-conversion` | Phase 5: DAG → Spark stage mapping |
| Baseline-Aware Tuner | `@tez2spark.tez-optimization` | Phase 6: performance tuning |
| Structural Validator | `@tez2spark.tez-plan-diff` | Phase 7: plan diff vs original topology |
| Execution Agent | `@tez2spark.tez-execution` | Phase 8: run or dry-run |
| Data Contract Validator | `@tez2spark.tez-data-contract` | Phase 9: correctness validation |
| Benchmark Comparator | `@tez2spark.tez-benchmark` | Phase 10: Tez vs Spark performance |
| Cutover Authority | `@tez2spark.tez-review` | Phase 11: cutover + rollback plan + **GATE 2** |

#### Quick Start
```
@tez2spark.tez-master

# Master auto-generates a Run ID and drives phases 0-2.
# After GATE 1: reply "GO [run-id]"
# After GATE 2: reply "FINALIZE [run-id]"

# Resume an interrupted run:
@tez2spark.tez-master Run ID: TEZ2SPK-20260424-1430-ABCD
```

---

## License System

### How License Bits Work

Each agent pack is controlled by a bit in the license's feature bitmask. The bit index corresponds to the pack's position in `product.config.json → f1a2` array (0-based).

```
Bit 0 → core        (SDLC core agents)
Bit 1 → engineering (SDLC engineering agents)
Bit 2 → governance  (SDLC governance agents)
Bit 3 → data        (SDLC data agents)
Bit 4 → migration   (SDLC migration agents)
Bit 5 → abpy        (@abpy — Ab Initio→PySpark)
Bit 6 → ang2react   (@ang2react — Angular→React)
Bit 7 → java2py     (@java2py — Java→Python)
Bit 8 → tez2spark   (@tez2spark — Tez→Spark)
Bit 14 → selfLearning
Bit 15 → customStandards
```

### Enabling Individual Libraries

To enable one or more agent libs on a single machine, generate a license code with the desired bits set.

#### Examples

**Enable only ABPY on a machine:**
```bash
cd tools
node license-gen.js --machineId <machineId> --days 365 --packs abpy
```

**Enable Angular→React and Java→Python together:**
```bash
node license-gen.js --machineId <machineId> --days 365 --packs ang2react,java2py
```

**Enable all agent libs (no SDLC core):**
```bash
node license-gen.js --machineId <machineId> --days 365 --packs abpy,ang2react,java2py,tez2spark
```

**Full license — everything including SDLC core:**
```bash
node license-gen.js --machineId <machineId> --days 365 --packs core,engineering,governance,data,migration,abpy,ang2react,java2py,tez2spark --self-learning --custom-standards
```

### How to Get Your Machine ID

In VS Code:
1. Open Command Palette (`Ctrl+Shift+P`)
2. Run: **SDLC Agents: Show Machine ID**

Or in the extension activation panel — the machine ID is displayed when activation is required.

### Enabling Multiple Libraries on the Same System

You can enable any combination of agent libs with a single license code. There is no conflict between namespaces:

```
@abpy.abpy-analyzer      → Ab Initio work
@ang2react.migrate-coder → Angular migration work  
@java2py.j2py-master     → Java migration work
@tez2spark.tez-master    → Tez migration work
```

All four can be active simultaneously on one machine. Each is licensed independently by its bit.

### License Code Format

```
SDLC-[machineHash]-[expiryBase36]-[featureBitsBase36]-[signature]
```

The `featureBitsBase36` encodes which packs are enabled. Example:
- Bits 5+6 set (abpy + ang2react): `0b01100000` = 96 decimal = `2o` in base36
- Bits 5+6+7+8 set (all 4 libs): `0b111100000` = 480 decimal = `dc` in base36

---

## Building the .bin Files

After updating agent content, rebuild the encrypted bin for each lib:

```bash
cd tools

# ABPY
node dat-encoder.js \
  --input  ../agent-libs/abpy/agents.md \
  --pack-id abpy \
  --output ../extension/dat/f6b1.bin \
  --instructions ../agent-libs/abpy/instructions.md \
  --namespace abpy

# Angular → React
node dat-encoder.js \
  --input  ../agent-libs/ang2react/agents.md \
  --pack-id ang2react \
  --output ../extension/dat/g7c2.bin \
  --instructions ../agent-libs/ang2react/instructions.md \
  --namespace ang2react

# Java → Python
node dat-encoder.js \
  --input  ../agent-libs/java2py/agents.md \
  --pack-id java2py \
  --output ../extension/dat/h8d3.bin \
  --instructions ../agent-libs/java2py/instructions.md \
  --namespace java2py

# Tez → Spark
node dat-encoder.js \
  --input  ../agent-libs/tez2spark/agents.md \
  --pack-id tez2spark \
  --output ../extension/dat/i9e4.bin \
  --instructions ../agent-libs/tez2spark/instructions.md \
  --namespace tez2spark
```

Then build the VSIX:
```bash
cd extension
npm run build
```

---

## Agent Lib File Structure

```
agent-libs/
├── abpy/
│   ├── agents.md        ← All 7 agents compiled (source of truth)
│   └── instructions.md  ← Pack-level global instructions (injected into every session)
├── ang2react/
│   ├── agents.md        ← All 6 agents compiled
│   └── instructions.md  ← Angular migration instructions + incremental migration guide
├── java2py/
│   ├── agents.md        ← All 11 agents compiled
│   └── instructions.md  ← Java→Python pipeline rules
└── tez2spark/
    ├── agents.md        ← All 13 agents compiled
    └── instructions.md  ← Tez→Spark pipeline rules
```

To update an agent: edit the corresponding `agents.md` file, rebuild the bin, rebuild VSIX.

---

## Architecture Notes

### Why Separate Namespaces?

The SDLC core uses `@sdlc-agents.agentId`. Agent libs each get their own namespace (`@abpy`, `@ang2react`, `@java2py`, `@tez2spark`) because:

1. **Separation of concerns** — migration pipelines are entirely separate products from the SDLC agents
2. **Independent licensing** — each lib is licensed separately; a user may have only `@abpy` without any SDLC core packs
3. **No dropdown pollution** — agents don't appear in the Copilot chat dropdown; they are accessed directly via `@namespace.agentId` in chat

### How Namespace Resolution Works

In `agentManager.ts`, the namespace is resolved per-pack:
- If `pack.namespace` is set → use it (e.g. `abpy` → `@abpy.agentId`)
- Otherwise → fall back to `this.cfg.productId` (e.g. `sdlc-agents` → `@sdlc-agents.agentId`)

The namespace is set in two places (both are supported, runtime config wins):
1. **In the `.bin` file** — via `--namespace` flag at encode time
2. **In `product.config.json` `p4` field** — injected by `licenseManager.ts` at runtime (overrides bin value)

### Handoff System

All agent libs use a **HANDOFF BLOCK** pattern — a structured block that each agent produces and the next agent reads. This is the only shared state between agents (agents have no memory between sessions). The user copies and pastes the HANDOFF BLOCK at the top of the next prompt.

```
╔══════════════════════════════════════════════════════════════╗
║  HANDOFF BLOCK — [from-agent] → [to-agent]                  ║
╚══════════════════════════════════════════════════════════════╝
[structured data]
STATUS: READY FOR [next-agent]
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `@abpy.abpy-analyzer` not found in chat | Check license has bit 5 set. Re-activate the extension. |
| Agent responds but doesn't follow pipeline | Paste the HANDOFF BLOCK from the previous agent at the top of your prompt |
| `BLOCKED — NO_TEZ_EVIDENCE` | The audit agent found no Tez files. Verify the repo path is correct. |
| Gate 1 approval not working | Reply with exactly `GO [run-id]` matching the run ID shown |
| Performance seems slow (Copilot model) | Use `/debate` sparingly — it uses 3× tokens |
| All 4 libs active but only ABPY working | Verify all 4 bin files exist in `extension/dat/` and are non-empty (> 1 byte) |
| License shows "feature not available" | The pack bit is not set in your license code. Generate a new license. |
