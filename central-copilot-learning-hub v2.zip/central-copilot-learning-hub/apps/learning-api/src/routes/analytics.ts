// ─── Analytics Routes (Phase 2) ───────────────────────────────────────────────
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { generateAnalyticsSnapshot, generateAllSkillsSnapshot } from '../services/analyticsService.js';

const SkillParam = z.enum(['angular','java','python','devops','sql','qa','general']);

export async function analyticsRoutes(app: FastifyInstance) {

  // GET /analytics — all skills snapshot
  app.get('/analytics', async (_req, reply) => {
    const snapshots = await generateAllSkillsSnapshot();
    return reply.send({ snapshots, generatedAt: new Date().toISOString() });
  });

  // GET /analytics/:skill — single skill snapshot
  app.get('/analytics/:skill', async (req, reply) => {
    const parsed = SkillParam.safeParse((req.params as any).skill);
    if (!parsed.success) return reply.status(400).send({ error: 'Invalid skill' });
    const snapshot = await generateAnalyticsSnapshot(parsed.data);
    return reply.send(snapshot);
  });
}
