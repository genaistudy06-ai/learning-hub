#!/usr/bin/env node
/**
 * SDLC Agents — License Code Generator v4
 * Code-only activation. No idx.bin. No binary file output.
 *
 * Code format:  PREFIX-MMMMMMMM-EEEEFFFF-SSSSSSSSSSSS
 *   PREFIX  = accessCodePrefix from product.config.json  (e.g. "SDLC")
 *   MMMMMMMM = first 8 hex of SHA256(machineId + buildSecretA)  — machine fingerprint
 *   EEEE    = expiry days-since-epoch, hex, 4 chars
 *   FFFF    = feature bitmask, hex, 4 chars (up to 16 packs + selfLearning + customStandards)
 *   SSSSSSSSSSSS = first 12 hex of HMAC-SHA256(sigKey, M+E+F) — tamper-proof signature
 *
 * Usage:
 *   Single:  node license-gen.js --machine-id <id> --expiry 2026-12-31 --packs core,engineering
 *   Bulk:    node license-gen.js --bulk team.csv --output codes.csv
 *
 * Feature flag bits (must match licenseManager.ts):
 *   Bit 0  = core pack
 *   Bit 1  = engineering pack
 *   Bit 2  = governance pack
 *   Bit 3  = data pack
 *   Bit 4  = migration pack
 *   Bit 14 = selfLearning
 *   Bit 15 = customStandards
 */

'use strict';

const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');

// ── Load product config (obfuscated keys) ─────────────────────────────────────
const configPath = path.resolve(__dirname, '..', 'extension', 'product.config.json');
const cfg        = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
const PREFIX     = cfg.e7f8;
const PACKS      = cfg.f1a2; // array of { p1: packId, p2: file, p3: featureFlag }

// ── Build secrets (must match licenseManager.ts) ──────────────────────────────
// After running init-config.js, set BUILD_SECRET_A in environment:
//   set BUILD_SECRET_A=your_secret_value  (Windows)
//   export BUILD_SECRET_A=your_secret_value  (Mac/Linux)
const BUILD_SECRET_A = process.env.BUILD_SECRET_A;
if (!BUILD_SECRET_A) {
  console.error('ERROR: BUILD_SECRET_A environment variable not set.');
  console.error('Run: export BUILD_SECRET_A=<value from init-config.js>');
  process.exit(1);
}

// buildSecretB fragments — replace after running init-config.js
const _f1 = Buffer.from('706172744131', 'hex').toString(); // ← REPLACE
const _f2 = Buffer.from('706172744132', 'hex').toString(); // ← REPLACE
const _f3 = Buffer.from('706172744133', 'hex').toString(); // ← REPLACE
const _f4 = Buffer.from('706172744134', 'hex').toString(); // ← REPLACE
const BUILD_SECRET_B = _f1 + _f2 + _f3 + _f4;

// Derived keys (must mirror licenseManager.ts constructor)
const SIG_KEY = crypto
  .createHash('sha256')
  .update('sig' + BUILD_SECRET_A + BUILD_SECRET_B)
  .digest();

// ── Feature bit positions ─────────────────────────────────────────────────────
const PACK_BIT_MAP = {};
PACKS.forEach((pack, idx) => { PACK_BIT_MAP[pack.p1] = idx; });
const SELF_LEARNING_BIT    = 14;
const CUSTOM_STANDARDS_BIT = 15;

// ── Core generation function ──────────────────────────────────────────────────
function generateCode(machineId, expiryDate, packIds, selfLearning = false, customStandards = false) {
  // 1. Machine fingerprint — first 8 hex of SHA256(machineId + buildSecretA)
  const machineHash = crypto
    .createHash('sha256')
    .update(machineId + BUILD_SECRET_A)
    .digest('hex')
    .slice(0, 8)
    .toUpperCase();

  // 2. Expiry — days since epoch, hex 4 chars
  const expiryDays = Math.floor(new Date(expiryDate).getTime() / (24 * 60 * 60 * 1000));
  const expiryHex  = expiryDays.toString(16).toUpperCase().padStart(4, '0');
  if (expiryHex.length > 4) {
    throw new Error(`Expiry date too far in the future (hex overflow). Max ~year 2074.`);
  }

  // 3. Feature bitmask
  let bits = 0;
  for (const packId of packIds) {
    const bit = PACK_BIT_MAP[packId];
    if (bit === undefined) throw new Error(`Unknown pack ID: "${packId}". Known packs: ${Object.keys(PACK_BIT_MAP).join(', ')}`);
    bits |= (1 << bit);
  }
  if (selfLearning)    bits |= (1 << SELF_LEARNING_BIT);
  if (customStandards) bits |= (1 << CUSTOM_STANDARDS_BIT);
  const featureHex = bits.toString(16).toUpperCase().padStart(4, '0');

  // 4. HMAC signature — first 12 hex of HMAC-SHA256(sigKey, M+E+F)
  const payload   = machineHash + expiryHex + featureHex;
  const signature = crypto
    .createHmac('sha256', SIG_KEY)
    .update(payload)
    .digest('hex')
    .slice(0, 12)
    .toUpperCase();

  return `${PREFIX}-${machineHash}-${expiryHex}${featureHex}-${signature}`;
}

// ── Verify a code (sanity check) ──────────────────────────────────────────────
function verifyCode(code, machineId) {
  const upper   = code.toUpperCase().trim();
  const pattern = new RegExp(`^${PREFIX}-([A-F0-9]{8})-([A-F0-9]{4})([A-F0-9]{4})-([A-F0-9]{12})$`);
  const match   = upper.match(pattern);
  if (!match) return { valid: false, reason: 'Format invalid' };

  const [, machineHash, expiryHex, featureHex, signature] = match;

  // Verify HMAC
  const payload      = machineHash + expiryHex + featureHex;
  const expectedSig  = crypto
    .createHmac('sha256', SIG_KEY)
    .update(payload)
    .digest('hex')
    .slice(0, 12)
    .toUpperCase();

  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
    return { valid: false, reason: 'Signature mismatch — tampered or wrong build secrets' };
  }

  // Verify machine
  if (machineId) {
    const expectedMachine = crypto
      .createHash('sha256')
      .update(machineId + BUILD_SECRET_A)
      .digest('hex')
      .slice(0, 8)
      .toUpperCase();
    if (machineHash !== expectedMachine) {
      return { valid: false, reason: 'Machine ID mismatch' };
    }
  }

  // Decode
  const expiryDays   = parseInt(expiryHex, 16);
  const expiresAt    = new Date(expiryDays * 24 * 60 * 60 * 1000);
  const featureBits  = parseInt(featureHex, 16);
  const packs        = PACKS.filter((p, i) => featureBits & (1 << i)).map(p => p.p1);
  const selfLearning = !!(featureBits & (1 << SELF_LEARNING_BIT));
  const daysLeft     = Math.floor((expiresAt - Date.now()) / 86_400_000);

  return {
    valid:         true,
    machineHash,
    expiresAt:     expiresAt.toISOString().slice(0, 10),
    daysRemaining: daysLeft,
    packs,
    selfLearning,
    customStandards: !!(featureBits & (1 << CUSTOM_STANDARDS_BIT)),
  };
}

// ── Parse CLI arguments ───────────────────────────────────────────────────────
const args = process.argv.slice(2);
const arg  = (flag) => {
  const i = args.indexOf(flag);
  return i >= 0 ? args[i + 1] : undefined;
};
const hasFlag = (flag) => args.includes(flag);

// ── Single code generation ────────────────────────────────────────────────────
if (arg('--machine-id')) {
  const machineId      = arg('--machine-id');
  const expiry         = arg('--expiry') || (() => {
    // Default: 1 year from today
    const d = new Date(); d.setFullYear(d.getFullYear() + 1);
    return d.toISOString().slice(0, 10);
  })();
  const packsArg       = arg('--packs') || 'core';
  const packIds        = packsArg.split(/[,+]/).map(s => s.trim()).filter(Boolean);
  const selfLearning   = hasFlag('--self-learning');
  const customStds     = hasFlag('--custom-standards');
  const verifyMachineId = arg('--verify-machine') || undefined;

  try {
    const code   = generateCode(machineId, expiry, packIds, selfLearning, customStds);
    const verify = verifyCode(code, verifyMachineId || machineId);

    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('  SDLC Agents — License Code');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`  Code:           ${code}`);
    console.log(`  Machine ID:     ${machineId}`);
    console.log(`  Expires:        ${expiry}`);
    console.log(`  Packs:          ${packIds.join(', ')}`);
    console.log(`  Self-Learning:  ${selfLearning}`);
    console.log(`  Verification:   ${verify.valid ? 'PASS ✓' : 'FAIL — ' + verify.reason}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  } catch (err) {
    console.error('ERROR:', err.message);
    process.exit(1);
  }
  process.exit(0);
}

// ── Bulk code generation from CSV ─────────────────────────────────────────────
if (arg('--bulk')) {
  const inputFile  = arg('--bulk');
  const outputFile = arg('--output') || 'codes.csv';

  if (!fs.existsSync(inputFile)) {
    console.error(`ERROR: Input file not found: ${inputFile}`);
    process.exit(1);
  }

  const lines  = fs.readFileSync(inputFile, 'utf-8').split('\n').map(l => l.trim()).filter(Boolean);
  const header = lines[0].toLowerCase().split(',').map(h => h.trim());

  const col = (name) => header.indexOf(name);
  const required = ['name', 'machineid', 'expiry', 'packs'];
  for (const r of required) {
    if (col(r) < 0) {
      console.error(`ERROR: Missing required column "${r}" in CSV header.`);
      console.error(`Required columns: ${required.join(', ')}`);
      console.error(`Optional columns: selflearning, customstandards`);
      process.exit(1);
    }
  }

  const results = ['name,machineId,expiry,packs,code,verification'];
  let success = 0, failed = 0;

  for (let i = 1; i < lines.length; i++) {
    const cells          = lines[i].split(',').map(s => s.trim());
    const name           = cells[col('name')];
    const machineId      = cells[col('machineid')];
    const expiry         = cells[col('expiry')];
    const packsArg       = cells[col('packs')] || 'core';
    const packIds        = packsArg.split(/[+]/).map(s => s.trim()).filter(Boolean);
    const selfLearning   = col('selflearning') >= 0
      ? cells[col('selflearning')].toLowerCase() === 'true'
      : false;
    const customStds     = col('customstandards') >= 0
      ? cells[col('customstandards')].toLowerCase() === 'true'
      : false;

    if (!machineId || !expiry) {
      results.push(`${name},${machineId},${expiry},${packsArg},ERROR_MISSING_FIELDS,FAIL`);
      failed++;
      continue;
    }

    try {
      const code   = generateCode(machineId, expiry, packIds, selfLearning, customStds);
      const verify = verifyCode(code, machineId);
      results.push(`${name},${machineId},${expiry},${packsArg},${code},${verify.valid ? 'OK' : 'FAIL'}`);
      console.log(`  ✓  ${name.padEnd(25)} → ${code}`);
      success++;
    } catch (err) {
      results.push(`${name},${machineId},${expiry},${packsArg},ERROR: ${err.message},FAIL`);
      console.error(`  ✗  ${name.padEnd(25)} → ERROR: ${err.message}`);
      failed++;
    }
  }

  fs.writeFileSync(outputFile, results.join('\n'), 'utf-8');
  console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`  Generated: ${success} codes   Errors: ${failed}`);
  console.log(`  Output:    ${outputFile}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
  process.exit(failed > 0 ? 1 : 0);
}

// ── Verify a code ─────────────────────────────────────────────────────────────
if (arg('--verify')) {
  const code      = arg('--verify');
  const machineId = arg('--machine-id');
  const result    = verifyCode(code, machineId);

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`  Verification: ${result.valid ? 'PASS ✓' : 'FAIL ✗ — ' + result.reason}`);
  if (result.valid) {
    console.log(`  Expires:        ${result.expiresAt}  (${result.daysRemaining} days remaining)`);
    console.log(`  Packs:          ${result.packs.join(', ')}`);
    console.log(`  Self-Learning:  ${result.selfLearning}`);
  }
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  process.exit(result.valid ? 0 : 1);
}

// ── Help ──────────────────────────────────────────────────────────────────────
console.log(`
SDLC Agents — License Code Generator

Single code:
  node license-gen.js \\
    --machine-id <vscode.env.machineId> \\
    --expiry 2026-12-31 \\
    --packs core,engineering,data \\
    [--self-learning] \\
    [--custom-standards]

Bulk from CSV:
  node license-gen.js --bulk team.csv --output codes.csv

  CSV format (header required):
    name,machineId,expiry,packs[,selfLearning][,customStandards]

  Example:
    Alice Chen,a3f9c2b1...,2026-12-31,core+engineering+data,true
    Bob Patel,7d2e4a8f...,2026-12-31,core,false

Verify a code:
  node license-gen.js --verify SDLC-XXXXXXXX-XXXXXXXX-XXXXXXXXXXXX [--machine-id <id>]

Available packs:
  ${PACKS.map(p => p.p1).join(', ')}

Environment required:
  BUILD_SECRET_A — from tools/init-config.js output
`);
