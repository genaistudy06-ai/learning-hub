## Weekly Productivity Stats

Each Monday, export your agent usage stats for the v2 tracker:

**Ctrl+Shift+P → SDLC Agents: Show Weekly Stats**

The panel shows:
- Invocation counts per agent — mapped to tracker columns V–AF
- A **Copy tracker-ready values** button for one-click paste
- Additional stats (model tier, debate sessions, learning counts) below the separator

Reset the counter after copying: **Ctrl+Shift+P → SDLC Agents: Reset Weekly Stats**
