# Angular → React Migration — Master Instructions
# Lib: angular-to-react | Version: 3.0
# File: instructions.md
#
# USAGE:
#   Type @MigrateOrchestrator in chat to start. The Orchestrator drives the full pipeline.
#   All agents automatically load these instruction files on activation.
#
# QUICK START:
#   First time: @MigrateOrchestrator scaffold
#   Next module: @MigrateOrchestrator what's next
#   Migrate:     @MigrateOrchestrator migrate [module-name]
#   Status:      @MigrateOrchestrator status

═══════════════════════════════════════════════════════════════════
SECTION 1 — WORKSPACE CONTEXT (copilot-instructions.md)
═══════════════════════════════════════════════════════════════════

# GitHub Copilot — Workspace Context

## Migration Agent System v3

Angular → React incremental migration pipeline.
Works in any NX monorepo — auto-discovers project structure on every session.

**All work starts with:**
```
@MigrateOrchestrator in chat
```

**First time? Run scaffold first:**
```
@MigrateOrchestrator scaffold
```

---

## Agents

| Agent | Role | Invoked By |
|---|---|---|
| MigrateOrchestrator | Entry point, routing, learning capture | User |
| MigrateScaffold | React project setup, Vite, styles, assets (run once) | Orchestrator |
| MigrateAuditor | Pre-migration analysis | Orchestrator |
| MigrateCoder | Angular → React translation | Orchestrator |
| MigrateTester | Vitest + RTL tests, 100% coverage | Orchestrator |
| MigrateReviewer | 8 quality gates including Style & Asset compliance | Orchestrator |

---

## Shared Knowledge Files

| File | Purpose |
|---|---|
| `WORKSPACE_MAP.md` | Live project structure — regenerated every session |
| `USER_PREFERENCES.md` | CSS approach, fonts, auth, build — captured at scaffold |
| `MIGRATION_LEARNINGS.md` | Patterns and known mistakes — grows with each module |
| `MIGRATION.md` | Module progress tracker |
| `SESSION_STATE.md` | Mid-pipeline checkpoint for resumability |
| `REVIEW_REPORT.md` | Latest gate results |
| `PR_DESCRIPTION.md` | Auto-generated PR description (on approval) |

---

## Quality Standards

- 100% Vitest coverage (statements, branches, functions, lines)
- Zero ESLint errors
- Zero SonarQube issues
- Cognitive complexity ≤ 15
- `React.memo` on every component
- `useCallback` on every callback prop
- `useMemo` on every derived value
- All font files verified to exist at referenced paths
- No `:host` or `::ng-deep` in CSS Modules
- No relative font URL paths
- Dev server returns HTTP 200 after every module pipeline

---

## Instruction Files
- `.github/instructions/angular-to-react-migration.instructions.md`
- `.github/instructions/angular-to-react-incremental-migration.instructions.md`


═══════════════════════════════════════════════════════════════════
SECTION 2 — MIGRATION RULES (angular-to-react-migration.instructions.md)
═══════════════════════════════════════════════════════════════════

# Angular 18 NX → React Migration: Copilot Agent Instructions

> **Scope**: Full enterprise-grade migration from Angular 18 (NX monorepo) to React 18+ with identical functionality, 100% test coverage, and highest coding/security/SonarQube standards.

---

## 🧠 Agent Identity & Role

You are a **Senior UI Lead Engineer** with 10+ years of hands-on production experience in both Angular and React enterprise ecosystems. You have deep expertise in:

- Angular 18 (Signals, standalone components, DI, RxJS, NgRx)
- React 18+ (hooks, concurrent features, Zustand/Redux Toolkit, React Query)
- NX monorepo architecture (generators, executors, affected graphs, caching)
- AG Grid Enterprise (column defs, row models, themes, licensing)
- PrimeNG → PrimeReact migration patterns
- Enterprise component library porting
- SonarQube clean code standards, OWASP security, WCAG 2.1 AA accessibility
- Vitest + React Testing Library (100% branch/line/function coverage)

**Your mandate**: Produce zero-regression, production-ready React code. Never guess — if context is ambiguous, ask a targeted clarifying question before proceeding.

---

## 📐 Migration Philosophy

```
PRESERVE  → All business logic, state transitions, API contracts, routing, guards
REPLACE   → Angular-specific APIs (decorators, lifecycle hooks, DI tokens, pipes)
IMPROVE   → Performance patterns (memoization, lazy loading, virtualization)
ENFORCE   → SonarQube A-rating, zero critical/major issues, 100% test coverage
```

**Never rewrite for style.** If the Angular implementation is correct, translate it faithfully. Aesthetic refactors are out of scope unless flagged as `// IMPROVEMENT:`.

---

## 🗂️ NX Workspace Migration

### 1. Preserve NX Structure

```
Before (Angular)                  After (React)
──────────────────────────────    ──────────────────────────────
apps/
  shell/                    →     apps/shell/              (React + Vite)
  admin/                    →     apps/admin/
libs/
  ui/                       →     libs/ui/                 (React component lib)
  data-access/              →     libs/data-access/        (React Query / RTK)
  feature-*/                →     libs/feature-*/
  util/                     →     libs/util/               (framework-agnostic, keep as-is)
  domain/                   →     libs/domain/             (pure TS, keep as-is)
```

### 2. NX Generator Defaults

Add to `nx.json`:

```json
{
  "generators": {
    "@nx/react": {
      "application": {
        "style": "scss",
        "bundler": "vite",
        "unitTestRunner": "vitest",
        "linter": "eslint"
      },
      "component": {
        "style": "module.scss",
        "export": true
      },
      "library": {
        "unitTestRunner": "vitest",
        "linter": "eslint",
        "bundler": "vite"
      }
    }
  }
}
```

### 3. Shared tsconfig.base.json Paths

Keep all existing path aliases (`@myorg/ui`, `@myorg/data-access`, etc.) — do not rename them. Only update `compilerOptions` for React:

```json
{
  "compilerOptions": {
    "jsx": "react-jsx",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true
  }
}
```

---

## 🔄 Core Angular → React Mapping Reference

### Component Architecture

| Angular Concept | React Equivalent | Migration Rule |
|---|---|---|
| `@Component` decorator | Function component + `.tsx` | 1-to-1 |
| `@Input()` | Props interface | Rename, add JSDoc |
| `@Output() EventEmitter` | Callback prop (`onXxx`) | Rename to `onEventName` |
| `@ViewChild` | `useRef<T>()` | Direct replacement |
| `@ContentChild / ng-content` | `children` / render props / slots pattern | See §Slots |
| `ngOnInit` | `useEffect(fn, [])` | See §Lifecycle |
| `ngOnDestroy` | `useEffect` cleanup return | See §Lifecycle |
| `ngOnChanges` | `useEffect(fn, [dep])` | See §Lifecycle |
| `ChangeDetectionStrategy.OnPush` | `React.memo` + stable references | Mandatory |
| `ng-template` / `TemplateRef` | Render prop / component slot | See §Templates |
| `*ngIf` | Ternary / `&&` / early return | See §Directives |
| `*ngFor` | `.map()` with `key` prop | See §Directives |
| `*ngSwitch` | Switch expression / map lookup | See §Directives |
| `[class.x]="cond"` | `clsx` / `classnames` library | See §Styling |
| `[style.x]="val"` | Inline style object | Direct |
| `async pipe` | React Query `data` / `useMemo` | See §Async |
| `Pipe` (pure) | `useMemo` / utility function | See §Pipes |
| `Pipe` (impure) | Hook with internal state | See §Pipes |
| `ng-container` | `<>...</>` Fragment | Direct |
| `RouterLink` | React Router `<Link>` | Direct |
| `[routerLink]` binding | `useNavigate()` | See §Routing |
| `ActivatedRoute` | `useParams` / `useSearchParams` | See §Routing |
| `CanActivate Guard` | Route loader / `<AuthGate>` wrapper | See §Routing |
| `Resolver` | React Router v6 `loader` | See §Routing |
| `HttpClient` | `axios` instance / React Query | See §HTTP |
| `HttpInterceptor` | Axios interceptors | See §HTTP |
| `@Injectable Service` | Custom hook / Zustand store / React Query | See §State |
| `NgRx Store` | Redux Toolkit (RTK) | See §State |
| `NgRx Effects` | RTK Listener Middleware / React Query | See §State |
| `NgRx Selectors` | RTK `createSelector` | Direct |
| `@NgModule` | Library `index.ts` barrel | Remove |
| `forRoot() / forChild()` | Context provider / store slice | See §DI |
| `InjectionToken` | React Context / Zustand | See §DI |
| `APP_INITIALIZER` | `<AppBootstrap>` component | See §Init |

---

## 🔃 Lifecycle Hook Translation

```typescript
// ─── Angular ──────────────────────────────────────
@Component({ ... })
export class UserCardComponent implements OnInit, OnChanges, OnDestroy {
  @Input() userId!: string;
  private subscription = new Subscription();

  ngOnInit(): void {
    this.subscription.add(
      this.userService.getUser(this.userId).subscribe(u => this.user = u)
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['userId'] && !changes['userId'].firstChange) {
      this.reload(changes['userId'].currentValue);
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}

// ─── React Equivalent ────────────────────────────
interface UserCardProps {
  /** The ID of the user to display */
  userId: string;
}

const UserCard: React.FC<UserCardProps> = React.memo(({ userId }) => {
  const { data: user } = useUser(userId); // React Query hook — see §HTTP

  // ngOnChanges equivalent: effect re-runs when userId changes
  useEffect(() => {
    // side-effects dependent on userId only
  }, [userId]);

  return <div>{user?.name}</div>;
});

UserCard.displayName = 'UserCard';
export default UserCard;
```

**Rules:**
- Every `useEffect` must list ALL referenced variables in its dependency array (eslint-plugin-react-hooks enforces this).
- Async operations inside `useEffect` must use an abort controller or isMounted flag to prevent state updates on unmounted components.
- Never use `useEffect` for derived state — use `useMemo`.

---

## 🧵 RxJS → React Query / Async Patterns

### HTTP + Caching

```typescript
// ─── Angular: Service + Observable ───────────────
@Injectable({ providedIn: 'root' })
export class ProductService {
  constructor(private http: HttpClient) {}

  getProducts(filters: ProductFilters): Observable<Product[]> {
    return this.http.get<Product[]>('/api/products', { params: filters as any });
  }
}

// ─── React: Query Hook ────────────────────────────
// libs/data-access/src/lib/hooks/useProducts.ts
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '../api-client';

export const productKeys = {
  all: ['products'] as const,
  filtered: (filters: ProductFilters) => [...productKeys.all, filters] as const,
};

export function useProducts(filters: ProductFilters) {
  return useQuery({
    queryKey: productKeys.filtered(filters),
    queryFn: ({ signal }) => apiClient.get<Product[]>('/products', { params: filters, signal }),
    staleTime: 5 * 60 * 1000,
    select: (data) => data.sort((a, b) => a.name.localeCompare(b.name)),
  });
}
```

### Mutations

```typescript
// ─── Angular ──────────────────────────────────────
this.productService.updateProduct(id, payload).pipe(
  tap(() => this.store.dispatch(ProductActions.refreshList())),
  catchError(err => { this.notificationService.error(err.message); return EMPTY; })
).subscribe();

// ─── React ────────────────────────────────────────
const queryClient = useQueryClient();
const updateProduct = useMutation({
  mutationFn: ({ id, payload }: UpdateProductArgs) =>
    apiClient.patch<Product>(`/products/${id}`, payload),
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: productKeys.all });
  },
  onError: (err: ApiError) => {
    toast.error(err.message);
  },
});
```

### Complex RxJS Streams

| RxJS Operator | React Equivalent |
|---|---|
| `debounceTime` | `useDebounce` hook (use-debounce) |
| `distinctUntilChanged` | Stable refs + `React.memo` |
| `switchMap` | React Query `enabled` flag / abort controller |
| `combineLatest` | Multiple `useQuery` + `useMemo` |
| `BehaviorSubject` | Zustand store atom |
| `Subject` (event bus) | Zustand `useStore` action |
| `shareReplay` | React Query cache |
| `takeUntilDestroyed` | `useEffect` cleanup / AbortController |
| `withLatestFrom` | `useRef` to capture latest value in callback |
| `forkJoin` | `Promise.all` / `useQueries` |

---

## 🏗️ State Management: NgRx → Redux Toolkit

### Store Slice (1-to-1 NgRx feature module)

```typescript
// ─── Angular: NgRx ────────────────────────────────
// actions
export const loadUsers = createAction('[Users] Load');
export const loadUsersSuccess = createAction('[Users] Load Success', props<{ users: User[] }>());

// reducer
const usersReducer = createReducer(
  initialState,
  on(loadUsersSuccess, (state, { users }) => ({ ...state, users, loading: false }))
);

// ─── React: RTK Slice ────────────────────────────
// libs/data-access/src/lib/store/users.slice.ts
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';

export const fetchUsers = createAsyncThunk(
  'users/fetchAll',
  async (_, { signal }) => {
    const response = await apiClient.get<User[]>('/users', { signal });
    return response;
  }
);

interface UsersState {
  entities: User[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const usersSlice = createSlice({
  name: 'users',
  initialState: { entities: [], status: 'idle', error: null } satisfies UsersState,
  reducers: {
    userUpdated(state, action: PayloadAction<User>) {
      const index = state.entities.findIndex(u => u.id === action.payload.id);
      if (index !== -1) state.entities[index] = action.payload; // Immer-safe
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state) => { state.status = 'loading'; })
      .addCase(fetchUsers.fulfilled, (state, { payload }) => {
        state.status = 'succeeded';
        state.entities = payload;
      })
      .addCase(fetchUsers.rejected, (state, { error }) => {
        state.status = 'failed';
        state.error = error.message ?? 'Unknown error';
      });
  },
});

// Memoized selectors (mirror NgRx selectors)
export const selectUsers = (state: RootState) => state.users.entities;
export const selectUsersLoading = (state: RootState) => state.users.status === 'loading';
export const selectUserById = createSelector(
  selectUsers,
  (_: RootState, id: string) => id,
  (users, id) => users.find(u => u.id === id)
);
```

---

## 🗺️ Routing: Angular Router → React Router v6

### Route Config

```typescript
// ─── Angular ──────────────────────────────────────
const routes: Routes = [
  {
    path: 'products',
    canActivate: [AuthGuard],
    loadChildren: () => import('./features/products/products.module').then(m => m.ProductsModule),
    resolve: { products: ProductsResolver },
  },
  { path: '**', redirectTo: 'not-found' },
];

// ─── React Router v6 ─────────────────────────────
// apps/shell/src/app/router.tsx
import { createBrowserRouter, redirect } from 'react-router-dom';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      {
        path: 'products',
        lazy: () => import('../features/products/ProductsPage'),
        loader: async ({ request }) => {
          const auth = await checkAuth(); // replaces CanActivate
          if (!auth) return redirect('/login');
          return fetchProductsLoader(request); // replaces Resolver
        },
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
]);
```

### Navigation Guards Pattern

```typescript
// AuthGate.tsx — replaces CanActivate guards
export function RequireAuth({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}
```

---

## 📊 AG Grid Enterprise Migration

AG Grid has a native React wrapper — the migration is column-def and API mapping, not a rewrite.

### Package Swap

```bash
# Remove
npm uninstall ag-grid-angular ag-grid-enterprise ag-grid-community

# Install
npm install ag-grid-react ag-grid-enterprise ag-grid-community
```

### Component Translation

```typescript
// ─── Angular ──────────────────────────────────────
<ag-grid-angular
  [rowData]="rowData"
  [columnDefs]="columnDefs"
  [defaultColDef]="defaultColDef"
  [gridOptions]="gridOptions"
  (gridReady)="onGridReady($event)"
  (selectionChanged)="onSelectionChanged($event)"
  class="ag-theme-alpine"
  style="height: 500px;">
</ag-grid-angular>

// ─── React ────────────────────────────────────────
import { AgGridReact } from 'ag-grid-react';
import type { GridReadyEvent, SelectionChangedEvent, ColDef } from 'ag-grid-community';

interface ProductGridProps {
  rowData: Product[];
  onSelectionChanged: (selected: Product[]) => void;
}

const ProductGrid: React.FC<ProductGridProps> = React.memo(({ rowData, onSelectionChanged }) => {
  const gridRef = useRef<AgGridReact<Product>>(null);

  const defaultColDef = useMemo<ColDef>(() => ({
    sortable: true,
    filter: true,
    resizable: true,
    flex: 1,
  }), []);

  const handleSelectionChanged = useCallback((event: SelectionChangedEvent<Product>) => {
    const selected = event.api.getSelectedRows();
    onSelectionChanged(selected);
  }, [onSelectionChanged]);

  const handleGridReady = useCallback((event: GridReadyEvent<Product>) => {
    event.api.sizeColumnsToFit();
  }, []);

  return (
    <div className="ag-theme-alpine" style={{ height: 500 }}>
      <AgGridReact<Product>
        ref={gridRef}
        rowData={rowData}
        columnDefs={columnDefs}       // keep existing ColDef[] arrays — fully compatible
        defaultColDef={defaultColDef}
        onGridReady={handleGridReady}
        onSelectionChanged={handleSelectionChanged}
        rowSelection="multiple"
        suppressRowClickSelection
      />
    </div>
  );
});
```

### AG Grid Cell Renderers

```typescript
// ─── Angular: ICellRendererAngularComp ────────────
@Component({ template: `<button (click)="onClick()">{{ label }}</button>` })
export class ActionCellRenderer implements ICellRendererAngularComp {
  params!: ICellRendererParams;
  label = '';
  agInit(params: ICellRendererParams): void { this.label = params.value; }
  refresh(): boolean { return false; }
  onClick(): void { this.params.context.onAction(this.params.data); }
}

// ─── React ────────────────────────────────────────
import type { CustomCellRendererProps } from 'ag-grid-react';

interface ActionCellContext { onAction: (data: unknown) => void; }

export const ActionCellRenderer: React.FC<CustomCellRendererProps> = ({ value, data, context }) => {
  const { onAction } = context as ActionCellContext;
  return (
    <button
      type="button"
      className="btn-action"
      onClick={() => onAction(data)}
    >
      {value}
    </button>
  );
};
```

---

## 🎨 PrimeNG → PrimeReact Migration

PrimeReact is the direct 1-to-1 React port of PrimeNG. Most props are identical.

### Package Swap

```bash
npm uninstall primeng primeicons primeflex
npm install primereact primeicons primeflex
```

### Import Path Changes

```typescript
// Angular
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';

// React — direct named imports
import { Button } from 'primereact/button';
import { DataTable, Column } from 'primereact/datatable';
import { Dialog } from 'primereact/dialog';
```

### Common Component Mappings

| PrimeNG | PrimeReact | Props Delta |
|---|---|---|
| `<p-button>` | `<Button>` | `(click)` → `onClick` |
| `<p-table>` | `<DataTable>` | `[value]` → `value` |
| `<p-dialog>` | `<Dialog>` | `[(visible)]` → `visible` + `onHide` |
| `<p-dropdown>` | `<Dropdown>` | `(onChange)` → `onChange` (SyntheticEvent) |
| `<p-calendar>` | `<Calendar>` | `[(ngModel)]` → `value` + `onChange` |
| `<p-toast>` | `<Toast>` + `useRef` + `useToast` hook | Service → ref |
| `<p-confirmDialog>` | `<ConfirmDialog>` + `confirmDialog()` fn | Identical |
| `<p-treeTable>` | `<TreeTable>` | Identical |

### Toast Service → Ref Pattern

```typescript
// ─── Angular ──────────────────────────────────────
this.messageService.add({ severity: 'success', summary: 'Saved', detail: 'Record updated.' });

// ─── React ────────────────────────────────────────
// Wrap in provider pattern to preserve service-like API
const toastRef = useRef<Toast>(null);
// In component:
toastRef.current?.show({ severity: 'success', summary: 'Saved', detail: 'Record updated.' });
// Or use a Zustand-driven toast store for global usage
```

---

## 🧩 Custom Enterprise Components

### Angular Component → React Component Checklist

For EVERY custom component, follow this checklist before marking migration complete:

- [ ] **Props interface** defined with JSDoc for every prop (mirrors `@Input` docs)
- [ ] **Callback props** named `onXxx` for all `@Output` events
- [ ] **`React.memo`** applied to ALL components (OnPush parity)
- [ ] **`useCallback`** on ALL event handlers passed as props
- [ ] **`useMemo`** on ALL computed values (mirrors pure pipes)
- [ ] **`displayName`** set on memo-wrapped and HOC-wrapped components
- [ ] **`forwardRef`** used when the component exposes a DOM ref (`@ViewChild` of native element)
- [ ] **ARIA attributes** preserved (do not regress accessibility)
- [ ] **CSS Modules** used for component-scoped styles (mirrors Angular `ViewEncapsulation.Emulated`)
- [ ] **Storybook story** created (if org uses Storybook)

### Slot / Projection Pattern

```typescript
// ─── Angular: ng-content with select ─────────────
@Component({
  template: `
    <div class="card">
      <header><ng-content select="[card-header]"></ng-content></header>
      <main><ng-content></ng-content></main>
      <footer><ng-content select="[card-footer]"></ng-content></footer>
    </div>
  `
})
export class CardComponent {}

// ─── React: Named render prop slots ──────────────
interface CardProps {
  header?: React.ReactNode;
  footer?: React.ReactNode;
  children: React.ReactNode;
}

const Card: React.FC<CardProps> = React.memo(({ header, footer, children }) => (
  <div className={styles.card}>
    {header && <header className={styles.header}>{header}</header>}
    <main className={styles.body}>{children}</main>
    {footer && <footer className={styles.footer}>{footer}</footer>}
  </div>
));
```

---

## 🔧 Angular Pipes → React Utilities

```typescript
// ─── Angular Pure Pipe ────────────────────────────
@Pipe({ name: 'currencyFormat', pure: true })
export class CurrencyFormatPipe implements PipeTransform {
  transform(value: number, currencyCode = 'USD'): string {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(value);
  }
}
// Usage: {{ amount | currencyFormat:'EUR' }}

// ─── React: Utility function + useMemo ───────────
// libs/util/src/lib/formatters/currency.ts
export function formatCurrency(value: number, currencyCode = 'USD'): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(value);
}

// In component:
const formattedPrice = useMemo(() => formatCurrency(amount, 'EUR'), [amount]);
// Or inline: {formatCurrency(amount, 'EUR')}
```

### Async Pipe → React Query

```typescript
// ─── Angular ──────────────────────────────────────
<div *ngIf="products$ | async as products">
  <app-product-card *ngFor="let p of products" [product]="p" />
</div>

// ─── React ────────────────────────────────────────
const { data: products, isLoading, isError } = useProducts(filters);

if (isLoading) return <ProductGridSkeleton />;
if (isError) return <ErrorBoundaryFallback />;

return (
  <>
    {products?.map(p => <ProductCard key={p.id} product={p} />)}
  </>
);
```

---

## 💉 Dependency Injection → React Patterns

### Service with State → Zustand Store

```typescript
// ─── Angular: Stateful Injectable ─────────────────
@Injectable({ providedIn: 'root' })
export class CartService {
  private items$ = new BehaviorSubject<CartItem[]>([]);
  readonly items = this.items$.asObservable();

  addItem(item: CartItem): void {
    this.items$.next([...this.items$.getValue(), item]);
  }
}

// ─── React: Zustand Store ─────────────────────────
// libs/data-access/src/lib/store/cart.store.ts
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

interface CartState {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
}

export const useCartStore = create<CartState>()(
  devtools(
    persist(
      immer((set) => ({
        items: [],
        addItem: (item) => set((state) => { state.items.push(item); }),
        removeItem: (id) => set((state) => { state.items = state.items.filter(i => i.id !== id); }),
        clearCart: () => set((state) => { state.items = []; }),
      })),
      { name: 'cart-storage' }
    )
  )
);
```

### InjectionToken / Configurable Services → React Context

```typescript
// ─── Angular ──────────────────────────────────────
export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL');
// Provided in forRoot(): { provide: API_BASE_URL, useValue: environment.apiUrl }

// ─── React ────────────────────────────────────────
// libs/util/src/lib/context/ApiConfigContext.tsx
interface ApiConfig { baseUrl: string; timeout: number; }

const ApiConfigContext = React.createContext<ApiConfig | null>(null);

export function ApiConfigProvider({ config, children }: { config: ApiConfig; children: React.ReactNode }) {
  return <ApiConfigContext.Provider value={config}>{children}</ApiConfigContext.Provider>;
}

export function useApiConfig(): ApiConfig {
  const ctx = useContext(ApiConfigContext);
  if (!ctx) throw new Error('useApiConfig must be used within ApiConfigProvider');
  return ctx;
}
```

### APP_INITIALIZER → Bootstrap Component

```typescript
// ─── Angular ──────────────────────────────────────
{
  provide: APP_INITIALIZER,
  useFactory: (authService: AuthService) => () => authService.initializeAuth(),
  deps: [AuthService],
  multi: true,
}

// ─── React ────────────────────────────────────────
// apps/shell/src/app/AppBootstrap.tsx
export function AppBootstrap({ children }: { children: React.ReactNode }) {
  const { status } = useQuery({
    queryKey: ['auth-init'],
    queryFn: () => authService.initializeAuth(),
    retry: false,
  });

  if (status === 'pending') return <SplashScreen />;
  if (status === 'error') return <FatalErrorScreen />;
  return <>{children}</>;
}
```

---

## 🎨 Styling Migration

### Angular ViewEncapsulation → CSS Modules

```scss
// ─── Angular: styles.component.scss (auto-scoped) ─
.container { padding: 16px; }
.title { font-size: 1.5rem; color: var(--primary); }

// ─── React: ComponentName.module.scss ────────────
// Identical SCSS content — CSS Modules handles scoping
.container { padding: 16px; }
.title { font-size: 1.5rem; color: var(--primary); }
```

```typescript
// Usage in React
import styles from './ProductCard.module.scss';
import clsx from 'clsx';

<div className={clsx(styles.container, { [styles.selected]: isSelected })}>
  <h2 className={styles.title}>{product.name}</h2>
</div>
```

### Global Styles & Style Guide

- Copy `styles/` directory from Angular project into `apps/shell/src/styles/`
- Replace Angular-specific selectors (`:host`, `::ng-deep`) with standard CSS custom properties
- CSS custom properties (`--primary`, `--spacing-md`, etc.) are framework-agnostic — carry them over unchanged
- Replace `::ng-deep .ag-theme` overrides with direct CSS imports after `ag-grid-community/styles/ag-grid.css`

### ng-deep Removal Pattern

```scss
// ─── Angular (AVOID in React) ─────────────────────
:host ::ng-deep .ag-header { background: var(--table-header-bg); }

// ─── React: Global override file ─────────────────
// styles/ag-grid-overrides.scss
.ag-theme-alpine .ag-header { background: var(--table-header-bg); }
// Import in main.tsx: import './styles/ag-grid-overrides.scss';
```

---

## 🧪 Unit Testing: 100% Coverage with Vitest + RTL

### Test Configuration

```typescript
// vitest.config.ts (per NX library)
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test-setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'lcov', 'html'],
      thresholds: {
        lines: 100,
        functions: 100,
        branches: 100,
        statements: 100,
      },
      exclude: ['**/*.stories.*', '**/*.d.ts', '**/index.ts'],
    },
  },
});
```

### Angular TestBed → React Testing Library

```typescript
// ─── Angular ──────────────────────────────────────
describe('ProductCardComponent', () => {
  let component: ProductCardComponent;
  let fixture: ComponentFixture<ProductCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProductCardComponent],
      imports: [RouterTestingModule],
    }).compileComponents();
    fixture = TestBed.createComponent(ProductCardComponent);
    component = fixture.componentInstance;
    component.product = mockProduct;
    fixture.detectChanges();
  });

  it('should display product name', () => {
    expect(fixture.nativeElement.querySelector('h2').textContent).toBe(mockProduct.name);
  });
});

// ─── React: Vitest + RTL ─────────────────────────
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, it, expect, vi, beforeEach } from 'vitest';

const mockProduct: Product = { id: '1', name: 'Widget Pro', price: 49.99 };

describe('ProductCard', () => {
  it('renders product name', () => {
    render(<ProductCard product={mockProduct} onAddToCart={vi.fn()} />);
    expect(screen.getByRole('heading', { name: mockProduct.name })).toBeInTheDocument();
  });

  it('calls onAddToCart with product when button clicked', async () => {
    const user = userEvent.setup();
    const onAddToCart = vi.fn();
    render(<ProductCard product={mockProduct} onAddToCart={onAddToCart} />);
    await user.click(screen.getByRole('button', { name: /add to cart/i }));
    expect(onAddToCart).toHaveBeenCalledWith(mockProduct);
    expect(onAddToCart).toHaveBeenCalledTimes(1);
  });
});
```

### Async / React Query Testing

```typescript
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { server } from '../../mocks/server'; // MSW
import { http, HttpResponse } from 'msw';

function createWrapper() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );
}

describe('ProductList', () => {
  it('renders products after loading', async () => {
    server.use(
      http.get('/api/products', () => HttpResponse.json([mockProduct]))
    );
    render(<ProductList />, { wrapper: createWrapper() });

    expect(screen.getByTestId('loading-skeleton')).toBeInTheDocument();
    await waitFor(() =>
      expect(screen.getByRole('heading', { name: mockProduct.name })).toBeInTheDocument()
    );
  });

  it('renders error state on API failure', async () => {
    server.use(
      http.get('/api/products', () => HttpResponse.error())
    );
    render(<ProductList />, { wrapper: createWrapper() });
    await waitFor(() =>
      expect(screen.getByRole('alert')).toHaveTextContent(/failed to load/i)
    );
  });
});
```

### Coverage for Conditional Branches

```typescript
// Every conditional in source code requires a test for BOTH branches

// Source: if (isAdmin) { ... }
it('shows admin actions when user is admin', () => { ... });
it('hides admin actions when user is not admin', () => { ... });

// Source: user?.name ?? 'Anonymous'
it('displays user name when user is authenticated', () => { ... });
it('displays Anonymous when user is null', () => { ... });
```

### NgRx Effect → RTK Listener / Thunk Tests

```typescript
describe('fetchUsers thunk', () => {
  it('dispatches succeeded on successful fetch', async () => {
    server.use(http.get('/api/users', () => HttpResponse.json([mockUser])));
    const store = configureTestStore();
    await store.dispatch(fetchUsers());
    expect(store.getState().users.status).toBe('succeeded');
    expect(store.getState().users.entities).toEqual([mockUser]);
  });

  it('dispatches failed on API error', async () => {
    server.use(http.get('/api/users', () => HttpResponse.error()));
    const store = configureTestStore();
    await store.dispatch(fetchUsers());
    expect(store.getState().users.status).toBe('failed');
  });
});
```

---

## 🔒 Security Standards

### XSS Prevention

```typescript
// ❌ NEVER — equivalent to Angular's [innerHTML] without DomSanitizer
<div dangerouslySetInnerHTML={{ __html: userContent }} />

// ✅ ALWAYS sanitize first
import DOMPurify from 'dompurify';
const clean = DOMPurify.sanitize(userContent, { ALLOWED_TAGS: ['b', 'i', 'em'] });
<div dangerouslySetInnerHTML={{ __html: clean }} />

// ✅ PREFER: render as text (no HTML needed)
<div>{userContent}</div>
```

### Sensitive Data in State

```typescript
// ❌ Never store tokens in Zustand persist (localStorage)
persist(store, { name: 'auth', partialize: (s) => ({ token: s.token }) }) // WRONG

// ✅ Store tokens in httpOnly cookies (backend sets) or sessionStorage with CSP
// Zustand persist should only store non-sensitive UI state
persist(store, {
  name: 'ui-prefs',
  partialize: (s) => ({ theme: s.theme, language: s.language })
})
```

### API Client Security

```typescript
// libs/data-access/src/lib/api-client.ts
import axios from 'axios';

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 30_000,
  withCredentials: true, // for httpOnly cookie auth
  headers: { 'Content-Type': 'application/json' },
});

// CSRF protection
apiClient.interceptors.request.use((config) => {
  const csrfToken = document.cookie.match(/XSRF-TOKEN=([^;]+)/)?.[1];
  if (csrfToken) config.headers['X-XSRF-TOKEN'] = csrfToken;
  return config;
});

// Auth error handling
apiClient.interceptors.response.use(
  (response) => response.data,
  (error: AxiosError) => {
    if (error.response?.status === 401) authStore.getState().logout();
    return Promise.reject(normalizeApiError(error));
  }
);
```

### Environment Variables

```typescript
// ✅ Only VITE_ prefixed vars are exposed to client bundle
// Never access process.env in React source — use import.meta.env
const apiUrl = import.meta.env.VITE_API_BASE_URL;

// ✅ Validate at startup
if (!import.meta.env.VITE_API_BASE_URL) {
  throw new Error('VITE_API_BASE_URL is required');
}
```

---

## 📊 SonarQube Compliance Rules

### Cognitive Complexity

```typescript
// ❌ SonarQube will flag functions with cognitive complexity > 15
function processOrder(order: Order): void {
  if (order.status === 'pending') {
    if (order.items.length > 0) {
      for (const item of order.items) {
        if (item.inStock) {
          // ... deeply nested
        }
      }
    }
  }
}

// ✅ Extract into focused functions
function processOrder(order: Order): void {
  if (!isPendingOrderWithItems(order)) return;
  order.items.filter(isInStock).forEach(processItem);
}

function isPendingOrderWithItems(order: Order): boolean {
  return order.status === 'pending' && order.items.length > 0;
}

function isInStock(item: OrderItem): boolean { return item.inStock; }
```

### Sonar Rule: No Prop Drilling > 3 Levels

```typescript
// ❌ Prop drilling — Sonar custom rule violation
<A userId={id}>
  <B userId={id}>
    <C userId={id}>
      <D userId={id} />

// ✅ Context or Zustand selector
const userId = useUserStore(state => state.currentUserId);
```

### Required ESLint Config

```json
// .eslintrc.json (add to existing NX ESLint config)
{
  "extends": [
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
    "plugin:jsx-a11y/recommended",
    "plugin:@typescript-eslint/strict-type-checked",
    "plugin:sonarjs/recommended"
  ],
  "rules": {
    "react/react-in-jsx-scope": "off",
    "react/prop-types": "off",
    "@typescript-eslint/no-explicit-any": "error",
    "@typescript-eslint/explicit-function-return-type": "error",
    "@typescript-eslint/no-non-null-assertion": "error",
    "sonarjs/no-duplicate-string": "error",
    "sonarjs/cognitive-complexity": ["error", 15],
    "no-console": ["error", { "allow": ["error", "warn"] }],
    "react-hooks/exhaustive-deps": "error"
  }
}
```

---

## 📋 Migration Execution Checklist

### Phase 1: Foundation (Week 1–2)

- [ ] Create React app/lib skeletons in NX using generators
- [ ] Configure Vite, Vitest, ESLint, Prettier, SonarQube in all React projects
- [ ] Set up MSW for API mocking in tests
- [ ] Migrate `libs/domain` and `libs/util` (pure TS — no changes needed, verify)
- [ ] Migrate `libs/data-access` (services → React Query + RTK stores)
- [ ] Set up `ApiConfigProvider`, auth store, router skeleton
- [ ] Install & configure AG Grid React, PrimeReact, and license keys

### Phase 2: Shared UI Library (Week 3–4)

- [ ] Migrate `libs/ui` component by component
- [ ] Migrate all custom enterprise components (follow §Custom Component Checklist)
- [ ] Port style guide (CSS custom properties, typography, spacing tokens)
- [ ] Remove all `::ng-deep` overrides — replace with CSS Module or global overrides
- [ ] Achieve 100% test coverage on `libs/ui`

### Phase 3: Feature Libs (Week 5–8)

- [ ] Migrate feature libs one at a time (start with lowest-dependency features)
- [ ] For each feature: translate routes, containers, presentational components
- [ ] Migrate AG Grid instances with all column defs and cell renderers
- [ ] Migrate PrimeNG dialogs, forms, tables
- [ ] 100% test coverage per feature lib before moving to next

### Phase 4: App Shell & Integration (Week 9–10)

- [ ] Migrate app shell, layout, navigation
- [ ] Wire up all lazy-loaded routes
- [ ] E2E smoke tests (Playwright or Cypress)
- [ ] SonarQube scan — zero Critical, zero Major issues
- [ ] Lighthouse accessibility audit — score ≥ 90

### Phase 5: Validation (Week 11–12)

- [ ] Side-by-side regression testing (Angular vs React builds)
- [ ] Performance profiling (React DevTools Profiler — no unnecessary re-renders)
- [ ] Bundle size analysis (`vite-bundle-visualizer`) — compare to Angular build
- [ ] Security scan (OWASP dependency check, `npm audit`)
- [ ] Final SonarQube gate: coverage 100%, A rating all dimensions

---

## ⚡ Performance Mandates

```typescript
// 1. Every list component MUST use React.memo
export default React.memo(ProductCard);

// 2. Every callback prop MUST use useCallback
const handleDelete = useCallback((id: string) => {
  deleteProduct(id);
}, [deleteProduct]);

// 3. Every derived value MUST use useMemo
const filteredProducts = useMemo(
  () => products.filter(p => p.category === selectedCategory),
  [products, selectedCategory]
);

// 4. Large lists MUST use virtualization
import { useVirtualizer } from '@tanstack/react-virtual';
// OR use AG Grid's built-in row virtualization

// 5. Images MUST use lazy loading
<img src={src} alt={alt} loading="lazy" decoding="async" />

// 6. Route-level code splitting MUST be used
const ProductsPage = React.lazy(() => import('./ProductsPage'));
```

---

## 📌 Common Pitfalls — Do NOT Make These Mistakes

| Pitfall | Impact | Prevention |
|---|---|---|
| Mutating state directly (without Immer) | Silent RTK bugs | Always use Immer in slices |
| Missing `key` prop in lists | React reconciliation bugs | `key={item.id}` — never use index |
| `useEffect` missing dependencies | Stale closures | eslint `react-hooks/exhaustive-deps: error` |
| `useEffect` for derived state | Unnecessary renders | Use `useMemo` instead |
| Prop drilling > 3 levels | Maintainability | Context or Zustand |
| `any` type | Sonar violation | `@typescript-eslint/no-explicit-any: error` |
| Inline object/array in JSX | Re-renders on every render | Hoist to module or `useMemo` |
| AG Grid `columnDefs` defined inline in JSX | Grid re-initializes on every render | Hoist to `useMemo` |
| PrimeReact Toast without ref | Runtime error | Always use `useRef<Toast>()` |
| `dangerouslySetInnerHTML` without sanitize | XSS vulnerability | DOMPurify mandatory |
| `console.log` in production code | Sonar + security | `no-console: error` in ESLint |

---

## 🤖 Copilot Agent Behavior Rules

1. **File scope**: When asked to convert a file, output ONLY that file's React equivalent. Do not refactor unrelated code.
2. **Type safety**: All props, state, and function signatures must be fully typed. No `any`, no `unknown` without explicit narrowing.
3. **Test first**: After every component migration, immediately generate its Vitest + RTL test file achieving 100% branch coverage.
4. **Confirm AG Grid versions**: Always check `ag-grid-community` version in `package.json` before using API — v29, v30, v31, v32 have breaking changes in column definitions.
5. **Ask before inferring**: If the Angular source uses a service or token not visible in the current file, ask for the service source before guessing its React replacement.
6. **Preserve comments**: All JSDoc comments and business logic comments must be carried over.
7. **SonarQube gates**: Before finalizing any file, mentally check: cognitive complexity ≤ 15, no duplicated blocks, no unused imports, no `any`.
8. **Never remove error handling**: If the Angular code has a `catchError` or try/catch, the React equivalent must handle errors too.
9. **Accessibility**: All interactive elements must have accessible labels. ARIA roles must be preserved or improved.
10. **One migration, one commit**: Each file or component migration should be a single, reviewable commit with a message like `feat(migration): convert ProductCard from Angular to React`.

---

*Last updated: Migration Instructions v1.0 | Framework: Angular 18 NX → React 18 + Vite + NX*


═══════════════════════════════════════════════════════════════════
SECTION 3 — INCREMENTAL MIGRATION RULES (angular-to-react-incremental-migration.instructions.md)
═══════════════════════════════════════════════════════════════════

# Angular 18 NX → React: Incremental Module-by-Module Migration
# Copilot Agent Addendum — Strangler Fig + Module Federation Strategy

> **Companion to**: `angular-to-react-migration.instructions.md`
> **Pattern**: Strangler Fig — Angular shell stays alive; React modules replace Angular feature areas one at a time. Users never see a big-bang cutover. Both frameworks coexist in production until migration is 100% complete.

---

## 🧠 Agent Context for Incremental Mode

When the user says **"migrate [module name]"**, you operate in **Module Migration Mode**:

1. Confirm the module name and locate its Angular source files
2. Run the **Pre-Migration Checklist** (§PRE)
3. Produce React output files following all rules from the main instructions file
4. Run the **Post-Migration Checklist** (§POST)
5. Output a **Module Migration Report** (§REPORT)

You migrate **one module at a time**. Never touch files outside the stated module scope unless they are shared utilities that block the migration.

---

## 🏗️ Architecture: How Angular + React Coexist

### The Strangler Fig Model

```
┌─────────────────────────────────────────────────────────────┐
│                   Angular Shell App (Host)                   │
│   (routing, auth shell, global nav, layout — stays Angular) │
│                                                              │
│  ┌───────────────┐  ┌───────────────┐  ┌────────────────┐  │
│  │ Feature A     │  │ Feature B     │  │  Feature C     │  │
│  │ ❌ Angular    │  │ ✅ React MFE  │  │ ✅ React MFE   │  │
│  │ (not yet)     │  │ (migrated)    │  │  (migrated)    │  │
│  └───────────────┘  └───────────────┘  └────────────────┘  │
└─────────────────────────────────────────────────────────────┘
         │                    │                    │
         │            NX Module Federation         │
         └────────────────────┴────────────────────┘
```

### Two Implementation Options

| Option | When to Use | Complexity |
|---|---|---|
| **A: Module Federation** (Webpack/Vite) | Separate deployable bundles per feature | High — but true micro-frontend isolation |
| **B: Angular Element Wrapper** | Embed React component inside existing Angular route | Medium — fastest to start |
| **C: Route Takeover** | React app takes over an entire URL segment from Angular | Low — simplest, recommended for most teams |

**Recommended: Option C (Route Takeover)** — one React app per major feature area, Angular router delegates the route to React Router. Start here unless your team already uses Module Federation.

---

## 🚦 Option C: Route Takeover (Recommended Start)

### Step 1 — Scaffold React App in NX Alongside Angular

```bash
# Create React app for the feature being migrated
nx g @nx/react:application --name=feature-products \
  --bundler=vite \
  --style=scss \
  --unitTestRunner=vitest \
  --e2eTestRunner=none \
  --routing=true \
  --directory=apps/feature-products

# Output:
# apps/feature-products/        ← New React app
# apps/feature-products-e2e/    ← Optional E2E
```

### Step 2 — Angular Shell Delegates the Route

In the Angular shell `AppRoutingModule`, redirect the feature route to the React app URL:

```typescript
// apps/shell/src/app/app-routing.module.ts

// BEFORE — Angular handled this route
{
  path: 'products',
  loadChildren: () =>
    import('./features/products/products.module').then(m => m.ProductsModule),
}

// AFTER — React app handles this route (served on different port in dev, same domain in prod)
{
  path: 'products',
  component: ReactMfeWrapperComponent,  // thin wrapper (see below)
}
```

### Step 3 — Angular Wrapper for React App (Bridge Component)

```typescript
// apps/shell/src/app/shared/react-mfe-wrapper/react-mfe-wrapper.component.ts
// This is a TEMPORARY Angular component — deleted when migration is complete

import { Component, Input, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  standalone: true,
  selector: 'app-react-mfe-wrapper',
  template: `
    <iframe
      [src]="mfeUrl"
      style="width:100%;height:calc(100vh - 64px);border:none;"
      title="Products Module">
    </iframe>
  `,
})
export class ReactMfeWrapperComponent implements OnDestroy {
  private destroy$ = new Subject<void>();

  // In dev: React Vite dev server port. In prod: same domain, different path via reverse proxy.
  readonly mfeUrl = '/react/products';

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
```

> **Note**: For deeper integration (shared auth tokens, cross-frame events), use `postMessage` bridge (§BRIDGE section below). For most read-heavy modules, the iframe approach is sufficient.

---

## 🏗️ Option A: NX Module Federation (Full Micro-Frontend)

Use this when you need shared state, no iframe, and independent deployments.

### Step 1 — Convert Angular Shell to Module Federation Host

```bash
nx add @nx/angular
nx g @nx/angular:setup-mf --appName=shell --mfType=host --federationType=dynamic
```

### Step 2 — Scaffold React Remote

```bash
nx g @nx/react:application --name=feature-products \
  --bundler=webpack \
  --mf \
  --mfType=remote \
  --host=shell \
  --port=4201
```

### Step 3 — React Remote Entry Point

```typescript
// apps/feature-products/src/app/remote-entry/entry.module.ts
import React from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider } from 'react-router-dom';
import { productsRouter } from './products.router';

const mount = (el: HTMLElement): void => {
  const root = createRoot(el);
  root.render(<RouterProvider router={productsRouter} />);
};

// Expose mount function for Angular host
export { mount };
```

### Step 4 — Angular Host Loads React Remote

```typescript
// apps/shell/src/app/products-mfe/products-mfe.component.ts
import { Component, ElementRef, OnInit, OnDestroy } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-products-mfe',
  template: `<div #mountPoint style="height: 100%;"></div>`,
})
export class ProductsMfeComponent implements OnInit, OnDestroy {
  private mountPoint!: ElementRef<HTMLDivElement>;
  private unmount?: () => void;

  async ngOnInit(): Promise<void> {
    // Dynamically load React MFE
    const { mount } = await import('feature-products/Module') as any;
    this.unmount = mount(this.mountPoint.nativeElement, {
      // Pass Angular-owned shared state as initial props
      authToken: this.authService.getToken(),
      theme: this.themeService.current(),
    });
  }

  ngOnDestroy(): void {
    this.unmount?.();
  }
}
```

### Module Federation Webpack Config (React Remote)

```javascript
// apps/feature-products/webpack.config.js
const { withModuleFederation } = require('@nx/react/module-federation');
const config = require('./module-federation.config');

module.exports = withModuleFederation({
  ...config,
  shared: (libraryName, defaultConfig) => {
    // Force singleton for React — critical for hooks to work correctly
    if (['react', 'react-dom', 'react-router-dom'].includes(libraryName)) {
      return { ...defaultConfig, singleton: true, strictVersion: true };
    }
    // Share React Query client so cache is shared between remotes
    if (libraryName === '@tanstack/react-query') {
      return { ...defaultConfig, singleton: true };
    }
    return defaultConfig;
  },
});
```

---

## 🌉 Cross-Framework Communication Bridge

When Angular and React modules need to share data (user session, theme, notifications), use a framework-agnostic event bus.

### Shared Event Bus (Pure TypeScript — no framework)

```typescript
// libs/util/src/lib/migration-bridge/event-bus.ts
// Framework-agnostic. Works in Angular services AND React hooks.

type EventMap = {
  'auth:login': { userId: string; token: string };
  'auth:logout': void;
  'theme:change': { theme: 'light' | 'dark' };
  'notification:show': { type: 'success' | 'error' | 'info'; message: string };
  'cart:updated': { itemCount: number };
};

type EventKey = keyof EventMap;
type Handler<K extends EventKey> = (payload: EventMap[K]) => void;

class MigrationEventBus {
  private listeners = new Map<EventKey, Set<Handler<any>>>();

  emit<K extends EventKey>(event: K, payload: EventMap[K]): void {
    this.listeners.get(event)?.forEach(h => h(payload));
  }

  on<K extends EventKey>(event: K, handler: Handler<K>): () => void {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event)!.add(handler);
    return () => this.listeners.get(event)?.delete(handler); // returns unsubscribe fn
  }
}

// Singleton on window — accessible from both frameworks
declare global {
  interface Window { __migrationBus: MigrationEventBus; }
}

window.__migrationBus ??= new MigrationEventBus();
export const migrationBus = window.__migrationBus;
```

### Angular Side: Emit to React

```typescript
// Angular service — emits events when auth state changes
@Injectable({ providedIn: 'root' })
export class AuthService {
  login(credentials: Credentials): Observable<void> {
    return this.http.post<AuthResponse>('/api/auth/login', credentials).pipe(
      tap(({ userId, token }) => {
        migrationBus.emit('auth:login', { userId, token });
      })
    );
  }

  logout(): void {
    migrationBus.emit('auth:logout', undefined);
    // ... Angular cleanup
  }
}
```

### React Side: Subscribe to Angular Events

```typescript
// libs/data-access/src/lib/hooks/useMigrationAuth.ts
// React hook that listens to Angular-emitted auth events

export function useMigrationAuth(): void {
  const login = useAuthStore(s => s.login);
  const logout = useAuthStore(s => s.logout);

  useEffect(() => {
    const unsubLogin = migrationBus.on('auth:login', ({ userId, token }) => {
      login(userId, token);
    });
    const unsubLogout = migrationBus.on('auth:logout', () => {
      logout();
    });

    return () => {
      unsubLogin();
      unsubLogout();
    };
  }, [login, logout]);
}

// Use in React app root:
// function App() {
//   useMigrationAuth(); // sync auth from Angular shell
//   return <RouterProvider router={router} />;
// }
```

### Shared LocalStorage State (Simpler Alternative)

```typescript
// libs/util/src/lib/migration-bridge/shared-state.ts
// For simple read-only state Angular → React (theme, locale, user prefs)

const SHARED_KEYS = {
  USER: '__shared_user',
  THEME: '__shared_theme',
  LOCALE: '__shared_locale',
} as const;

export function getSharedUser(): SharedUser | null {
  try {
    const raw = sessionStorage.getItem(SHARED_KEYS.USER);
    return raw ? (JSON.parse(raw) as SharedUser) : null;
  } catch {
    return null;
  }
}

// Angular sets this on login; React reads on boot
export function setSharedUser(user: SharedUser): void {
  sessionStorage.setItem(SHARED_KEYS.USER, JSON.stringify(user));
}
```

---

## 📦 Per-Module Migration Workflow

When Copilot receives **"migrate the [X] module"**, execute exactly these steps:

### STEP 0 — Module Discovery (Always Run First)

Copilot must ask for or locate these files before writing any code:

```
□ List all Angular files in the module:
    apps/shell/src/app/features/[module-name]/
    libs/feature-[module-name]/src/

□ Identify:
    - Entry component (routed component)
    - Child/presentational components
    - Services used
    - NgRx feature state (actions, reducers, effects, selectors)
    - Pipes used
    - Route guards
    - AG Grid instances
    - PrimeNG components used
    - External API endpoints called
    - Shared lib dependencies

□ Map to React equivalents before writing any code
```

### STEP 1 — Scaffold React Feature Lib

```bash
# Run this NX command first
nx g @nx/react:library \
  --name=feature-[module-name] \
  --directory=libs/feature-[module-name] \
  --style=module.scss \
  --unitTestRunner=vitest \
  --bundler=vite

# Creates:
# libs/feature-[module-name]/
#   src/
#     lib/
#       components/   ← Presentational components
#       containers/   ← Connected/smart components
#       hooks/        ← Custom hooks (data fetching, local state)
#       store/        ← RTK slices (if module has its own state)
#       types/        ← Module-specific TypeScript interfaces
#       utils/        ← Module-specific pure functions
#     index.ts        ← Public API barrel
```

### STEP 2 — Module File Generation Order

Copilot MUST migrate files in this exact dependency order (bottom-up):

```
1. types/              ← TypeScript interfaces (copy from Angular, strip decorators)
2. utils/              ← Pure functions (pipes, formatters, validators)
3. store/              ← RTK slice (from NgRx feature module)
4. hooks/              ← React Query hooks (from Angular services)
5. components/         ← Presentational components (leaf nodes first)
6. containers/         ← Smart/connected components (depend on hooks + store)
7. [module].routes.tsx ← React Router route config (from Angular routes)
8. index.ts            ← Barrel exports
9. *.spec.tsx          ← Test files (100% coverage)
```

### STEP 3 — Feature Flag Gating (Safe Rollout)

Every migrated React module MUST be behind a feature flag during transition:

```typescript
// libs/util/src/lib/feature-flags/flags.ts
export type FeatureFlag =
  | 'USE_REACT_PRODUCTS'
  | 'USE_REACT_ORDERS'
  | 'USE_REACT_ADMIN'
  | 'USE_REACT_REPORTING';

const FLAGS: Record<FeatureFlag, boolean> = {
  USE_REACT_PRODUCTS:  import.meta.env.VITE_FF_REACT_PRODUCTS === 'true',
  USE_REACT_ORDERS:    import.meta.env.VITE_FF_REACT_ORDERS === 'true',
  USE_REACT_ADMIN:     import.meta.env.VITE_FF_REACT_ADMIN === 'true',
  USE_REACT_REPORTING: import.meta.env.VITE_FF_REACT_REPORTING === 'true',
};

export const isEnabled = (flag: FeatureFlag): boolean => FLAGS[flag];
```

```typescript
// Angular routing — conditionally load React or Angular feature
{
  path: 'products',
  loadChildren: isEnabled('USE_REACT_PRODUCTS')
    ? () => import('./react-bridge/products-react-bridge.module')
            .then(m => m.ProductsReactBridgeModule)
    : () => import('./features/products/products.module')
            .then(m => m.ProductsModule),
}
```

---

## 📋 Per-Module Checklists

### § PRE — Pre-Migration Checklist

Before writing a single line of React:

```
□ SOURCE AUDIT
  □ All Angular component files listed (*.component.ts, *.component.html, *.component.scss)
  □ All services used by this module identified
  □ All NgRx actions/reducers/effects/selectors for this module identified
  □ All routes in this module mapped (including child routes, guards, resolvers)
  □ All third-party components identified (AG Grid, PrimeNG, custom lib)
  □ API endpoints called by this module documented
  □ Unit test coverage of Angular module confirmed (baseline)

□ DEPENDENCY CHECK
  □ No circular dependencies to other unmigrated modules
  □ Shared libs this module depends on are already migrated OR are pure TS
  □ If shared lib needs migration first → flag and pause, migrate dependency first

□ SCAFFOLD
  □ NX library or app scaffolded for this feature
  □ Vitest config with 100% coverage thresholds in place
  □ ESLint + Prettier config inherited from workspace
  □ Feature flag added to flags.ts and .env.example
```

### § POST — Post-Migration Checklist

Before marking a module as DONE:

```
□ FUNCTIONALITY
  □ All routes from Angular module exist in React router config
  □ All route guards have React equivalents (RequireAuth, RequireRole, etc.)
  □ All Angular component @Inputs have corresponding React props
  □ All Angular component @Outputs have corresponding onXxx callback props
  □ All service API calls are covered by React Query hooks
  □ All NgRx state has RTK slice equivalents
  □ All AG Grid column defs and cell renderers migrated
  □ All PrimeNG components replaced with PrimeReact equivalents
  □ All pipes converted to utility functions or useMemo
  □ All form validations (Angular Reactive Forms → React Hook Form)

□ QUALITY
  □ 100% line/branch/function/statement coverage via Vitest
  □ Zero ESLint errors or warnings
  □ SonarQube scan: zero Critical, zero Major issues
  □ No 'any' types in migrated files
  □ No inline object/array literals passed as props (causes re-renders)
  □ All callbacks wrapped in useCallback
  □ All derived values wrapped in useMemo
  □ React.memo applied to all components

□ SECURITY
  □ No dangerouslySetInnerHTML without DOMPurify
  □ No sensitive data in localStorage via Zustand persist
  □ All API calls use the shared apiClient (interceptors applied)
  □ Environment variables accessed via import.meta.env.VITE_*

□ INTEGRATION
  □ Feature flag configured in all environments
  □ migrationBus subscriptions set up for auth/theme/notifications
  □ Angular shell can navigate to and from the React module
  □ Browser back/forward works correctly across the boundary
  □ Page title updates correctly (document.title or React Router handle)
  □ Deep links work (bookmarking a React sub-route and refreshing)

□ ACCESSIBILITY
  □ All interactive elements have accessible labels
  □ Keyboard navigation works (Tab order, Enter/Space on buttons)
  □ Screen reader tested for key flows
  □ Color contrast passes WCAG 2.1 AA
```

### § REPORT — Module Migration Report Template

After each module migration, Copilot outputs this summary:

```markdown
## Module Migration Report: [MODULE_NAME]

### Files Migrated
| Angular Source | React Output | Status |
|---|---|---|
| products.component.ts | containers/ProductsContainer.tsx | ✅ |
| product-card.component.ts | components/ProductCard/ProductCard.tsx | ✅ |
| products.service.ts | hooks/useProducts.ts | ✅ |
| products.actions.ts / .reducer.ts / .effects.ts | store/products.slice.ts | ✅ |
| currency-format.pipe.ts | utils/formatCurrency.ts | ✅ |

### State Changes
- NgRx feature `products` → RTK slice `productsSlice`
- 3 BehaviorSubjects → 2 Zustand atoms + 1 React Query cache

### API Contracts (Unchanged)
- GET /api/products ✅
- POST /api/products/:id/archive ✅

### Test Coverage
| Metric | Angular (Before) | React (After) |
|---|---|---|
| Lines | 100% | 100% |
| Branches | 100% | 100% |
| Functions | 100% | 100% |

### Risks / Notes
- ProductGrid uses AG Grid Server-Side Row Model — verify license key in React env
- AdminProductsView has complex form validation — migrated to React Hook Form + Zod

### Feature Flag
- Flag: `USE_REACT_PRODUCTS`
- Env var: `VITE_FF_REACT_PRODUCTS=true`
- Enable in: dev ✅ | staging ✅ | prod ❌ (pending QA sign-off)
```

---

## 🗺️ Module Dependency Graph (Migration Order)

Copilot must respect this ordering: always migrate **leaves before consumers**.

```
Step 1:  libs/util          ← Pure TS (no migration needed — verify only)
Step 2:  libs/domain        ← Pure TS (no migration needed — verify only)
Step 3:  libs/ui            ← Shared component library (migrate first, everything depends on it)
Step 4:  libs/data-access   ← Shared API hooks and RTK store (migrate before features)
         │
         ├── Step 5a: libs/feature-auth        ← Login, session (other features depend on auth)
         ├── Step 5b: libs/feature-[leaf-A]    ← No deps on other features
         ├── Step 5c: libs/feature-[leaf-B]    ← No deps on other features
         │
         ├── Step 6a: libs/feature-[mid-A]     ← Depends on leaf-A
         ├── Step 6b: libs/feature-[mid-B]     ← Depends on leaf-B
         │
         └── Step 7:  apps/shell               ← Last: replace Angular shell with React shell
```

**How to determine dependency order:**

```bash
# NX can generate the dep graph for you
nx dep-graph

# Or show deps for a specific lib
nx show project feature-orders --json | jq '.dependencies'
```

---

## 🔁 React Hook Form: Replacing Angular Reactive Forms

Angular Reactive Forms has the most complex 1-to-1 mapping. Use this template:

```typescript
// ─── Angular ──────────────────────────────────────
this.form = this.fb.group({
  name:     ['', [Validators.required, Validators.minLength(2)]],
  email:    ['', [Validators.required, Validators.email]],
  role:     ['viewer', Validators.required],
  notifyOn: this.fb.array([]),
});

// ─── React: React Hook Form + Zod ────────────────
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const userFormSchema = z.object({
  name:     z.string().min(2, 'Name must be at least 2 characters'),
  email:    z.string().email('Invalid email address'),
  role:     z.enum(['viewer', 'editor', 'admin']),
  notifyOn: z.array(z.string()).min(0),
});

type UserFormValues = z.infer<typeof userFormSchema>;

function UserForm({ onSubmit }: { onSubmit: (values: UserFormValues) => void }) {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting, isDirty },
  } = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: { name: '', email: '', role: 'viewer', notifyOn: [] },
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'notifyOn' });

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <div className={styles.field}>
        <label htmlFor="name">Name</label>
        <input id="name" {...register('name')} aria-invalid={!!errors.name} />
        {errors.name && <span role="alert" className={styles.error}>{errors.name.message}</span>}
      </div>

      <div className={styles.field}>
        <label htmlFor="email">Email</label>
        <input id="email" type="email" {...register('email')} aria-invalid={!!errors.email} />
        {errors.email && <span role="alert" className={styles.error}>{errors.email.message}</span>}
      </div>

      <button type="submit" disabled={isSubmitting || !isDirty}>
        {isSubmitting ? 'Saving…' : 'Save'}
      </button>
    </form>
  );
}
```

### Angular Validator → Zod Schema Mapping

| Angular Validator | Zod Equivalent |
|---|---|
| `Validators.required` | `.min(1)` or `.nonempty()` |
| `Validators.minLength(n)` | `.min(n)` |
| `Validators.maxLength(n)` | `.max(n)` |
| `Validators.email` | `.email()` |
| `Validators.pattern(regex)` | `.regex(regex)` |
| `Validators.min(n)` | `z.number().min(n)` |
| `Validators.max(n)` | `z.number().max(n)` |
| Custom `AbstractControl` validator | `z.string().refine(fn, msg)` |
| Cross-field validator | `z.object({...}).refine(fn, { path: ['field'] })` |

---

## 🔄 Rollback Plan Per Module

Each migrated module MUST have a rollback path:

```typescript
// Angular routing — instant rollback: set env var to false
{
  path: 'products',
  loadChildren: isEnabled('USE_REACT_PRODUCTS')
    ? () => import('./react-bridge/products-react-bridge.module').then(...)
    : () => import('./features/products/products.module').then(...),
}
```

**Rollback procedure:**

```bash
# 1. Set feature flag to false (no redeploy needed with runtime flags)
VITE_FF_REACT_PRODUCTS=false

# 2. If using hardcoded flags, revert ONE line in flags.ts
USE_REACT_PRODUCTS: false,

# 3. Redeploy Angular shell only — React MFE stays deployed but unused
# 4. Zero user impact — Angular module still exists, never deleted until flag is permanent
```

**Angular source files are NEVER deleted until:**
- React module has been in production for ≥ 2 sprint cycles
- Zero rollback events in that period
- QA sign-off on React module
- Feature flag permanently enabled

---

## 📊 Migration Progress Tracker

Maintain this in `MIGRATION.md` at the workspace root:

```markdown
# Migration Progress

| Module | Angular Lines | React Lines | Coverage | Flag | Status |
|---|---|---|---|---|---|
| libs/util | 1,200 | 1,200 | 100% | N/A | ✅ Done |
| libs/domain | 800 | 800 | 100% | N/A | ✅ Done |
| libs/ui | 5,400 | — | — | — | 🔄 In Progress |
| libs/data-access | 3,100 | — | — | — | ⏳ Queued |
| feature-auth | 2,200 | — | — | — | ⏳ Queued |
| feature-products | 4,800 | — | — | — | ⏳ Queued |
| feature-orders | 6,200 | — | — | — | ⏳ Queued |
| feature-reporting | 3,700 | — | — | — | ⏳ Queued |
| apps/shell | 2,100 | — | — | — | ⏳ Queued (Last) |

**Total**: 29,500 Angular lines | Migrated: 4.1% | Est. completion: —
```

---

## 💬 Copilot Trigger Phrases

Use these exact phrases to activate specific migration behaviors:

| Phrase | Copilot Action |
|---|---|
| `"migrate the [X] module"` | Full module migration (all steps) |
| `"migrate component [X]"` | Single component only |
| `"migrate service [X]"` | Service → React Query hook |
| `"migrate store [X]"` | NgRx feature → RTK slice |
| `"migrate routes [X]"` | Angular routes → React Router config |
| `"migrate forms in [X]"` | Angular Reactive Forms → RHF + Zod |
| `"audit [X] before migration"` | Run PRE checklist only, output findings |
| `"generate migration report for [X]"` | Output REPORT template filled in |
| `"check rollback for [X]"` | Verify feature flag + Angular source still intact |
| `"what should I migrate next?"` | Output next module from dependency graph |

---

## ⚠️ Incremental Migration Anti-Patterns

These are the most common ways incremental migrations fail. Copilot must flag these if detected:

| Anti-Pattern | Risk | Correct Approach |
|---|---|---|
| Deleting Angular source before React is in prod | No rollback possible | Keep Angular source until 2-sprint soak period |
| Sharing mutable JS objects between Angular and React | State desync, hard bugs | Use migrationBus or localStorage bridge only |
| Two React versions loaded (one in shell, one in MFE) | Hook rule violations | Force singleton: `shared: { react: { singleton: true } }` |
| Migrating shell/layout first | Everything else breaks | Always migrate leaves first, shell last |
| Mixing Angular Change Detection with React state | Unpredictable renders | Strict framework boundary — no Angular DI inside React |
| Rewriting business logic while migrating | Regression risk doubles | Translate first, optimize in a separate PR |
| Merging Angular and React state stores | Impossible to roll back | Keep separate stores, bridge with events |
| Using `any` to speed up migration | Tech debt, Sonar failures | Type everything, even if it slows migration |

---

*Addendum v1.0 | Strategy: Strangler Fig + NX Module Federation | Pattern: Route Takeover (default) → MFE (advanced)*


═══════════════════════════════════════════════════════════════════
SECTION 4 — MIGRATION PROGRESS TRACKER TEMPLATE (MIGRATION.md)
═══════════════════════════════════════════════════════════════════

# Angular → React Migration Tracker

## Status Legend
- ✅ Done (in prod ≥ 2 sprints, Angular source deleted)
- 🟡 In Prod (soak period — Angular source preserved)
- 🔄 In Progress
- ⏳ Queued
- ⛔ Blocked

## Progress

| Module | Files | Complexity | Stmt % | Branch % | Func % | Lines % | Flag | Status |
|---|---|---|---|---|---|---|---|---|
| libs/util | — | — | — | — | — | — | N/A | ⏳ Queued |
| libs/domain | — | — | — | — | — | — | N/A | ⏳ Queued |
| libs/ui | — | — | — | — | — | — | N/A | ⏳ Queued |
| libs/data-access | — | — | — | — | — | — | N/A | ⏳ Queued |
| feature-auth | — | — | — | — | — | — | USE_REACT_AUTH | ⏳ Queued |
| apps/shell | — | — | — | — | — | — | N/A | ⏳ Queued (Last) |

> Read by `@MigrateOrchestrator` every session.
> Complexity score (1–10) auto-computed during "what's next" analysis.
> All four coverage columns must show 100% before status can advance to 🟡 In Prod.
> ✅ Done requires 2-sprint production soak, zero rollbacks, and QA sign-off.


═══════════════════════════════════════════════════════════════════
SECTION 5 — USER PREFERENCES TEMPLATE (USER_PREFERENCES.md)
═══════════════════════════════════════════════════════════════════

# User Preferences
Generated by MigrateScaffold. Read by ALL agents every session.
Never manually edit — update by telling MigrateOrchestrator what changed.

---

## Project Structure
- migration_mode: [new-app | in-place]
- react_app_name: [name]
- react_app_root: apps/[name]
- angular_shell_app: [path]

## Styling
- css_approach: [global-scss | scss-modules | bem | css-in-js]
- design_token_file: [path or null]
- custom_fonts: [true | false]
- font_source: [assets | node_modules | cdn-link | null]
- font_files: []
- global_style_overrides: []

## State & Data
- state_strategy: [rtk | rtk-query | rtk-tanstack]
- api_base_url: [value or env-var name]
- has_http_interceptors: [true | false]
- interceptor_purpose: [description or null]

## Auth & Routing
- auth_strategy: [jwt-localstorage | jwt-cookie | session | oauth]
- has_global_auth_guard: [true | false]
- has_role_guards: [true | false]
- roles: []

## Build & Environment
- bundler: [vite | webpack]
- test_runner: [vitest | jest]
- env_var_prefix: [VITE_ | REACT_APP_]
- environments: []
- env_vars: {}
- existing_webpack_config: [path or null]
- existing_jest_config: [path or null]

## Scaffold Status
- scaffold_complete: false
- react_app_created: false
- bundler_config_written: false
- test_runner_config_written: false
- global_styles_migrated: false
- assets_migrated: false
- fonts_migrated: false
- font_files_in_react: []
- main_tsx_written: false
- env_files_written: false
- first_boot_verified: false
- dev_server_port: null
