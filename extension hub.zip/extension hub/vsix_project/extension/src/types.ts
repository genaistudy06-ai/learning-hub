// types.ts — All shared TypeScript interfaces and enums

// ── License (code-only activation — no idx.bin) ───────────────────────────────
export interface ParsedLicenseCode {
  raw:          string;     // full original code string
  machineHash:  string;     // first 8 hex chars of SHA256(machineId)
  expiryDays:   number;     // days since epoch (decoded from base36 segment)
  featureBits:  number;     // bitmask of licensed packs
  signature:    string;     // first 12 hex chars of HMAC
  expiresAt:    Date;       // computed from expiryDays
}

export interface LicenseFeatures {
  agentPacks:      string[];  // decoded from featureBits against pack registry
  selfLearning:    boolean;   // bit 7 of featureBits
  customStandards: boolean;   // bit 6 of featureBits
  maxAgents:       number;    // derived from pack count
}

export interface LicenseValidationResult {
  valid:           boolean;
  state:           ActivationState;
  features?:       LicenseFeatures;
  expiryLevel?:    ExpiryWarningLevel;
  daysRemaining?:  number;
}

// ── Activation states ─────────────────────────────────────────────────────────
export enum ActivationState {
  DORMANT          = 'DORMANT',
  VALIDATING       = 'VALIDATING',
  AWAITING_CODE    = 'AWAITING_CODE',
  DECRYPTING       = 'DECRYPTING',
  INJECTING        = 'INJECTING',
  ACTIVE           = 'ACTIVE',
  DEACTIVATING     = 'DEACTIVATING',
  BLOCKED_MACHINE  = 'BLOCKED_MACHINE',
  BLOCKED_CLOCK    = 'BLOCKED_CLOCK',
  BLOCKED_EXPIRED  = 'BLOCKED_EXPIRED',
  BLOCKED_INVALID  = 'BLOCKED_INVALID',
  BLOCKED_TAMPERED = 'BLOCKED_TAMPERED',
}

export enum ExpiryWarningLevel {
  NONE    = 'NONE',
  WARNING = 'WARNING',
  URGENT  = 'URGENT',
  GRACE   = 'GRACE',
  EXPIRED = 'EXPIRED',
}

// ── Product config (obfuscated field names match product.config.json) ─────────
export interface ProductConfig {
  a1f3: string;                         // productId
  b2e4: string;                         // productName
  c5d6: string;                         // productVersion
  e7f8: string;                         // accessCodePrefix
  f1a2: AgentPackConfig[];              // agentPacks array
  g3h4: Record<string, string>;         // agentDisplayNames
  i5j6: string;                         // statusBarLabel
  k7l8: string;                         // activationCommand

  // Convenience getters (computed in loadConfig)
  productId:         string;
  productName:       string;
  productVersion:    string;
  accessCodePrefix:  string;
  agentPacks:        AgentPackConfig[];
  agentDisplayNames: Record<string, string>;
  statusBarLabel:    string;
  activationCommand: string;
}

export interface AgentPackConfig {
  p1: string;   // packId
  p2: string;   // bin filename
  p3: string;   // featureFlag string (used to decode featureBits)
  p4?: string;  // optional namespace override (e.g. "abpy", "ang2react")
                // When set, agents are addressed as @namespace.agentId
                // instead of @productId.agentId
}

// ── Agent content ─────────────────────────────────────────────────────────────
export interface AgentContent {
  agentId:        string;
  displayName:    string;
  frontmatter:    string;
  body:           string;
  shieldInjected: boolean;
}

export interface AgentPack {
  packId:        string;
  namespace?:    string;  // if set, agents register as @namespace.agentId
                          // injected by dat-encoder --namespace flag at build time
  agents:        AgentContent[];
  instructions?: string;  // pack-level global instructions
}

// ── Self-learning ─────────────────────────────────────────────────────────────
export interface AgentLearning {
  id:          string;
  agentKey:    string;               // "packId:agentId" — namespaced to prevent collision
  learnedAt:   string;               // ISO timestamp
  topic:       string;
  insight:     string;
  source:      'auto' | 'user';      // user-taught gets higher recall priority
  usageCount:  number;
  lastUsed:    string;
}

export interface AgentLearningStore {
  agentKey:  string;                 // "packId:agentId"
  version:   number;
  learnings: AgentLearning[];
}

// ── Weekly stats (for tracker export) ────────────────────────────────────────
export interface WeeklyAgentStats {
  weekLabel:       string;           // ISO week e.g. "2026-W17"
  weekStart:       string;           // YYYY-MM-DD
  weekEnd:         string;           // YYYY-MM-DD
  invocations:     Record<string, number>;  // agentId → count
  totalInvocations: number;
  debateSessions:  number;
  modelUsage:      Record<string, number>;  // modelId → call count
  modelTier:       '0x' | '1x' | '3x';
  manualOverrides: number;
  learningsAutoSaved:  number;
  learningsUserTaught: number;
  learningsRecalled:   number;
  learningsPruned:     number;
  learningMode:    'local' | 'central';
  centralApiOk:    boolean | null;   // null = not configured
}

// ── File verification ─────────────────────────────────────────────────────────
export interface FileVerificationResult {
  valid:   boolean;
  failed?: string;
}
