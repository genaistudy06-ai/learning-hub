// ─── Search Service ───────────────────────────────────────────────────────────
import Fuse from 'fuse.js';
import type {
  SearchRequest, SearchResult, IndexEntry, Solution,
  Skill, Badge
} from '../../../../shared/types.js';
import { computeBadge } from './badgeEngine.js';
import { defaultStorage } from '../storage/storageFactory.js';

const FUSE_OPTIONS = {
  keys: [
    { name: 'title',   weight: 0.4 },
    { name: 'summary', weight: 0.3 },
    { name: 'tags',    weight: 0.3 },
  ],
  threshold: 0.4,
  includeScore: true,
};

export async function searchLearnings(
  req: SearchRequest,
  storage = defaultStorage
): Promise<SearchResult[]> {
  const index = await storage.getSkillIndex(req.skill);
  if (!index) return [];

  // Filter active + persona-aware entries
  const eligible = index.learnings.filter(e => {
    if (e.status === 'SUPPRESSED' || e.status === 'DEPRECATED') return false;
    if (e.personaHints.length > 0 && !e.personaHints.includes(req.persona)) return false;
    if (req.repoScope && e.repoScope && e.repoScope !== req.repoScope) return false;
    if (req.tenantId && e.tenantId && e.tenantId !== req.tenantId) return false;
    return true;
  });

  const fuse = new Fuse(eligible, FUSE_OPTIONS);
  const fuseResults = fuse.search(req.query, { limit: req.limit ?? 5 });

  const results: SearchResult[] = [];

  for (const fuseResult of fuseResults) {
    const entry = fuseResult.item as IndexEntry;
    const matchScore = 1 - (fuseResult.score ?? 0);

    const cluster = await storage.getCluster(entry.clusterId);
    if (!cluster) continue;

    // Fetch all solutions in this cluster
    const solutions: Array<Solution & { badge: Badge; matchScore: number }> = [];
    for (const solId of cluster.solutionIds) {
      const sol = await storage.getSolution(solId);
      if (!sol || sol.status === 'SUPPRESSED') continue;
      solutions.push({
        ...sol,
        badge: computeBadge({ upvotes: sol.upvotes, downvotes: sol.downvotes, retrievalCount: sol.retrievalCount }),
        matchScore,
      });
    }

    // Sort: HIGH_CONFIDENCE first, then by communityScore
    solutions.sort((a, b) => {
      if (a.status === 'HIGH_CONFIDENCE' && b.status !== 'HIGH_CONFIDENCE') return -1;
      if (b.status === 'HIGH_CONFIDENCE' && a.status !== 'HIGH_CONFIDENCE') return 1;
      return b.communityScore - a.communityScore;
    });

    // Increment retrieval count (fire and forget)
    incrementRetrieval(entry, storage);

    results.push({ cluster, solutions, topMatchScore: matchScore });
  }

  return results;
}

async function incrementRetrieval(entry: IndexEntry, storage: any) {
  try {
    const sol = await storage.getSolution(entry.id);
    if (sol) {
      sol.retrievalCount = (sol.retrievalCount ?? 0) + 1;
      await storage.saveSolution(sol);
    }
  } catch { /* best-effort */ }
}
