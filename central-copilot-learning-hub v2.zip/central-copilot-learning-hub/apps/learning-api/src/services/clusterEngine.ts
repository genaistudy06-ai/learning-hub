// ─── Cluster Engine ───────────────────────────────────────────────────────────
// Determines if an incoming learning belongs to an existing cluster
// or needs a new one. Uses Jaccard similarity on tag + keyword tokens.

import type { Cluster, SaveRequest } from '../../../../shared/types.js';

const SIMILARITY_THRESHOLD = 0.45; // PRD §4.2

function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(t => t.length > 2)
  );
}

function jaccard(a: Set<string>, b: Set<string>): number {
  const intersection = new Set([...a].filter(x => b.has(x)));
  const union = new Set([...a, ...b]);
  return union.size === 0 ? 0 : intersection.size / union.size;
}

export interface ClusterMatch {
  matched: boolean;
  cluster?: Cluster;
  score: number;
}

export function findCluster(
  incoming: SaveRequest,
  existingClusters: Cluster[],
  clusterDescriptions: Map<string, string>   // clusterId → description
): ClusterMatch {
  const incomingTokens = tokenize(
    `${incoming.title} ${incoming.summary} ${incoming.tags.join(' ')}`
  );

  let best: ClusterMatch = { matched: false, score: 0 };

  for (const cluster of existingClusters) {
    if (cluster.skill !== incoming.skill) continue;
    const desc = clusterDescriptions.get(cluster.id) ?? cluster.description;
    const clusterTokens = tokenize(desc);
    const score = jaccard(incomingTokens, clusterTokens);

    if (score > best.score) {
      best = { matched: score >= SIMILARITY_THRESHOLD, cluster, score };
    }
  }

  return best;
}

export function isDuplicate(
  incoming: SaveRequest,
  existingSolutions: Array<{ title: string; summary: string; tags: string[] }>
): boolean {
  const incomingTokens = tokenize(
    `${incoming.title} ${incoming.summary} ${incoming.tags.join(' ')}`
  );

  for (const sol of existingSolutions) {
    const solTokens = tokenize(
      `${sol.title} ${sol.summary} ${sol.tags.join(' ')}`
    );
    if (jaccard(incomingTokens, solTokens) >= 0.85) return true;
  }

  return false;
}
