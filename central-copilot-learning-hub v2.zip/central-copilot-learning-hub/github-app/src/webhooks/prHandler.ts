// ─── GitHub App — PR Webhook Handler (Phase 3) ───────────────────────────────
import Fastify from 'fastify';
import { createHmac, timingSafeEqual } from 'crypto';
import { Octokit } from '@octokit/rest';

const WEBHOOK_SECRET = process.env.GITHUB_WEBHOOK_SECRET!;
const APP_TOKEN      = process.env.GITHUB_APP_TOKEN!;
const LEARNING_API   = process.env.LEARNING_API_URL ?? 'http://localhost:3000/api/v1';

interface PRPayload {
  action: string;
  number: number;
  pull_request: {
    title: string;
    body: string;
    head: { ref: string };
    base: { ref: string; repo: { full_name: string; name: string; owner: { login: string } } };
    diff_url: string;
  };
  repository: { full_name: string; name: string; owner: { login: string } };
}

function verifySignature(payload: Buffer, signature: string): boolean {
  const hmac = createHmac('sha256', WEBHOOK_SECRET);
  hmac.update(payload);
  const digest = Buffer.from(`sha256=${hmac.digest('hex')}`);
  const sig     = Buffer.from(signature);
  return digest.length === sig.length && timingSafeEqual(digest, sig);
}

async function searchRelatedLearnings(title: string, body: string, repo: string): Promise<any[]> {
  const query = `${title} ${(body ?? '').slice(0, 200)}`.trim();
  const skill = inferSkillFromRepo(repo);

  const res = await fetch(
    `${LEARNING_API}/learnings/search?query=${encodeURIComponent(query)}&skill=${skill}&persona=${skill}&limit=5`
  );
  if (!res.ok) return [];
  const data = await res.json() as any;
  return data.results ?? [];
}

function inferSkillFromRepo(repoName: string): string {
  if (/angular|ng-|frontend/i.test(repoName)) return 'angular';
  if (/java|spring|backend/i.test(repoName))  return 'java';
  if (/python|data|ml/i.test(repoName))       return 'python';
  if (/infra|devops|k8s|helm/i.test(repoName)) return 'devops';
  return 'general';
}

function buildPRComment(results: any[]): string {
  if (results.length === 0) return '';

  const lines = [
    '## 📚 Learning Hub Suggestions',
    '',
    'Related learnings from your team\'s knowledge base:',
    '',
  ];

  for (const r of results.slice(0, 3)) {
    for (const sol of (r.solutions ?? []).slice(0, 2)) {
      lines.push(`### ${sol.badge ?? '📌'} ${sol.title}`);
      lines.push(`> ${sol.summary}`);
      lines.push('');
      lines.push('```');
      lines.push((sol.solutionText ?? '').slice(0, 500));
      lines.push('```');
      lines.push(`*Score: ${(sol.communityScore ?? 0).toFixed(1)} | 👍 ${sol.upvotes} 👎 ${sol.downvotes}*`);
      lines.push('---');
    }
  }

  lines.push('');
  lines.push('*Powered by [Central Copilot Learning Hub](https://github.com/your-org/learning-hub)*');

  return lines.join('\n');
}

async function main() {
  const app = Fastify({ logger: true });

  app.post('/webhook', {
    config: { rawBody: true },
  }, async (req, reply) => {
    const signature = req.headers['x-hub-signature-256'] as string;
    if (!signature || !verifySignature(req.rawBody as Buffer, signature)) {
      return reply.status(401).send({ error: 'Invalid signature' });
    }

    const event   = req.headers['x-github-event'] as string;
    const payload = req.body as PRPayload;

    // Only handle PR opened/synchronize events
    if (event !== 'pull_request' || !['opened', 'synchronize'].includes(payload.action)) {
      return reply.send({ skipped: true });
    }

    const pr   = payload.pull_request;
    const repo = payload.repository;

    try {
      const results = await searchRelatedLearnings(pr.title, pr.body ?? '', repo.name);
      const comment  = buildPRComment(results);

      if (!comment) {
        return reply.send({ commented: false, reason: 'No related learnings found' });
      }

      const octokit = new Octokit({ auth: APP_TOKEN });
      await octokit.issues.createComment({
        owner:      repo.owner.login,
        repo:       repo.name,
        issue_number: payload.number,
        body:       comment,
      });

      return reply.send({ commented: true, suggestionsCount: results.length });
    } catch (err: any) {
      req.log.error(err, 'Failed to post PR comment');
      return reply.status(500).send({ error: 'Internal error' });
    }
  });

  app.get('/health', async () => ({ status: 'ok' }));

  await app.listen({ port: Number(process.env.PORT ?? 3001), host: '0.0.0.0' });
  console.log('🤖 GitHub App webhook server running on port 3001');
}

main().catch(err => { console.error(err); process.exit(1); });
