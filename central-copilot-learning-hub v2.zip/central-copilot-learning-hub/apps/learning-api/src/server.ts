// ─── API Server ───────────────────────────────────────────────────────────────
import Fastify from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import { learningsRoutes } from './routes/learnings.js';
import { analyticsRoutes } from './routes/analytics.js';
import { tenantRoutes } from './routes/tenants.js';

const PORT = Number(process.env.PORT ?? 3000);
const HOST = process.env.HOST ?? '0.0.0.0';

async function buildApp() {
  const app = Fastify({ logger: true });

  // ── Plugins ──────────────────────────────────────────────────────────────
  await app.register(cors, {
    origin: process.env.CORS_ORIGIN ?? '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  });

  await app.register(rateLimit, {
    max: 120,
    timeWindow: '1 minute',
    errorResponseBuilder: () => ({
      error: 'Too Many Requests',
      message: 'Rate limit exceeded. Slow down!',
      statusCode: 429,
    }),
  });

  // ── Health ────────────────────────────────────────────────────────────────
  app.get('/health', async () => ({
    status: 'ok',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
  }));

  // ── Routes ────────────────────────────────────────────────────────────────
  await app.register(learningsRoutes, { prefix: '/api/v1' });
  await app.register(analyticsRoutes, { prefix: '/api/v1' });
  await app.register(tenantRoutes,    { prefix: '/api/v1' });

  return app;
}

async function main() {
  const app = await buildApp();
  await app.listen({ port: PORT, host: HOST });
  console.log(`\n🚀 Central Copilot Learning Hub API running on http://${HOST}:${PORT}\n`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});

export { buildApp };
