/* eslint-disable @typescript-eslint/no-var-requires */
const path              = require('path');
const webpack           = require('webpack');
const WebpackObfuscator = require('webpack-obfuscator');

const BUILD_SECRET_A = process.env.BUILD_SECRET_A;
const isProd         = process.env.NODE_ENV === 'production';

if (!BUILD_SECRET_A) {
  console.error('\n\nERROR: BUILD_SECRET_A environment variable is not set.');
  console.error('Run setenv.bat first, then run build.bat again.\n\n');
  process.exit(1);
}

module.exports = {
  target:    'node',
  mode:      isProd ? 'production' : 'development',
  entry:     './src/extension.ts',
  output: {
    path:          path.resolve(__dirname, 'dist'),
    filename:      'extension.js',
    libraryTarget: 'commonjs2',
  },
  devtool:   isProd ? false : 'source-map',
  externals: { vscode: 'commonjs vscode' },
  resolve:   { extensions: ['.ts', '.js'] },
  module: {
    rules: [{
      test:    /\.ts$/,
      exclude: /node_modules/,
      use:     [{ loader: 'ts-loader',
                  options: { compilerOptions: { sourceMap: !isProd } } }],
    }],
  },
  plugins: [
    new webpack.DefinePlugin({
      __BUILD_SECRET_A__: JSON.stringify(BUILD_SECRET_A),
      __IS_PRODUCTION__:  JSON.stringify(isProd),
    }),
    ...(isProd ? [new WebpackObfuscator({
      rotateStringArray:                  true,
      stringArray:                        true,
      stringArrayEncoding:                ['base64'],
      stringArrayThreshold:               0.85,
      stringArrayCallsTransform:          true,
      stringArrayCallsTransformThreshold: 0.75,
      controlFlowFlattening:              true,
      controlFlowFlatteningThreshold:     0.7,
      deadCodeInjection:                  true,
      deadCodeInjectionThreshold:         0.4,
      selfDefending:                      true,
      disableConsoleOutput:               true,
      identifierNamesGenerator:           'hexadecimal',
      renameGlobals:                      false,
      numbersToExpressions:               true,
      splitStrings:                       true,
      splitStringsChunkLength:            8,
      target:                             'node',
    }, [])] : []),
  ],
};
