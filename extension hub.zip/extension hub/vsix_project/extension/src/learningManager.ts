// learningManager.ts — Persists and retrieves per-agent learnings across sessions
// Storage key: packId:agentId  (prevents collision between agents with same ID across packs)
// Survives VSIX version upgrades — globalStorageUri is never cleared on update.
import * as vscode from 'vscode';
import * as fs     from 'fs';
import * as path   from 'path';
import * as crypto from 'crypto';
import { AgentLearning, AgentLearningStore } from './types';

const STORE_VERSION   = 2;
const MAX_LEARNINGS   = 100;   // per agent — oldest pruned when exceeded
const TOP_K_RECALL    = 7;     // injected per request (down from 12 — reduces token overhead)
const STALE_DAYS      = 30;    // prune learnings unused for this many days

// ── Extraction patterns — raised quality threshold (min score 5, was 3) ───────
const LEARNING_PATTERNS: Array<{ regex: RegExp; weight: number }> = [
  { regex: /\b(always|never|make sure|important(?:ly)?|note that|remember that|keep in mind)\b/i, weight: 3 },
  { regex: /\b(best practice|recommended|prefer|avoid|don['']t use|use instead)\b/i,             weight: 3 },
  { regex: /\b(the reason is|because|this is why|root cause|key insight)\b/i,                    weight: 2 },
  { regex: /\b(pattern|convention|standard|rule|guideline)\b/i,                                  weight: 2 },
  { regex: /\b(in this (project|codebase|repo)|your (setup|config|stack))\b/i,                   weight: 4 },
  { regex: /\b(instead of|rather than|as opposed to)\b/i,                                        weight: 2 },
  { regex: /\b(common (mistake|pitfall|issue|error))\b/i,                                        weight: 3 },
  { regex: /\b(critical|mandatory|required|must|shall)\b/i,                                      weight: 2 },
];

// Sentences to skip — too generic or conversational
const SKIP_PATTERNS: RegExp[] = [
  /^(sure|okay|of course|absolutely|great|let me|i (will|can|would)|here('s| is))/i,
  /^(this|that|it) (is|was|seems|looks|appears)/i,
  /thank(s| you)/i,
  /\b(i|me|my|we|our)\b/i,
];

// Correction signals — don't store responses where the model is backtracking
const CORRECTION_SIGNALS: RegExp[] = [
  /\b(i was wrong|actually|let me correct|let me reconsider|correction:|my mistake|i apologise|i apologize)\b/i,
  /\b(wait,|hmm,|actually,|on second thought)\b/i,
];

export class LearningManager {
  readonly storageDir: string;
  private cache: Map<string, AgentLearningStore> = new Map();

  constructor(ctx: vscode.ExtensionContext) {
    this.storageDir = path.join(ctx.globalStorageUri.fsPath, 'learnings');
    fs.mkdirSync(this.storageDir, { recursive: true });
  }

  // ── Storage key — always "packId:agentId" ────────────────────────────────
  private storeKey(agentKey: string): string {
    // agentKey is already "packId:agentId" — sanitize for filesystem
    return agentKey.replace(/[^a-zA-Z0-9_-]/g, '_');
  }

  private storePath(agentKey: string): string {
    return path.join(this.storageDir, `${this.storeKey(agentKey)}.json`);
  }

  // ── Load store (memory-cached) ────────────────────────────────────────────
  load(agentKey: string): AgentLearningStore {
    if (this.cache.has(agentKey)) return this.cache.get(agentKey)!;
    const p = this.storePath(agentKey);
    if (fs.existsSync(p)) {
      try {
        const store = JSON.parse(fs.readFileSync(p, 'utf-8')) as AgentLearningStore;
        this.cache.set(agentKey, store);
        return store;
      } catch { /* corrupt file — start fresh */ }
    }
    const fresh: AgentLearningStore = { agentKey, version: STORE_VERSION, learnings: [] };
    this.cache.set(agentKey, fresh);
    return fresh;
  }

  // ── Recall top-K learnings (scored + keyword-gated to save tokens) ────────
  recall(agentKey: string, userMessage?: string): AgentLearning[] {
    const store = this.load(agentKey);
    if (!store.learnings.length) return [];

    const now = Date.now();
    let candidates = store.learnings;

    // Keyword gate: if userMessage provided, prefer learnings with topic overlap
    if (userMessage && userMessage.length > 10) {
      const msgWords = new Set(
        userMessage.toLowerCase().split(/\W+/).filter(w => w.length > 3)
      );
      const topicMatches = candidates.filter(l => {
        const topicWords = l.topic.toLowerCase().split(/\W+/);
        return topicWords.some(w => msgWords.has(w));
      });
      // Use topic-matching subset if it has enough entries, else fall back to all
      if (topicMatches.length >= 3) candidates = topicMatches;
    }

    const scored = candidates.map(l => {
      const ageMins    = (now - new Date(l.lastUsed).getTime()) / 60_000;
      const recency    = Math.exp(-ageMins / (7 * 24 * 60));
      const frequency  = Math.log1p(l.usageCount) / Math.log1p(MAX_LEARNINGS);
      const userBoost  = l.source === 'user' ? 1.4 : 1.0; // user-taught = highest priority
      return { l, score: (0.6 * recency + 0.4 * frequency) * userBoost };
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, TOP_K_RECALL).map(s => s.l);
  }

  // ── Mark recalled learnings as used ──────────────────────────────────────
  markUsed(learnings: AgentLearning[]): void {
    for (const l of learnings) {
      const store = this.cache.get(l.agentKey);
      if (!store) continue;
      const entry = store.learnings.find(x => x.id === l.id);
      if (entry) {
        entry.usageCount++;
        entry.lastUsed = new Date().toISOString();
      }
      this.persist(store);
    }
  }

  // ── Save a learning (user-taught or from extraction) ─────────────────────
  save(agentKey: string, topic: string, insight: string, source: 'auto' | 'user' = 'auto'): void {
    if (!insight || insight.length < 20) return;

    const store = this.load(agentKey);

    // Deduplication
    const dup = store.learnings.find(l =>
      l.topic.toLowerCase() === topic.toLowerCase() ||
      this.similarity(l.insight, insight) > 0.82,
    );

    if (dup) {
      dup.usageCount++;
      dup.lastUsed = new Date().toISOString();
      // Upgrade to user-taught if now explicitly taught
      if (source === 'user') dup.source = 'user';
      this.persist(store);
      return;
    }

    store.learnings.push({
      id:         crypto.randomBytes(6).toString('hex'),
      agentKey,
      learnedAt:  new Date().toISOString(),
      topic:      topic.trim(),
      insight:    insight.trim(),
      source,
      usageCount: 0,
      lastUsed:   new Date().toISOString(),
    });

    // Prune stale learnings (unused for STALE_DAYS)
    this.pruneStale(store);

    // Prune oldest if still over limit
    if (store.learnings.length > MAX_LEARNINGS) {
      store.learnings.sort(
        (a, b) => new Date(a.lastUsed).getTime() - new Date(b.lastUsed).getTime(),
      );
      store.learnings = store.learnings.slice(store.learnings.length - MAX_LEARNINGS);
    }

    this.persist(store);
  }

  // ── Extract learnings from agent reply — ZERO extra LM calls ─────────────
  extractAndSave(agentKey: string, userMessage: string, agentReply: string): boolean {
    // Skip if response contains correction signals (model was wrong — don't store)
    if (CORRECTION_SIGNALS.some(p => p.test(agentReply))) return false;

    const sentences = agentReply
      .replace(/```[\s\S]*?```/g, '')       // strip code blocks
      .split(/(?<=[.!?])\s+/)
      .map(s => s.trim())
      .filter(s => s.length > 40 && s.length < 300);

    let saved = false;
    for (const sentence of sentences) {
      if (SKIP_PATTERNS.some(p => p.test(sentence))) continue;

      let score = 0;
      for (const { regex, weight } of LEARNING_PATTERNS) {
        if (regex.test(sentence)) score += weight;
      }
      if (score < 5) continue; // raised threshold (was 3)

      // Better topic extraction: first meaningful noun phrase (skip question/filler words)
      const stopWords = new Set(['what','how','why','when','where','who','which','can','could','would','should','please','the','a','an','is','are','was','were','do','does','did']);
      const topic = userMessage
        .replace(/[^a-zA-Z0-9 ]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 2 && !stopWords.has(w.toLowerCase()))
        .slice(0, 6)
        .join(' ')
        .trim() || 'General insight';

      this.save(agentKey, topic, sentence, 'auto');
      saved = true;
    }
    return saved;
  }

  // ── Prune stale learnings ─────────────────────────────────────────────────
  private pruneStale(store: AgentLearningStore): void {
    const threshold = Date.now() - STALE_DAYS * 24 * 60 * 60 * 1000;
    store.learnings = store.learnings.filter(l => {
      if (l.source === 'user') return true; // never prune user-taught
      return new Date(l.lastUsed).getTime() > threshold || l.usageCount > 0;
    });
  }

  // ── Clear all learnings for an agent ─────────────────────────────────────
  clear(agentKey: string): void {
    const fresh: AgentLearningStore = { agentKey, version: STORE_VERSION, learnings: [] };
    this.cache.set(agentKey, fresh);
    this.persist(fresh);
  }

  // ── List all stored agent keys ────────────────────────────────────────────
  listAgentKeys(): string[] {
    if (!fs.existsSync(this.storageDir)) return [];
    return fs.readdirSync(this.storageDir)
      .filter(f => f.endsWith('.json'))
      .map(f => path.basename(f, '.json').replace(/_/g, ':'));
  }

  // ── Stats for status panel / weekly tracker ───────────────────────────────
  stats(agentKey: string): { count: number; userTaught: number; oldest?: string; newest?: string } {
    const store = this.load(agentKey);
    if (!store.learnings.length) return { count: 0, userTaught: 0 };
    const dates     = store.learnings.map(l => l.learnedAt).sort();
    const userTaught = store.learnings.filter(l => l.source === 'user').length;
    return { count: store.learnings.length, userTaught, oldest: dates[0], newest: dates[dates.length - 1] };
  }

  // ── Version migration — run once at activation ────────────────────────────
  runMigrations(previousVersion: string | undefined): void {
    if (!previousVersion) return;
    // Future: add migration logic here when agent IDs change between versions
    // Example: rename 'sdlc_data-engineer' → 'sdlc_data_engineer'
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  private persist(store: AgentLearningStore): void {
    try {
      fs.writeFileSync(
        this.storePath(store.agentKey),
        JSON.stringify(store, null, 2),
        'utf-8',
      );
    } catch { /* best-effort */ }
  }

  private similarity(a: string, b: string): number {
    const words = (s: string) =>
      new Set(s.toLowerCase().split(/\W+/).filter(w => w.length > 3));
    const wa = words(a), wb = words(b);
    if (!wa.size || !wb.size) return 0;
    let shared = 0;
    for (const w of wa) if (wb.has(w)) shared++;
    return shared / Math.max(wa.size, wb.size);
  }
}
