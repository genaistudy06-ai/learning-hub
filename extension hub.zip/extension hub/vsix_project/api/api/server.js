/**
 * SDLC Agents — Central Learning API
 * Storage: local filesystem (JSON files) — no S3, no cloud required
 * Deploy: run on any Node.js server. Back up the /data folder.
 *
 * File layout on disk:
 *   data/learnings/{packId}/{agentKey}.json   → AgentLearningStore
 *   data/stats/{packId}/{agentKey}.json       → weekly stats per agent
 *
 * All routes require header:  x-api-key: <API_KEY from .env>
 */

'use strict';
require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const fs       = require('fs');
const path     = require('path');
const crypto   = require('crypto');
const { v4: uuidv4 } = require('uuid');

// ── Storage root ──────────────────────────────────────────────────────────────
const DATA_ROOT = path.resolve(process.env.DATA_DIR || './data');
const LEARN_DIR = path.join(DATA_ROOT, 'learnings');
const STATS_DIR = path.join(DATA_ROOT, 'stats');
fs.mkdirSync(LEARN_DIR, { recursive: true });
fs.mkdirSync(STATS_DIR, { recursive: true });

// ── Express ───────────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

// ── Auth ──────────────────────────────────────────────────────────────────────
function auth(req, res, next) {
  const key = req.headers['x-api-key'];
  if (!key || key !== process.env.API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// ── Filesystem helpers ────────────────────────────────────────────────────────
function learnPath(packId, agentKey) {
  const dir = path.join(LEARN_DIR, packId);
  fs.mkdirSync(dir, { recursive: true });
  // sanitize agentKey for filesystem
  const safe = agentKey.replace(/[^a-zA-Z0-9_-]/g, '_');
  return path.join(dir, `${safe}.json`);
}

function statsPath(packId, agentKey) {
  const dir = path.join(STATS_DIR, packId);
  fs.mkdirSync(dir, { recursive: true });
  const safe = agentKey.replace(/[^a-zA-Z0-9_-]/g, '_');
  return path.join(dir, `${safe}.json`);
}

function readJson(filePath) {
  if (!fs.existsSync(filePath)) return null;
  try { return JSON.parse(fs.readFileSync(filePath, 'utf-8')); }
  catch { return null; }
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

// ── Constants ─────────────────────────────────────────────────────────────────
const MAX_LEARNINGS = 200;
const TOP_K_RECALL  = 10;
const STALE_DAYS    = 30;

// ── Scoring (mirrors local LearningManager) ───────────────────────────────────
function scoreAndSort(learnings) {
  const now = Date.now();
  return learnings
    .map(l => {
      const ageMins   = (now - new Date(l.lastUsed).getTime()) / 60_000;
      const recency   = Math.exp(-ageMins / (7 * 24 * 60));
      const frequency = Math.log1p(l.usageCount) / Math.log1p(MAX_LEARNINGS);
      const userBoost = l.source === 'user' ? 1.4 : 1.0;
      return { l, score: (0.6 * recency + 0.4 * frequency) * userBoost };
    })
    .sort((a, b) => b.score - a.score);
}

function similarity(a, b) {
  const words = s => new Set(s.toLowerCase().split(/\W+/).filter(w => w.length > 3));
  const wa = words(a), wb = words(b);
  if (!wa.size || !wb.size) return 0;
  let shared = 0;
  for (const w of wa) if (wb.has(w)) shared++;
  return shared / Math.max(wa.size, wb.size);
}

function pruneStale(learnings) {
  const threshold = Date.now() - STALE_DAYS * 24 * 60 * 60 * 1000;
  return learnings.filter(l => {
    if (l.source === 'user') return true;
    return new Date(l.lastUsed).getTime() > threshold || l.usageCount > 0;
  });
}

// ═════════════════════════════════════════════════════════════════════════════
//  ROUTES
// ═════════════════════════════════════════════════════════════════════════════

// ── Health (no auth) ──────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', dataDir: DATA_ROOT, ts: new Date().toISOString() });
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /learnings/:packId/:agentKey
// Returns top-K learnings, scored by recency + usage
// Query: ?k=10  ?topic=<keyword for relevance pre-filtering>
// ─────────────────────────────────────────────────────────────────────────────
app.get('/learnings/:packId/:agentKey', auth, (req, res) => {
  try {
    const { packId, agentKey } = req.params;
    const k     = Math.min(parseInt(req.query.k || TOP_K_RECALL, 10), 20);
    const topic = req.query.topic?.toLowerCase();

    const store = readJson(learnPath(packId, agentKey));
    if (!store || !store.learnings?.length) {
      return res.json({ agentKey, packId, learnings: [], total: 0 });
    }

    let candidates = store.learnings;

    // Keyword pre-filter (same as local keyword-gate in LearningManager)
    if (topic) {
      const topicWords = new Set(topic.split(/\W+/).filter(w => w.length > 3));
      const matched    = candidates.filter(l =>
        l.topic.toLowerCase().split(/\W+/).some(w => topicWords.has(w))
      );
      if (matched.length >= 3) candidates = matched;
    }

    const topK = scoreAndSort(candidates).slice(0, k).map(s => s.l);
    res.json({ agentKey, packId, learnings: topK, total: store.learnings.length });
  } catch (err) {
    console.error('GET /learnings error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /learnings/:packId/:agentKey
// Contribute one or more learnings
// Body: { learnings: [{ topic, insight, source, usageCount }] }
// ─────────────────────────────────────────────────────────────────────────────
app.post('/learnings/:packId/:agentKey', auth, (req, res) => {
  try {
    const { packId, agentKey } = req.params;
    const incoming = req.body?.learnings;
    if (!Array.isArray(incoming) || !incoming.length) {
      return res.status(400).json({ error: 'Body must be { learnings: [...] }' });
    }

    const p     = learnPath(packId, agentKey);
    const store = readJson(p) || { agentKey, packId, version: 2, learnings: [] };

    let added = 0, merged = 0;
    for (const item of incoming) {
      if (!item.topic || !item.insight) continue;
      if (item.insight.length < 20) continue;  // quality gate

      const dup = store.learnings.find(l =>
        l.topic.toLowerCase() === item.topic.toLowerCase() ||
        similarity(l.insight, item.insight) > 0.82
      );

      if (dup) {
        dup.usageCount++;
        dup.lastUsed = new Date().toISOString();
        if (item.source === 'user') dup.source = 'user';
        merged++;
      } else {
        store.learnings.push({
          id:         uuidv4(),
          agentKey,
          packId,
          learnedAt:  new Date().toISOString(),
          lastUsed:   new Date().toISOString(),
          topic:      item.topic.trim(),
          insight:    item.insight.trim(),
          source:     item.source || 'auto',
          usageCount: item.usageCount || 0,
        });
        added++;
      }
    }

    // Prune stale, then enforce max size
    store.learnings = pruneStale(store.learnings);
    if (store.learnings.length > MAX_LEARNINGS) {
      store.learnings = scoreAndSort(store.learnings)
        .slice(0, MAX_LEARNINGS).map(s => s.l);
    }

    writeJson(p, store);
    res.json({ ok: true, added, merged, total: store.learnings.length });
  } catch (err) {
    console.error('POST /learnings error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH /learnings/:packId/:agentKey/:learningId/used
// ─────────────────────────────────────────────────────────────────────────────
app.patch('/learnings/:packId/:agentKey/:learningId/used', auth, (req, res) => {
  try {
    const { packId, agentKey, learningId } = req.params;
    const p     = learnPath(packId, agentKey);
    const store = readJson(p);
    if (!store) return res.status(404).json({ error: 'Store not found' });

    const entry = store.learnings.find(l => l.id === learningId);
    if (!entry)  return res.status(404).json({ error: 'Learning not found' });

    entry.usageCount++;
    entry.lastUsed = new Date().toISOString();
    writeJson(p, store);
    res.json({ ok: true, learningId, usageCount: entry.usageCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DELETE /learnings/:packId/:agentKey/:learningId
// ─────────────────────────────────────────────────────────────────────────────
app.delete('/learnings/:packId/:agentKey/:learningId', auth, (req, res) => {
  try {
    const { packId, agentKey, learningId } = req.params;
    const p     = learnPath(packId, agentKey);
    const store = readJson(p);
    if (!store) return res.status(404).json({ error: 'Store not found' });

    const before         = store.learnings.length;
    store.learnings      = store.learnings.filter(l => l.id !== learningId);
    if (store.learnings.length === before) {
      return res.status(404).json({ error: 'Learning ID not found' });
    }

    writeJson(p, store);
    res.json({ ok: true, removed: 1, remaining: store.learnings.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DELETE /learnings/:packId/:agentKey  — clear all
// ─────────────────────────────────────────────────────────────────────────────
app.delete('/learnings/:packId/:agentKey', auth, (req, res) => {
  try {
    const { packId, agentKey } = req.params;
    const p = learnPath(packId, agentKey);
    if (fs.existsSync(p)) fs.unlinkSync(p);
    res.json({ ok: true, message: `Cleared ${packId}:${agentKey}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /learnings/:packId  — list all agents in a pack
// ─────────────────────────────────────────────────────────────────────────────
app.get('/learnings/:packId', auth, (req, res) => {
  try {
    const { packId } = req.params;
    const dir = path.join(LEARN_DIR, packId);
    if (!fs.existsSync(dir)) return res.json({ packId, agents: [], count: 0 });

    const agents = fs.readdirSync(dir)
      .filter(f => f.endsWith('.json'))
      .map(f => {
        const store = readJson(path.join(dir, f));
        return {
          agentKey:      store?.agentKey ?? f.replace('.json', ''),
          count:         store?.learnings?.length ?? 0,
          userTaught:    store?.learnings?.filter(l => l.source === 'user').length ?? 0,
          lastModified:  fs.statSync(path.join(dir, f)).mtime,
        };
      });

    res.json({ packId, agents, count: agents.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /stats/:packId/:agentKey — record weekly stats
// Body: { week, invocations, modelTier, modelUsed, manualOverrides,
//         debateCalls, learningsAutoSaved, learningsUserTaught,
//         learningsRecalled, learningMode }
// ─────────────────────────────────────────────────────────────────────────────
app.post('/stats/:packId/:agentKey', auth, (req, res) => {
  try {
    const { packId, agentKey } = req.params;
    if (!req.body?.week) return res.status(400).json({ error: 'week is required' });

    const p     = statsPath(packId, agentKey);
    const store = readJson(p) || { agentKey, packId, weeks: [] };
    const entry = { ...req.body, recordedAt: new Date().toISOString() };
    const idx   = store.weeks.findIndex(w => w.week === req.body.week);
    if (idx >= 0) store.weeks[idx] = entry;
    else          store.weeks.push(entry);
    store.weeks = store.weeks.slice(-52); // keep 52 weeks
    writeJson(p, store);
    res.json({ ok: true, week: req.body.week });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /stats/:packId/:agentKey?weeks=8
// ─────────────────────────────────────────────────────────────────────────────
app.get('/stats/:packId/:agentKey', auth, (req, res) => {
  try {
    const { packId, agentKey } = req.params;
    const n     = parseInt(req.query.weeks || 8, 10);
    const store = readJson(statsPath(packId, agentKey));
    if (!store)  return res.json({ agentKey, packId, weeks: [] });
    res.json({ agentKey, packId, weeks: store.weeks.slice(-n) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`SDLC Learning API  →  http://localhost:${PORT}`);
  console.log(`Data directory     →  ${DATA_ROOT}`);
  console.log(`Auth               →  x-api-key header required`);
});

module.exports = app;
