// ─── Analytics Service (Phase 2) ─────────────────────────────────────────────
import type { AnalyticsSnapshot, Skill } from '../../../../shared/types.js';
import { defaultStorage } from '../storage/storageFactory.js';

const ALL_SKILLS: Skill[] = ['angular', 'java', 'python', 'devops', 'sql', 'qa', 'general'];

export async function generateAnalyticsSnapshot(
  skill: Skill,
  storage = defaultStorage
): Promise<AnalyticsSnapshot> {
  const index = await storage.getSkillIndex(skill);
  const learnings = index?.learnings ?? [];

  const activeCount       = learnings.filter(e => e.status === 'ACTIVE').length;
  const suppressedCount   = learnings.filter(e => e.status === 'SUPPRESSED').length;
  const deprecatedCount   = learnings.filter(e => e.status === 'DEPRECATED').length;
  const highConfCount     = learnings.filter(e => e.status === 'HIGH_CONFIDENCE').length;

  const topRetrieved = [...learnings]
    .sort((a, b) => b.retrievalCount - a.retrievalCount)
    .slice(0, 5);

  const topVoted = [...learnings]
    .sort((a, b) => b.communityScore - a.communityScore)
    .slice(0, 5);

  // Cross-skill coverage
  const coverageBySkill: Record<string, number> = {};
  for (const s of ALL_SKILLS) {
    const idx = await storage.getSkillIndex(s);
    coverageBySkill[s] = idx?.learnings.length ?? 0;
  }

  return {
    skill,
    totalLearnings: learnings.length,
    activeCount,
    suppressedCount,
    deprecatedCount,
    highConfidenceCount: highConfCount,
    topRetrieved,
    topVoted,
    coverageBySkill,
    generatedAt: new Date().toISOString(),
  };
}

export async function generateAllSkillsSnapshot(
  storage = defaultStorage
): Promise<AnalyticsSnapshot[]> {
  return Promise.all(ALL_SKILLS.map(s => generateAnalyticsSnapshot(s, storage)));
}
