// ─── GitHub Storage Adapter ───────────────────────────────────────────────────
// Persists SkillIndex, Solutions, Clusters and VoteRecords as JSON files
// in a designated GitHub repository.

import { Octokit } from '@octokit/rest';
import type {
  SkillIndex, Solution, Cluster, VoteRecord, Skill
} from '../../../../shared/types.js';

export interface GitHubStorageConfig {
  token: string;
  owner: string;
  repo: string;
  branch?: string;
}

interface GitHubFile {
  content: string;
  sha: string;
}

export class GitHubStorageAdapter {
  private octokit: Octokit;
  private owner: string;
  private repo: string;
  private branch: string;

  constructor(cfg: GitHubStorageConfig) {
    this.octokit = new Octokit({ auth: cfg.token });
    this.owner = cfg.owner;
    this.repo = cfg.repo;
    this.branch = cfg.branch ?? 'main';
  }

  // ── Low-level helpers ──────────────────────────────────────────────────────

  private async getFile(path: string): Promise<GitHubFile | null> {
    try {
      const res = await this.octokit.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path,
        ref: this.branch,
      });
      const data = res.data as { content: string; sha: string };
      return {
        content: Buffer.from(data.content, 'base64').toString('utf-8'),
        sha: data.sha,
      };
    } catch (e: any) {
      if (e.status === 404) return null;
      throw e;
    }
  }

  private async putFile(path: string, content: string, sha?: string, message?: string): Promise<void> {
    await this.octokit.repos.createOrUpdateFileContents({
      owner: this.owner,
      repo: this.repo,
      path,
      branch: this.branch,
      message: message ?? `chore: update ${path}`,
      content: Buffer.from(content).toString('base64'),
      sha,
    });
  }

  private async readJson<T>(path: string): Promise<T | null> {
    const file = await this.getFile(path);
    if (!file) return null;
    return JSON.parse(file.content) as T;
  }

  private async writeJson<T>(path: string, data: T, message?: string): Promise<void> {
    const file = await this.getFile(path);
    await this.putFile(
      path,
      JSON.stringify(data, null, 2),
      file?.sha,
      message
    );
  }

  // ── Skill Index ───────────────────────────────────────────────────────────

  async getSkillIndex(skill: Skill): Promise<SkillIndex | null> {
    return this.readJson<SkillIndex>(`indexes/${skill}-index.json`);
  }

  async saveSkillIndex(index: SkillIndex): Promise<void> {
    await this.writeJson(
      `indexes/${index.skill}-index.json`,
      { ...index, version: (index.version ?? 0) + 1, updatedAt: new Date().toISOString() },
      `feat: update ${index.skill} index`
    );
  }

  // ── Solutions ─────────────────────────────────────────────────────────────

  async getSolution(solutionId: string): Promise<Solution | null> {
    return this.readJson<Solution>(`solutions/${solutionId}.json`);
  }

  async saveSolution(solution: Solution): Promise<void> {
    await this.writeJson(
      `solutions/${solution.id}.json`,
      solution,
      `feat: save solution ${solution.id}`
    );
  }

  async listSolutionIds(): Promise<string[]> {
    try {
      const res = await this.octokit.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path: 'solutions',
        ref: this.branch,
      });
      const items = res.data as Array<{ name: string }>;
      return items
        .filter(i => i.name.endsWith('.json'))
        .map(i => i.name.replace('.json', ''));
    } catch {
      return [];
    }
  }

  // ── Clusters ──────────────────────────────────────────────────────────────

  async getCluster(clusterId: string): Promise<Cluster | null> {
    return this.readJson<Cluster>(`clusters/${clusterId}.json`);
  }

  async saveCluster(cluster: Cluster): Promise<void> {
    await this.writeJson(
      `clusters/${cluster.id}.json`,
      cluster,
      `feat: update cluster ${cluster.id}`
    );
  }

  async listClusters(skill?: Skill): Promise<Cluster[]> {
    try {
      const res = await this.octokit.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path: 'clusters',
        ref: this.branch,
      });
      const items = res.data as Array<{ name: string }>;
      const ids = items
        .filter(i => i.name.endsWith('.json'))
        .map(i => i.name.replace('.json', ''));

      const clusters = await Promise.all(ids.map(id => this.getCluster(id)));
      const valid = clusters.filter((c): c is Cluster => c !== null);
      return skill ? valid.filter(c => c.skill === skill) : valid;
    } catch {
      return [];
    }
  }

  // ── Votes ─────────────────────────────────────────────────────────────────

  async getVoteRecord(solutionId: string): Promise<VoteRecord | null> {
    return this.readJson<VoteRecord>(`votes/${solutionId}.json`);
  }

  async saveVoteRecord(record: VoteRecord): Promise<void> {
    await this.writeJson(
      `votes/${record.solutionId}.json`,
      record,
      `chore: update votes for ${record.solutionId}`
    );
  }

  // ── Phase 2: Version history ──────────────────────────────────────────────

  async getSolutionHistory(solutionId: string): Promise<Solution['history']> {
    const sol = await this.getSolution(solutionId);
    return sol?.history ?? [];
  }
}
