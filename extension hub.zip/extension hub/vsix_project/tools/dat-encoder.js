#!/usr/bin/env node
/**
 * dat-encoder.js — Encrypts agent definition files into encrypted .bin packs.
 *
 * ── TWO MODES ────────────────────────────────────────────────────────────────
 *
 * MODE A — Multi-pack (main SDLC lib, reads packs.config.json for agent routing):
 *   node dat-encoder.js --agents ../all-agents.md [--instructions ../instructions.md]
 *   Outputs: extension/dat/a7e2.bin, b3f9.bin, c1d4.bin, d2f8.bin, e5a1.bin
 *
 * MODE B — Single-pack (new agent lib as a single .bin, bypasses packs.config.json):
 *   node dat-encoder.js --input ../my-agents.md --pack-id my-pack \
 *                       --output ../extension/dat/xxxx.bin \
 *                       [--instructions ../my-instructions.md] \
 *                       [--namespace my-namespace]
 *
 *   --namespace  Optional. When set, embeds namespace into the .bin so agents
 *                register as @namespace.agentId instead of @sdlc-agents.agentId.
 *                Example: --namespace abpy → agents addressable as @abpy.abpy-analyzer
 *                Can also be set/overridden via product.config.json p4 field at runtime.
 *
 * KEY DERIVATION (MUST match licenseManager.ts deriveContentKey):
 *   SHA-256("content:" + buildSecretA + buildSecretB) → 32-byte AES-256-GCM key
 *   Deterministic from build secrets so runtime can re-derive without storing the key.
 */
'use strict';
const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');

// ── Load config ───────────────────────────────────────────────────────────────
const CFG_PATH   = path.join(__dirname, 'config.json');
const PACKS_PATH = path.join(__dirname, 'packs.config.json');
const DAT_DIR    = path.join(__dirname, '..', 'extension', 'dat');

if (!fs.existsSync(CFG_PATH)) {
  console.error('\nERROR: config.json not found.');
  console.error('Run: node init-config.js first\n');
  process.exit(1);
}

const cfg = JSON.parse(fs.readFileSync(CFG_PATH, 'utf-8'));

// ── Derive content key — MUST match licenseManager.ts deriveContentKey ────────
const K_CONTENT = crypto
  .createHash('sha256')
  .update('content:' + cfg.buildSecretA + cfg.buildSecretB)
  .digest();

const HMAC_KEY = Buffer.from(cfg.hmacKey, 'hex');
const MAGIC    = Buffer.from(cfg.magicBytes, 'hex');

// ── Parse CLI args ────────────────────────────────────────────────────────────
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--') && process.argv[i + 1]) {
    args[process.argv[i].slice(2)] = process.argv[++i];
  }
}

const isSinglePack = !!(args.input && args['pack-id'] && args.output);
const isMultiPack  = !!args.agents;

if (!isSinglePack && !isMultiPack) {
  console.error('\nUsage:');
  console.error('  Multi-pack:  node dat-encoder.js --agents <path> [--instructions <path>]');
  console.error('  Single-pack: node dat-encoder.js --input <path> --pack-id <id> --output <path>');
  console.error('               [--instructions <path>] [--namespace <ns>]');
  console.error('');
  console.error('  --namespace  Embed namespace into .bin so agents register as @namespace.agentId');
  console.error('               Can also be set via product.config.json p4 field at runtime.');
  process.exit(1);
}

console.log('\n╔═════════════════════════════════════════╗');
console.log('║  SDLC Agents — Dat Encoder               ║');
console.log('╚═════════════════════════════════════════╝\n');

// ── Read instructions (optional) ──────────────────────────────────────────────
const instrPath = args.instructions;
const instrRaw  = instrPath && fs.existsSync(instrPath)
  ? fs.readFileSync(instrPath, 'utf-8') : '';
if (instrPath && !instrRaw) console.warn(`  WARNING: instructions file not found: ${instrPath}`);
if (!instrRaw) console.log('  Note: No --instructions provided — agents will run without global instructions.\n');

// ═════════════════════════════════════════════════════════════════════════════
// MODE A — Multi-pack (packs.config.json driven, main SDLC lib)
// ═════════════════════════════════════════════════════════════════════════════
if (isMultiPack) {
  if (!fs.existsSync(PACKS_PATH)) { console.error(`ERROR: packs.config.json not found at ${PACKS_PATH}`); process.exit(1); }
  const agentsPath = args.agents;
  if (!fs.existsSync(agentsPath)) { console.error(`ERROR: agents file not found: ${agentsPath}`); process.exit(1); }

  const packs     = JSON.parse(fs.readFileSync(PACKS_PATH, 'utf-8'));
  const agentsRaw = fs.readFileSync(agentsPath, 'utf-8');

  console.log('Parsing agent definitions...');
  const agents = parseAgents(agentsRaw);
  console.log(`  Found ${agents.length} agent definitions\n`);
  if (agents.length === 0) { console.error('ERROR: No agents found. Check ## AGENT N headings with ```markdown blocks'); process.exit(1); }

  fs.mkdirSync(DAT_DIR, { recursive: true });
  console.log('Encoding packs...');

  for (const [packId, agentIds] of Object.entries(packs.packs)) {
    const packAgents = agentIds.map(id => {
      const a = agents.find(a => a.agentId === id);
      if (!a) console.warn(`  WARNING: Agent '${id}' in packs.config.json not found in agents file`);
      return a;
    }).filter(Boolean);

    if (packAgents.length === 0) { console.warn(`  WARNING: Pack '${packId}' has no matching agents — skipping`); continue; }

    const fileName = packs.packFiles?.[packId];
    if (!fileName) { console.warn(`  WARNING: No packFiles entry for '${packId}' — skipping`); continue; }

    // Mode A packs are SDLC packs — no namespace (they use productId prefix)
    const packData = { packId, agents: packAgents, instructions: instrRaw || undefined };
    const payload  = Buffer.from(JSON.stringify(packData), 'utf-8');
    const fileType = packs.fileTypes?.[packId] ?? 2;
    const bin      = buildBin(payload, fileType, K_CONTENT, HMAC_KEY, MAGIC);

    fs.writeFileSync(path.join(DAT_DIR, fileName), bin);
    const kb = (bin.length / 1024).toFixed(1);
    console.log(`  ${packId.padEnd(14)} → ${fileName}  (${kb} KB, ${packAgents.length} agents${instrRaw ? ', +instructions' : ''})`);
  }

  console.log('\n✓ All packs encoded successfully.\n');
  console.log('Next: run build.bat\n');
}

// ═════════════════════════════════════════════════════════════════════════════
// MODE B — Single-pack (agent lib, one bin file, optional namespace)
// ═════════════════════════════════════════════════════════════════════════════
if (isSinglePack) {
  const inputPath  = args.input;
  const packId     = args['pack-id'];
  const outputPath = args.output;
  const namespace  = args.namespace || undefined;   // ← NEW: embedded namespace

  if (!fs.existsSync(inputPath)) { console.error(`ERROR: input file not found: ${inputPath}`); process.exit(1); }

  const agentsRaw = fs.readFileSync(inputPath, 'utf-8');
  console.log(`Parsing agent definitions from ${path.basename(inputPath)}...`);
  const agents = parseAgents(agentsRaw);
  console.log(`  Found ${agents.length} agent definitions\n`);
  if (agents.length === 0) { console.error('ERROR: No agents found. Check ## AGENT N headings with ```markdown blocks'); process.exit(1); }

  if (namespace) {
    console.log(`  Namespace: @${namespace} (agents will be @${namespace}.<agentId>)`);
  } else {
    console.log('  Namespace: (not set — will use productId prefix from product.config.json p4 or default)');
  }

  // Embed namespace into the pack payload (runtime licenseManager.ts also injects from p4)
  const packData = {
    packId,
    ...(namespace ? { namespace } : {}),  // ← embedded in bin
    agents,
    instructions: instrRaw || undefined,
  };
  const payload  = Buffer.from(JSON.stringify(packData), 'utf-8');
  const bin      = buildBin(payload, 6, K_CONTENT, HMAC_KEY, MAGIC);

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, bin);

  const kb = (bin.length / 1024).toFixed(1);
  console.log(`\n✓ ${packId}  →  ${outputPath}  (${kb} KB, ${agents.length} agents${instrRaw ? ', +instructions' : ''}${namespace ? `, @${namespace}` : ''})`);
  console.log('\nNext steps:');
  console.log(`  1. Add to extension/product.config.json f1a2 array:`);
  console.log(`     { "p1": "${packId}", "p2": "${path.basename(outputPath)}", "p3": "${packId}"${namespace ? `, "p4": "${namespace}"` : ''} }`);
  console.log(`  2. Add agent display names to the g3h4 object`);
  console.log(`  3. Assign a license bit (index in f1a2 array, 0-based)`);
  console.log(`  4. Bump c5d6 version, then run build.bat\n`);
  if (namespace) {
    console.log(`  Agents available as: @${namespace}.<agentId>`);
    console.log(`  Example: @${namespace}.${agents[0]?.agentId}\n`);
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// HELPERS
// ═════════════════════════════════════════════════════════════════════════════

function parseAgents(raw) {
  const agents   = [];
  const sections = raw.split(/^## AGENT \d+[^\n]*/m).filter(s => s.trim().length > 0);
  for (const section of sections) {
    const codeMatch = section.match(/```markdown\s*\n([\s\S]*?)```/);
    if (!codeMatch) continue;
    const fmMatch = codeMatch[1].match(/^(---[\s\S]*?---)\n([\s\S]*)$/);
    if (!fmMatch) continue;
    const frontmatter = fmMatch[1];
    const body        = fmMatch[2].trim();
    const idMatch     = frontmatter.match(/^name:\s*(.+)$/m);
    if (!idMatch) continue;
    const agentId   = idMatch[1].trim();
    const descMatch = frontmatter.match(/^description:\s*[>|]?\s*\n?\s*(.+)$/m);
    const displayName = descMatch ? descMatch[1].trim().replace(/^>?\s*/, '') : agentId;
    agents.push({ agentId, displayName, frontmatter, body, shieldInjected: false });
  }
  return agents;
}

/**
 * Build encrypted .bin file.
 *
 * Layout:
 *   [0:4]   magic bytes  (4)
 *   [4:6]   version      (2)  0x0300
 *   [6:8]   file type    (2)
 *   [8:40]  HMAC-SHA256  (32) covers bytes [40..EOF]
 *   [40:56] AES nonce    (16) random, stored for decryption
 *   [56:60] lead noise len (4)
 *   [60:N]  lead noise
 *   [N:N+4] payload len  (4)
 *   [...]   AES-256-GCM ciphertext
 *   [...]   GCM auth tag (16)
 *   [...]   tail noise len (4)
 *   [...]   tail noise
 *   [...]   decoy block
 */
function buildBin(payload, fileType, kContent, hmacKey, magic) {
  const VERSION = Buffer.from([0x03, 0x00]);
  const FTYPE   = Buffer.alloc(2); FTYPE.writeUInt16BE(fileType, 0);
  const nonce   = crypto.randomBytes(16);

  const leadLen = 512 + Math.floor(Math.random() * 1537);
  const leadBuf = Buffer.alloc(4); leadBuf.writeUInt32BE(leadLen, 0);
  const lead    = crypto.randomBytes(leadLen);

  const cipher  = crypto.createCipheriv('aes-256-gcm', kContent, nonce);
  const enc     = Buffer.concat([cipher.update(payload), cipher.final()]);
  const authTag = cipher.getAuthTag();
  const plenBuf = Buffer.alloc(4); plenBuf.writeUInt32BE(enc.length, 0);

  const tailLen = 256 + Math.floor(Math.random() * 769);
  const tailBuf = Buffer.alloc(4); tailBuf.writeUInt32BE(tailLen, 0);
  const tail    = crypto.randomBytes(tailLen);

  const decoyMagic = Buffer.from([0xDE, 0xAD, 0xBE, 0xEF]);
  const decoyData  = Buffer.from(JSON.stringify({
    v: 2, ts: Date.now() - Math.floor(Math.random() * 1_000_000),
    checksum: crypto.randomBytes(16).toString('hex'),
    meta:     crypto.randomBytes(24).toString('base64'),
  }));
  const decoyLen = Buffer.alloc(4); decoyLen.writeUInt32BE(decoyData.length, 0);
  const decoy    = Buffer.concat([decoyMagic, decoyLen, decoyData]);

  const covered = Buffer.concat([nonce, leadBuf, lead, plenBuf, enc, authTag, tailBuf, tail, decoy]);
  const hmac    = crypto.createHmac('sha256', hmacKey).update(covered).digest();

  return Buffer.concat([magic, VERSION, FTYPE, hmac, covered]);
}
