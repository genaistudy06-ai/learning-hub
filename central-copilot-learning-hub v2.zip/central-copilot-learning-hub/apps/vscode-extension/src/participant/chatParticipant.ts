// ─── Copilot Chat Participant ─────────────────────────────────────────────────
import * as vscode from 'vscode';
import type { LearningHubClient } from '../services/apiClient';
import type { OfflineQueue } from '../offline/offlineQueue';
import { detectWorkspaceSignals, inferSkill } from '../services/workspaceDetector';
import type { Skill, VoteAction, SearchResult, Badge } from '../../../../shared/types';
import {
  DEFAULT_GITHUB_STRUCTURE,
  scaffoldGithubFolder,
  parseFolderStructureJson,
  formatScaffoldSummary,
} from '../services/githubFolderScaffolder';

const PARTICIPANT_ID = 'copilot-learning-hub.assistant';

type ChatHandler = Parameters<typeof vscode.chat.createChatParticipant>[1];

export function registerChatParticipant(
  context: vscode.ExtensionContext,
  client: LearningHubClient,
  queue: OfflineQueue
): vscode.Disposable {

  const participant = vscode.chat.createChatParticipant(
    PARTICIPANT_ID,
    createHandler(client, queue)
  );

  participant.iconPath = new vscode.ThemeIcon('book');
  context.subscriptions.push(participant);
  return participant;
}

function createHandler(client: LearningHubClient, queue: OfflineQueue): ChatHandler {
  return async (request, _ctx, stream, token) => {

    const signals   = await detectWorkspaceSignals();
    const skill     = inferSkill(signals);
    const config    = vscode.workspace.getConfiguration('copilotLearningHub');
    const userId    = config.get<string>('userId') ?? 'anonymous';
    const tenantId  = config.get<string>('tenantId') ?? undefined;
    const repoScope = signals.repoName;

    // ── /search ──────────────────────────────────────────────────────────────
    if (request.command === 'search' || (!request.command && request.prompt.toLowerCase().startsWith('search'))) {
      const query = request.command === 'search'
        ? request.prompt
        : request.prompt.replace(/^search\s+/i, '');

      if (!query) {
        stream.markdown('❓ Please provide a search query. Example: `@learning-hub /search angular lazy loading`');
        return;
      }

      stream.progress('🔍 Searching learning hub...');

      try {
        const { results } = await client.search({ query, skill, persona: skill, tenantId, repoScope });

        if (results.length === 0) {
          stream.markdown(`No learnings found for **"${query}"** in the **${skill}** index.\n\nTry a broader term or use \`/save\` to contribute a new one!`);
          return;
        }

        stream.markdown(`## 📚 Learning Hub Results — *${query}*\n`);

        for (const result of results) {
          renderSearchResult(stream, result);
        }
      } catch (err: any) {
        stream.markdown(`❌ Search failed: ${err.message}`);
      }

      return;
    }

    // ── /save ────────────────────────────────────────────────────────────────
    if (request.command === 'save') {
      const parts = request.prompt.split('|').map(p => p.trim());
      if (parts.length < 3) {
        stream.markdown([
          '**Save format:** `title | summary | solution text | tag1,tag2`',
          '',
          '**Example:**',
          '```',
          '@learning-hub /save Angular lazy loading fix | How to fix lazy module errors | Use loadChildren with arrow function | angular,routing',
          '```',
        ].join('\n'));
        return;
      }

      const [title, summary, solutionText, tagsRaw] = parts;
      const tags = tagsRaw ? tagsRaw.split(',').map(t => t.trim()) : [skill];

      stream.progress('💾 Saving learning...');

      const saveReq = {
        title, summary, solutionText, tags,
        skill, personaHints: [skill],
        authorId: userId,
        tenantId, repoScope,
      };

      try {
        const online = await client.healthCheck();
        if (!online && vscode.workspace.getConfiguration('copilotLearningHub').get('offlineMode')) {
          const queueId = await queue.enqueue(saveReq);
          stream.markdown(`📦 API offline — learning queued (ID: \`${queueId}\`). Will sync automatically.`);
          return;
        }

        const res = await client.saveLearning(saveReq);

        if (res.outcome === 'SECRET_REJECTED') {
          stream.markdown(`🔐 **Secret detected — learning NOT saved.**\n\nFound: ${res.secretFields?.join(', ')}\n\nPlease redact secrets and try again.`);
        } else if (res.outcome === 'DUPLICATE') {
          stream.markdown(`♻️ **Duplicate detected.** A similar learning already exists.\n\nUse \`/vote ${res.existingId} UPVOTE\` to confirm it's correct.`);
        } else {
          stream.markdown([
            `✅ **Learning saved!**`,
            `- **Outcome:** ${res.outcome}`,
            `- **Solution ID:** \`${res.solutionId}\``,
            `- **Cluster:** \`${res.clusterId}\``,
            `- **Skill:** ${skill}`,
            ``,
            `Use \`/vote ${res.solutionId} UPVOTE\` to endorse it!`,
          ].join('\n'));
        }
      } catch (err: any) {
        stream.markdown(`❌ Save failed: ${err.message}`);
      }

      return;
    }

    // ── /vote ─────────────────────────────────────────────────────────────────
    if (request.command === 'vote') {
      const parts = request.prompt.trim().split(/\s+/);
      const [solutionId, rawAction] = parts;
      const action = rawAction?.toUpperCase() as VoteAction;

      if (!solutionId || !['UPVOTE','DOWNVOTE','OUTDATED','DUPLICATE'].includes(action)) {
        stream.markdown([
          '**Vote format:** `@learning-hub /vote <solutionId> <action>`',
          '',
          'Actions: `UPVOTE` | `DOWNVOTE` | `OUTDATED` | `DUPLICATE`',
        ].join('\n'));
        return;
      }

      stream.progress('🗳️ Casting vote...');

      try {
        const res = await client.vote(solutionId, userId, action);
        stream.markdown(
          res.success
            ? `✅ Vote recorded! New community score: **${res.newScore.toFixed(1)}**`
            : `⚠️ ${res.message}`
        );
      } catch (err: any) {
        stream.markdown(`❌ Vote failed: ${err.message}`);
      }

      return;
    }

    // ── /scaffold ─────────────────────────────────────────────────────────────
    if (request.command === 'scaffold') {
      const workspaceFolders = vscode.workspace.workspaceFolders;
      if (!workspaceFolders?.length) {
        stream.markdown('❌ No workspace folder is open. Please open a project first.');
        return;
      }

      const workspaceRoot = workspaceFolders[0].uri;
      let structure = DEFAULT_GITHUB_STRUCTURE;

      // If the user passed JSON inline, parse it; otherwise fall back to the default template
      const rawPrompt = request.prompt.trim();
      if (rawPrompt) {
        const parsed = parseFolderStructureJson(rawPrompt);
        if (!parsed) {
          stream.markdown([
            '❌ **Invalid JSON.** The `/scaffold` command expects either:',
            '',
            '- **No arguments** — uses the built-in default `.github` template',
            '- **A JSON object** mapping relative paths to file contents:',
            '  ```json',
            '  {',
            '    "copilot-instructions.md": "# My Copilot Instructions\\n...",',
            '    "workflows/ci.yml": "name: CI\\non: [push]\\n..."',
            '  }',
            '  ```',
          ].join('\n'));
          return;
        }
        structure = parsed;
        stream.progress(`📂 Scaffolding custom .github structure (${Object.keys(structure).length} file(s))…`);
      } else {
        stream.progress(`📂 Scaffolding default .github template (${Object.keys(structure).length} file(s))…`);
      }

      const result = await scaffoldGithubFolder(workspaceRoot, structure, /* overwrite */ false);
      const summary = formatScaffoldSummary(result);

      const lines = [
        `## 📁 \`.github\` Scaffold Complete`,
        '',
        summary,
        '',
      ];

      if (result.created.length) {
        lines.push('**Created:**');
        result.created.forEach(f => {
          const rel = f.replace(workspaceRoot.fsPath, '').replace(/\\/g, '/');
          lines.push(`- \`${rel}\``);
        });
        lines.push('');
      }

      if (result.skipped.length) {
        lines.push(`**Skipped** (already exist — run the command palette command with *Overwrite* to replace them):`);
        result.skipped.forEach(f => {
          const rel = f.replace(workspaceRoot.fsPath, '').replace(/\\/g, '/');
          lines.push(`- \`${rel}\``);
        });
        lines.push('');
      }

      if (result.errors.length) {
        lines.push('**Errors:**');
        result.errors.forEach(e => lines.push(`- \`${e.file}\` — ${e.reason}`));
        lines.push('');
      }

      lines.push('> 💡 Edit the files to match your project\'s conventions, then commit them to your repo.');
      stream.markdown(lines.join('\n'));

      // Reveal in explorer
      if (result.created.length) {
        await vscode.commands.executeCommand('revealInExplorer',
          vscode.Uri.joinPath(workspaceRoot, '.github'));
      }

      return;
    }

    // ── /skill ────────────────────────────────────────────────────────────────
    if (request.command === 'skill') {
      stream.markdown(`🔍 **Auto-detected skill:** \`${skill}\`\n\nBased on:\n- Active file extension: \`${signals.activeFileExtension ?? 'none'}\`\n- Repo: \`${signals.repoName ?? 'unknown'}\``);
      return;
    }

    // ── /help / default ───────────────────────────────────────────────────────
    stream.markdown([
      '## 📚 Central Copilot Learning Hub',
      '',
      '| Command | Description |',
      '|---------|-------------|',
      '| `/search <query>` | Fuzzy search learnings for your skill |',
      '| `/save title \\| summary \\| solution \\| tags` | Save a new learning |',
      '| `/vote <id> <UPVOTE\\|DOWNVOTE\\|OUTDATED\\|DUPLICATE>` | Vote on a learning |',
      '| `/scaffold [json]` | Create `.github` folder structure in this project |',
      '| `/skill` | Show auto-detected skill from workspace |',
      '',
      `**Current skill:** \`${skill}\` | **User:** \`${userId}\``,
      `**Offline queue:** ${queue.count()} pending item(s)`,
    ].join('\n'));
  };
}

function badgeEmoji(badge: Badge): string {
  const map: Record<Badge, string> = {
    'New': '🆕',
    'Highly Trusted': '🏆',
    'Trusted': '✅',
    'Mixed Reviews': '⚖️',
    'Low Confidence': '⚠️',
  };
  return map[badge] ?? '📌';
}

function renderSearchResult(stream: vscode.ChatResponseStream, result: SearchResult): void {
  stream.markdown(`### 📂 ${result.cluster.description}`);

  for (const sol of result.solutions.slice(0, 3)) {
    stream.markdown([
      `**${badgeEmoji(sol.badge)} ${sol.title}** — ${sol.badge}`,
      `> ${sol.summary}`,
      ``,
      `\`\`\``,
      sol.solutionText.slice(0, 600),
      `\`\`\``,
      `*Score: ${sol.communityScore.toFixed(1)} | 👍 ${sol.upvotes} 👎 ${sol.downvotes} | 🔁 ${sol.retrievalCount} retrievals*`,
      `\`/vote ${sol.id} UPVOTE\` · \`/vote ${sol.id} DOWNVOTE\` · \`/vote ${sol.id} OUTDATED\``,
      `---`,
    ].join('\n'));
  }
}
