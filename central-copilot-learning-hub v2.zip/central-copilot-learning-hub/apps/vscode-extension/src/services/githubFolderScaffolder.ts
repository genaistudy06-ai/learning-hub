// ─── GitHub Folder Scaffolder ──────────────────────────────────────────────────
//
// Accepts a flat map of  { "relative/path/file.ext": "file content" }
// and writes every entry under <workspaceRoot>/.github/
//
// Example input:
//   {
//     "copilot-instructions.md": "# Copilot Instructions\n...",
//     "ISSUE_TEMPLATE/bug_report.md": "---\nname: Bug Report\n---\n",
//     "workflows/ci.yml": "name: CI\n..."
//   }
//
import * as vscode from 'vscode';
import * as path from 'path';

export type FolderStructure = Record<string, string>; // relativePath → fileContent

// ── Default dummy structure ──────────────────────────────────────────────────
// Replace the values with your real content; the keys drive the file tree.
export const DEFAULT_GITHUB_STRUCTURE: FolderStructure = {

  // Copilot repo-level instructions
  'copilot-instructions.md': [
    '# Copilot Instructions',
    '',
    '## Project Overview',
    'Describe what this repo does so Copilot understands the context.',
    '',
    '## Coding Conventions',
    '- Use TypeScript strict mode',
    '- Prefer `const` over `let`',
    '- Name files in kebab-case',
    '',
    '## Testing Guidelines',
    '- All new features must include unit tests',
    '- Use Jest + Testing Library',
    '',
    '## Commit Message Format',
    '`<type>(<scope>): <short summary>`',
    'Types: feat | fix | docs | refactor | test | chore',
  ].join('\n'),

  // Pull-request template
  'PULL_REQUEST_TEMPLATE/pull_request_template.md': [
    '## What does this PR do?',
    '',
    '<!-- Briefly describe the change and its motivation -->',
    '',
    '## Type of change',
    '- [ ] Bug fix',
    '- [ ] New feature',
    '- [ ] Refactor / tech-debt',
    '- [ ] Documentation update',
    '',
    '## Checklist',
    '- [ ] Unit tests added / updated',
    '- [ ] No new linting errors',
    '- [ ] Linked to an issue (closes #)',
  ].join('\n'),

  // Bug-report issue template
  'ISSUE_TEMPLATE/bug_report.md': [
    '---',
    'name: Bug Report',
    'about: Something is broken',
    'labels: bug',
    '---',
    '',
    '## Describe the bug',
    '',
    '## Steps to reproduce',
    '1.',
    '2.',
    '',
    '## Expected behaviour',
    '',
    '## Actual behaviour',
    '',
    '## Environment',
    '- OS:',
    '- Node version:',
    '- Extension version:',
  ].join('\n'),

  // Feature-request issue template
  'ISSUE_TEMPLATE/feature_request.md': [
    '---',
    'name: Feature Request',
    'about: Suggest an idea',
    'labels: enhancement',
    '---',
    '',
    '## Problem to solve',
    '',
    '## Proposed solution',
    '',
    '## Alternatives considered',
    '',
    '## Additional context',
  ].join('\n'),

  // Basic CI workflow (GitHub Actions)
  'workflows/ci.yml': [
    'name: CI',
    '',
    'on:',
    '  push:',
    '    branches: [main, develop]',
    '  pull_request:',
    '    branches: [main]',
    '',
    'jobs:',
    '  build-and-test:',
    '    runs-on: ubuntu-latest',
    '    steps:',
    '      - uses: actions/checkout@v4',
    '      - uses: actions/setup-node@v4',
    '        with:',
    '          node-version: 20',
    '          cache: npm',
    '      - run: npm ci',
    '      - run: npm run lint',
    '      - run: npm test',
  ].join('\n'),

  // CODEOWNERS
  'CODEOWNERS': [
    '# Global owner — review required on every PR',
    '* @your-org/your-team',
    '',
    '# Workflows only reviewed by DevOps',
    '.github/workflows/ @your-org/devops',
  ].join('\n'),
};

// ── Core scaffolding logic ───────────────────────────────────────────────────

export interface ScaffoldResult {
  created: string[];
  skipped: string[];
  errors:  { file: string; reason: string }[];
}

/**
 * Write `structure` into `<workspaceRoot>/.github/`.
 *
 * Existing files are skipped (not overwritten) unless `overwrite` is true.
 */
export async function scaffoldGithubFolder(
  workspaceRoot: vscode.Uri,
  structure: FolderStructure,
  overwrite = false
): Promise<ScaffoldResult> {
  const result: ScaffoldResult = { created: [], skipped: [], errors: [] };

  for (const [relativePath, content] of Object.entries(structure)) {
    // Normalise separators and prevent path traversal
    const safePath = relativePath.replace(/\\/g, '/').replace(/^\/+/, '');
    if (safePath.includes('..')) {
      result.errors.push({ file: relativePath, reason: 'Path traversal detected — skipped' });
      continue;
    }

    const fileUri = vscode.Uri.joinPath(workspaceRoot, '.github', safePath);

    // Skip if it already exists (unless overwrite requested)
    if (!overwrite) {
      try {
        await vscode.workspace.fs.stat(fileUri);
        result.skipped.push(fileUri.fsPath);
        continue;
      } catch {
        // stat throws when file doesn't exist — that's fine, proceed to write
      }
    }

    try {
      // Ensure parent directory exists
      const parentUri = vscode.Uri.joinPath(fileUri, '..');
      await vscode.workspace.fs.createDirectory(parentUri);

      // Write file
      const encoded = new TextEncoder().encode(content);
      await vscode.workspace.fs.writeFile(fileUri, encoded);
      result.created.push(fileUri.fsPath);
    } catch (err: any) {
      result.errors.push({ file: relativePath, reason: err.message ?? String(err) });
    }
  }

  return result;
}

/**
 * Parse a JSON string supplied by the user into a FolderStructure.
 * Returns `null` and shows an error message on parse failure.
 */
export function parseFolderStructureJson(raw: string): FolderStructure | null {
  try {
    const parsed = JSON.parse(raw);
    if (typeof parsed !== 'object' || Array.isArray(parsed) || parsed === null) {
      vscode.window.showErrorMessage('Folder structure must be a JSON object ({ "path": "content", ... })');
      return null;
    }
    return parsed as FolderStructure;
  } catch {
    vscode.window.showErrorMessage('Invalid JSON — please check your folder structure input.');
    return null;
  }
}

/** Build a human-readable summary of a ScaffoldResult for notifications. */
export function formatScaffoldSummary(result: ScaffoldResult): string {
  const lines: string[] = [];
  if (result.created.length)  lines.push(`✅ Created ${result.created.length} file(s)`);
  if (result.skipped.length)  lines.push(`⏭️ Skipped ${result.skipped.length} existing file(s)`);
  if (result.errors.length)   lines.push(`❌ ${result.errors.length} error(s)`);
  return lines.join('  |  ') || 'Nothing to do.';
}
