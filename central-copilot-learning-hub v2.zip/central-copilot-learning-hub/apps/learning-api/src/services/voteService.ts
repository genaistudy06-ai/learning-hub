// ─── Vote Service ─────────────────────────────────────────────────────────────
import type { VoteAction, VoteRecord } from '../../../../shared/types.js';
import { computeCommunityScore, computeStatus } from './badgeEngine.js';
import { defaultStorage } from '../storage/storageFactory.js';

const VOTE_WEIGHTS: Record<VoteAction, number> = {
  UPVOTE:    1.0,
  DOWNVOTE:  1.0,
  OUTDATED:  1.2,
  DUPLICATE: 0.8,
};

export async function castVote(
  solutionId: string,
  userId: string,
  action: VoteAction,
  storage = defaultStorage
): Promise<{ success: boolean; newScore: number; message: string }> {

  const solution = await storage.getSolution(solutionId);
  if (!solution) return { success: false, newScore: 0, message: 'Solution not found' };

  // Load or init vote record
  let record: VoteRecord = await storage.getVoteRecord(solutionId) ?? {
    solutionId,
    votes: [],
  };

  // One vote per user per solution
  const existingIdx = record.votes.findIndex(v => v.userId === userId);
  if (existingIdx !== -1) {
    const existing = record.votes[existingIdx];
    if (existing.action === action) {
      return { success: false, newScore: solution.communityScore, message: 'Already voted with this action' };
    }
    // Change vote
    record.votes[existingIdx] = {
      userId,
      action,
      weight: VOTE_WEIGHTS[action],
      timestamp: new Date().toISOString(),
    };
  } else {
    record.votes.push({
      userId,
      action,
      weight: VOTE_WEIGHTS[action],
      timestamp: new Date().toISOString(),
    });
  }

  await storage.saveVoteRecord(record);

  // Recompute solution scores from all votes
  let upvotes = 0, downvotes = 0;
  for (const v of record.votes) {
    if (v.action === 'UPVOTE') upvotes += v.weight;
    else downvotes += v.weight;
  }

  solution.upvotes = upvotes;
  solution.downvotes = downvotes;
  solution.communityScore = computeCommunityScore({ upvotes, downvotes, retrievalCount: solution.retrievalCount });
  solution.status = computeStatus({ upvotes, downvotes, retrievalCount: solution.retrievalCount }, solution.retrievalCount);
  solution.updatedAt = new Date().toISOString();
  await storage.saveSolution(solution);

  // Sync index entry
  const index = await storage.getSkillIndex(solution.skill);
  if (index) {
    const entry = index.learnings.find(e => e.id === solutionId);
    if (entry) {
      entry.upvotes = upvotes;
      entry.downvotes = downvotes;
      entry.communityScore = solution.communityScore;
      entry.status = solution.status;
      entry.updatedAt = solution.updatedAt;
      await storage.saveSkillIndex(index);
    }
  }

  return { success: true, newScore: solution.communityScore, message: `Vote recorded: ${action}` };
}
