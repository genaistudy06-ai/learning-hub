// ─── Secret Scanner ───────────────────────────────────────────────────────────
// Scans solution text for secrets/credentials before persisting

const SECRET_PATTERNS: Array<{ name: string; pattern: RegExp }> = [
  { name: 'AWS Access Key',       pattern: /AKIA[0-9A-Z]{16}/g },
  { name: 'AWS Secret Key',       pattern: /(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])/g },
  { name: 'GitHub Token',         pattern: /ghp_[0-9a-zA-Z]{36}/g },
  { name: 'GitHub OAuth',         pattern: /gho_[0-9a-zA-Z]{36}/g },
  { name: 'Slack Token',          pattern: /xox[baprs]-([0-9a-zA-Z]{10,48})/g },
  { name: 'Bearer Token',         pattern: /Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi },
  { name: 'Private Key',          pattern: /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/g },
  { name: 'Generic Password',     pattern: /(?:password|passwd|pwd)\s*[:=]\s*['"]?[^\s'"]{6,}/gi },
  { name: 'Generic Secret',       pattern: /(?:secret|api_key|apikey|api-key)\s*[:=]\s*['"]?[A-Za-z0-9_\-]{8,}/gi },
  { name: 'Connection String',    pattern: /(?:mongodb|postgres|mysql|redis):\/\/[^\s'"]+/gi },
  { name: 'Basic Auth URL',       pattern: /https?:\/\/[^:]+:[^@]+@[^\s/]+/gi },
  { name: 'JWT Token',            pattern: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g },
  { name: 'IP Address (private)', pattern: /\b(?:10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.)\d{1,3}\.\d{1,3}\b/g },
];

export interface ScanResult {
  clean: boolean;
  findings: Array<{ name: string; count: number }>;
}

export function scanForSecrets(text: string): ScanResult {
  const findings: Array<{ name: string; count: number }> = [];

  for (const { name, pattern } of SECRET_PATTERNS) {
    const matches = text.match(pattern);
    if (matches && matches.length > 0) {
      findings.push({ name, count: matches.length });
    }
  }

  return { clean: findings.length === 0, findings };
}

export function redactSecrets(text: string): string {
  let redacted = text;
  for (const { pattern } of SECRET_PATTERNS) {
    redacted = redacted.replace(pattern, '[REDACTED]');
  }
  return redacted;
}
