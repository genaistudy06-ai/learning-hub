// ─── API Client ───────────────────────────────────────────────────────────────
import type {
  SaveRequest, SaveResponse, SearchRequest, SearchResult,
  VoteAction, AnalyticsSnapshot, Skill
} from '../../../../shared/types';

export class LearningHubClient {
  private baseUrl: string;
  private apiKey: string;

  constructor(baseUrl: string, apiKey = '') {
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.apiKey = apiKey;
  }

  private async fetch<T>(
    path: string,
    options: RequestInit = {}
  ): Promise<T> {
    const res = await fetch(`${this.baseUrl}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(this.apiKey ? { 'x-api-key': this.apiKey } : {}),
        ...(options.headers ?? {}),
      },
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`API ${res.status}: ${body}`);
    }

    return res.json() as Promise<T>;
  }

  async saveLearning(req: SaveRequest): Promise<SaveResponse> {
    return this.fetch('/learnings', {
      method: 'POST',
      body: JSON.stringify(req),
    });
  }

  async search(req: SearchRequest): Promise<{ results: SearchResult[]; count: number }> {
    const params = new URLSearchParams({
      query:   req.query,
      skill:   req.skill,
      persona: req.persona,
      ...(req.limit     ? { limit:     String(req.limit) }     : {}),
      ...(req.tenantId  ? { tenantId:  req.tenantId }          : {}),
      ...(req.repoScope ? { repoScope: req.repoScope }         : {}),
    });
    return this.fetch(`/learnings/search?${params}`);
  }

  async vote(solutionId: string, userId: string, action: VoteAction): Promise<{ success: boolean; newScore: number; message: string }> {
    return this.fetch(`/learnings/${solutionId}/vote`, {
      method: 'POST',
      body: JSON.stringify({ userId, action }),
    });
  }

  async getAnalytics(skill?: Skill): Promise<AnalyticsSnapshot | { snapshots: AnalyticsSnapshot[] }> {
    return this.fetch(skill ? `/analytics/${skill}` : '/analytics');
  }

  async healthCheck(): Promise<boolean> {
    try {
      await this.fetch('/health'.replace('/api/v1', ''));
      return true;
    } catch {
      return false;
    }
  }
}
