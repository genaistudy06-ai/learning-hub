#!/usr/bin/env node
/**
 * generate-keys.js — Generates RSA-4096 signing key pair.
 * Uses Node.js built-in crypto — NO OpenSSL installation required.
 *
 * Run: node generate-keys.js
 * Outputs: signing-key.pem (private) and signing-key.pub (public)
 */
'use strict';
const crypto   = require('crypto');
const fs       = require('fs');
const path     = require('path');
const readline = require('readline');

const PRIV_PATH = path.join(__dirname, 'signing-key.pem');
const PUB_PATH  = path.join(__dirname, 'signing-key.pub');

// Check if keys already exist
if (fs.existsSync(PRIV_PATH)) {
  console.log('\n⚠  signing-key.pem already exists.');
  console.log('   Delete it manually if you want to regenerate.');
  console.log('   WARNING: Regenerating invalidates existing extension signatures.\n');
  process.exit(0);
}

console.log('\n╔══════════════════════════════════════════╗');
console.log('║   SDLC Agents — Key Generator            ║');
console.log('║   Node.js built-in crypto (no OpenSSL)   ║');
console.log('╚══════════════════════════════════════════╝\n');
console.log('You will set a signing password that protects your private key.');
console.log('You will enter this password every time you run build.bat.\n');

// Prompt for password (hidden input)
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function askPassword(prompt, callback) {
  if (process.stdin.isTTY) {
    // Hide characters on real terminals
    process.stdout.write(prompt);
    process.stdin.setRawMode(true);
    process.stdin.resume();
    let pwd = '';
    process.stdin.on('data', function handler(ch) {
      const c = ch.toString();
      if (c === '\n' || c === '\r') {
        process.stdin.setRawMode(false);
        process.stdin.removeListener('data', handler);
        process.stdout.write('\n');
        callback(pwd);
      } else if (c === '\u0003') {        // Ctrl+C
        process.stdout.write('\n');
        process.exit(0);
      } else if (c === '\u007f' || c === '\b') {  // Backspace
        if (pwd.length > 0) { pwd = pwd.slice(0, -1); process.stdout.write('\b \b'); }
      } else {
        pwd += c;
        process.stdout.write('*');
      }
    });
  } else {
    // Fallback for non-TTY (e.g. piped input)
    rl.question(prompt, callback);
  }
}

askPassword('Choose a signing password: ', (pass1) => {
  if (pass1.length < 8) {
    console.log('\nERROR: Password must be at least 8 characters. Run again.\n');
    process.exit(1);
  }
  askPassword('Confirm password:         ', (pass2) => {
    rl.close();

    if (pass1 !== pass2) {
      console.log('\nERROR: Passwords do not match. Run again.\n');
      process.exit(1);
    }

    console.log('\nGenerating RSA-4096 key pair...');
    console.log('This takes 10–30 seconds — this is normal.\n');

    try {
      const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
        modulusLength: 4096,
        privateKeyEncoding: {
          type:       'pkcs8',
          format:     'pem',
          cipher:     'aes-256-cbc',
          passphrase: pass1,
        },
        publicKeyEncoding: {
          type:   'spki',
          format: 'pem',
        },
      });

      fs.writeFileSync(PRIV_PATH, privateKey,  { mode: 0o600 });
      fs.writeFileSync(PUB_PATH,  publicKey);

      console.log('✓ signing-key.pem saved  ← PRIVATE — never share, never commit');
      console.log('✓ signing-key.pub saved  ← Public  — embedded in extension');
      console.log('\n══════════════════════════════════════════════════════');
      console.log('IMPORTANT: Remember your signing password.');
      console.log('You will enter it every time build.bat runs sign-build.js.');
      console.log('If you forget it, delete signing-key.pem and run this again');
      console.log('(you will also need to rebuild and redistribute the VSIX).');
      console.log('══════════════════════════════════════════════════════');
      console.log('\nNext: run test-crypto.js then build.bat\n');

    } catch (err) {
      console.error('\nERROR generating key pair:', err.message, '\n');
      process.exit(1);
    }
  });
});
