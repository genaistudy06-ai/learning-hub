// ─── Offline Queue ────────────────────────────────────────────────────────────
import * as vscode from 'vscode';
import { randomUUID } from 'crypto';
import type { OfflineQueueItem, SaveRequest } from '../../../../shared/types';
import type { LearningHubClient } from '../services/apiClient';

const QUEUE_KEY = 'copilotLearningHub.offlineQueue';
const MAX_RETRIES = 5;
const RETRY_DELAY_MS = 30_000; // 30s

export class OfflineQueue {
  private context: vscode.ExtensionContext;
  private client: LearningHubClient;
  private timer: NodeJS.Timeout | undefined;

  constructor(context: vscode.ExtensionContext, client: LearningHubClient) {
    this.context = context;
    this.client = client;
  }

  private getQueue(): OfflineQueueItem[] {
    return this.context.globalState.get<OfflineQueueItem[]>(QUEUE_KEY) ?? [];
  }

  private async setQueue(queue: OfflineQueueItem[]): Promise<void> {
    await this.context.globalState.update(QUEUE_KEY, queue);
  }

  async enqueue(learning: SaveRequest): Promise<string> {
    const item: OfflineQueueItem = {
      id: randomUUID(),
      learning,
      status: 'PENDING',
      retryCount: 0,
      createdAt: new Date().toISOString(),
    };
    const queue = this.getQueue();
    queue.push(item);
    await this.setQueue(queue);
    vscode.window.showInformationMessage(
      `📦 Learning queued offline (${queue.length} pending). Will sync when online.`
    );
    return item.id;
  }

  async sync(): Promise<{ synced: number; failed: number }> {
    const queue = this.getQueue();
    let synced = 0;
    let failed = 0;

    for (const item of queue) {
      if (item.status === 'FAILED' && item.retryCount >= MAX_RETRIES) {
        failed++;
        continue;
      }

      item.status = 'SYNCING';
      item.lastAttemptAt = new Date().toISOString();

      try {
        await this.client.saveLearning(item.learning);
        item.status = 'PENDING'; // mark for removal
        synced++;
      } catch {
        item.retryCount++;
        item.status = item.retryCount >= MAX_RETRIES ? 'FAILED' : 'PENDING';
        failed++;
      }
    }

    // Remove successfully synced items
    const remaining = queue.filter(i => i.status !== 'PENDING' || i.retryCount > 0);
    await this.setQueue(remaining);

    return { synced, failed };
  }

  startAutoSync(): void {
    this.stopAutoSync();
    this.timer = setInterval(async () => {
      const online = await this.client.healthCheck();
      if (!online) return;
      const { synced } = await this.sync();
      if (synced > 0) {
        vscode.window.showInformationMessage(`✅ Synced ${synced} offline learning(s) to hub.`);
      }
    }, RETRY_DELAY_MS);
  }

  stopAutoSync(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = undefined;
    }
  }

  count(): number {
    return this.getQueue().filter(i => i.status !== 'FAILED').length;
  }
}
