// licenseManager.ts — Code-only activation. No idx.bin. No file import.
// Code format:  PREFIX-MMMMMMMM-EEEEFFFF-SSSSSSSSSSSS
//   PREFIX  = accessCodePrefix from config (e.g. "SDLC")
//   MMMM    = first 8 hex of SHA256(machineId + buildSecret)
//   EEEE    = expiry: days-since-epoch in base36, 4 chars, zero-padded
//   FFFF    = feature bitmask in hex, 4 chars (16 bits = up to 16 packs)
//   SSSS    = first 12 hex of HMAC-SHA256(buildSecrets, M+E+F) — tamper proof
//
// Content key for .bin decryption is derived at runtime:
//   SHA-256("content:" + buildSecretA + buildSecretB) → 32-byte AES-256-GCM key
//   Must match dat-encoder.js K_CONTENT derivation exactly.
//   Never stored anywhere. Re-derived on every activation.

import * as vscode from 'vscode';
import * as crypto  from 'crypto';
import * as fs      from 'fs';
import * as path    from 'path';
import {
  ActivationState, ExpiryWarningLevel,
  ParsedLicenseCode, LicenseFeatures, LicenseValidationResult,
  FileVerificationResult, AgentPack, ProductConfig, AgentPackConfig,
} from './types';

// ── Binary file layout (agent pack .bin files — unchanged) ────────────────────
// [0:4]   magic bytes  (4)
// [4:6]   version      (2)
// [6:8]   file type    (2)
// [8:40]  HMAC-SHA256  (32) — covers bytes [40..EOF]
// [40:56] AES nonce    (16)
// [56..]  noise + payload + tag + noise + decoy

const HMAC_START        = 8;
const DATA_START        = 40;
const CONTENT_NONCE_OFF = 40;

const SECRET_KEY  = 'sdlc.code';
const LV_KEY      = 'sdlc.lv';
const WARN_DAYS   = 14;
const URGENT_DAYS = 3;
const GRACE_HOURS = 48;

// ── Feature bit positions (index = bit position) ──────────────────────────────
// Bit 0 = pack index 0 (core), bit 1 = pack index 1 (engineering), etc.
// Bit 14 = selfLearning, Bit 15 = customStandards
const SELF_LEARNING_BIT    = 14;
const CUSTOM_STANDARDS_BIT = 15;

declare const __BUILD_SECRET_A__: string;
declare const __IS_PRODUCTION__:  boolean;

export class LicenseManager {
  private readonly ctx:     vscode.ExtensionContext;
  private readonly cfg:     ProductConfig;
  private readonly extPath: string;
  private readonly storage: string;
  private readonly magic:   Buffer;
  private readonly hmacKey: Buffer;
  private readonly sigKey:  Buffer;

  constructor(ctx: vscode.ExtensionContext, cfg: ProductConfig) {
    this.ctx     = ctx;
    this.cfg     = cfg;
    this.extPath = ctx.extensionPath;
    this.storage = ctx.globalStorageUri.fsPath;
    fs.mkdirSync(this.storage, { recursive: true });

    const bA = __BUILD_SECRET_A__;
    const _f1 = Buffer.from('706172744131', 'hex').toString(); // ← REPLACE after init-config.js
    const _f2 = Buffer.from('706172744132', 'hex').toString(); // ← REPLACE
    const _f3 = Buffer.from('706172744133', 'hex').toString(); // ← REPLACE
    const _f4 = Buffer.from('706172744134', 'hex').toString(); // ← REPLACE
    const bB  = _f1 + _f2 + _f3 + _f4;

    this.magic   = crypto.createHash('sha256').update('hdr'  + bA      ).digest().slice(0, 4);
    this.hmacKey = crypto.createHash('sha256').update('hmac' + bA + bB ).digest();
    this.sigKey  = crypto.createHash('sha256').update('sig'  + bA + bB ).digest();
  }

  // ── Extension file verification (unchanged) ───────────────────────────────
  async verifyExtensionFiles(): Promise<FileVerificationResult> {
    const sigPath = path.join(this.extPath, 'keys', 'sig.bin');
    const pkPath  = path.join(this.extPath, 'keys', 'pk.bin');

    if (!fs.existsSync(sigPath) || !fs.existsSync(pkPath)) {
      return __IS_PRODUCTION__
        ? { valid: false, failed: 'Signature files missing' }
        : { valid: true };
    }
    const sig = fs.readFileSync(sigPath);
    if (sig.length <= 1) {
      return __IS_PRODUCTION__
        ? { valid: false, failed: 'Signature not generated — run sign-build.js' }
        : { valid: true };
    }
    try {
      const manifest = await this.buildFileManifest();
      const json     = JSON.stringify(Object.fromEntries(Object.entries(manifest).sort()));
      const pkDer    = fs.readFileSync(pkPath);
      const pubKey   = crypto.createPublicKey({ key: pkDer, format: 'der', type: 'spki' });
      const v        = crypto.createVerify('RSA-SHA256');
      v.update(json, 'utf-8');
      return v.verify(pubKey, sig)
        ? { valid: true }
        : { valid: false, failed: 'Signature mismatch — possible tampering' };
    } catch (e) {
      return { valid: false, failed: String(e) };
    }
  }

  private async buildFileManifest(): Promise<Record<string, string>> {
    const result: Record<string, string> = {};
    const files = ['dist/extension.js', 'product.config.json',
                   ...this.cfg.agentPacks.map(p => `dat/${p.p2}`)];
    for (const rel of files) {
      const abs = path.join(this.extPath, rel);
      if (fs.existsSync(abs)) {
        result[rel.replace(/\\/g, '/')] =
          crypto.createHash('sha256').update(fs.readFileSync(abs)).digest('hex');
      }
    }
    return result;
  }

  // ── Code-only validation ──────────────────────────────────────────────────
  async validateCode(code: string, machineId: string): Promise<LicenseValidationResult> {
    const parsed = this.parseCode(code);
    if (!parsed) {
      return { valid: false, state: ActivationState.BLOCKED_INVALID };
    }

    // 1. Verify HMAC signature (tamper detection)
    if (!this.verifyCodeSignature(parsed)) {
      return { valid: false, state: ActivationState.BLOCKED_TAMPERED };
    }

    // 2. Machine fingerprint check
    const expectedMachineHash = crypto
      .createHash('sha256')
      .update(machineId + __BUILD_SECRET_A__)
      .digest('hex')
      .slice(0, 8)
      .toUpperCase();

    if (parsed.machineHash !== expectedMachineHash) {
      return { valid: false, state: ActivationState.BLOCKED_MACHINE };
    }

    // 3. Clock integrity
    const clockFail = this.checkClock(parsed);
    if (clockFail) return { valid: false, state: clockFail };

    // 4. Expiry
    const expiryLevel   = this.calcExpiry(parsed);
    const daysRemaining = Math.floor((parsed.expiresAt.getTime() - Date.now()) / 86_400_000);
    if (expiryLevel === ExpiryWarningLevel.EXPIRED) {
      const gracePassed = daysRemaining < -(GRACE_HOURS / 24);
      if (gracePassed) return { valid: false, state: ActivationState.BLOCKED_EXPIRED };
    }

    // 5. Decode features from bitmask
    const features = this.decodeFeatures(parsed.featureBits);

    return { valid: true, state: ActivationState.ACTIVE, features, expiryLevel, daysRemaining };
  }

  // ── Parse code string → structured object ─────────────────────────────────
  private parseCode(code: string): ParsedLicenseCode | null {
    try {
      const prefix = this.cfg.accessCodePrefix;
      const upper  = code.toUpperCase().trim();

      // Format: PREFIX-MMMMMMMM-EEEEFFFF-SSSSSSSSSSSS
      const pattern = new RegExp(`^${prefix}-([A-F0-9]{8})-([A-F0-9]{4})([A-F0-9]{4})-([A-F0-9]{12})$`);
      const match   = upper.match(pattern);
      if (!match) return null;

      const [, machineHash, expiryB36Part, featureHex, signature] = match;

      // expiryB36Part is 4 hex chars here — but we store expiry as days-since-epoch in base36
      // EEEE segment: 4 base-36 chars → max value 36^4 - 1 = 1,679,615 days (~4600 years)
      // We re-encode the segment as hex in the regex for simplicity — actual encoding below
      const expiryDays   = parseInt(expiryB36Part, 16);
      const featureBits  = parseInt(featureHex, 16);
      const expiresAt    = new Date(expiryDays * 24 * 60 * 60 * 1000);

      return { raw: upper, machineHash, expiryDays, featureBits, signature, expiresAt };
    } catch {
      return null;
    }
  }

  // ── Verify HMAC signature in code ─────────────────────────────────────────
  private verifyCodeSignature(parsed: ParsedLicenseCode): boolean {
    const payload = parsed.machineHash
      + parsed.expiryDays.toString(16).toUpperCase().padStart(4, '0')
      + parsed.featureBits.toString(16).toUpperCase().padStart(4, '0');
    const expected = crypto
      .createHmac('sha256', this.sigKey)
      .update(payload)
      .digest('hex')
      .slice(0, 12)
      .toUpperCase();
    return crypto.timingSafeEqual(
      Buffer.from(parsed.signature),
      Buffer.from(expected),
    );
  }

  // ── Decode feature bitmask → LicenseFeatures ─────────────────────────────
  private decodeFeatures(bits: number): LicenseFeatures {
    const agentPacks: string[] = [];
    this.cfg.agentPacks.forEach((pack, idx) => {
      if (bits & (1 << idx)) agentPacks.push(pack.p1);
    });
    return {
      agentPacks,
      selfLearning:    !!(bits & (1 << SELF_LEARNING_BIT)),
      customStandards: !!(bits & (1 << CUSTOM_STANDARDS_BIT)),
      maxAgents:       agentPacks.length * 10, // approximate
    };
  }

  // ── Derive content key for .bin decryption ────────────────────────────────
  // Key = SHA-256("content:" + buildSecretA + buildSecretB) — 32 bytes.
  // MUST match dat-encoder.js K_CONTENT derivation exactly.
  // Does NOT use code or machineId — those control access (license validation),
  // not encryption. The .bin files' security comes from the build secrets never
  // leaving the developer environment.
  private deriveContentKey(): Buffer {
    const bA = __BUILD_SECRET_A__;
    const _f1 = Buffer.from('706172744131', 'hex').toString(); // ← REPLACE after init-config.js
    const _f2 = Buffer.from('706172744132', 'hex').toString(); // ← REPLACE
    const _f3 = Buffer.from('706172744133', 'hex').toString(); // ← REPLACE
    const _f4 = Buffer.from('706172744134', 'hex').toString(); // ← REPLACE
    const bB  = _f1 + _f2 + _f3 + _f4;
    return crypto.createHash('sha256').update('content:' + bA + bB).digest();
  }

  // ── Decrypt agent packs ───────────────────────────────────────────────────
  async decryptAgentPacks(_code: string, _machineId: string, features: LicenseFeatures): Promise<AgentPack[]> {
    const packs: AgentPack[] = [];

    for (const pc of this.cfg.agentPacks) {
      if (!features.agentPacks.includes(pc.p1)) continue;

      const binPath = path.join(this.extPath, 'dat', pc.p2);
      if (!fs.existsSync(binPath)) continue;

      const raw = fs.readFileSync(binPath);
      if (raw.length < 100) continue; // placeholder/stub guard — skip unencoded stubs

      if (!raw.slice(0, 4).equals(this.magic))  throw new Error(`Bad magic: ${pc.p2}`);
      if (!this.verifyHmac(raw))                throw new Error(`HMAC fail: ${pc.p2}`);

      const kContent = this.deriveContentKey();

      const dec = this.decryptBin(raw, kContent);
      const decoded = JSON.parse(dec.toString('utf-8')) as AgentPack;
      // Inject namespace from product.config p4 field (overrides what's in the bin)
      if (pc.p4) decoded.namespace = pc.p4;
      packs.push(decoded);
    }
    return packs;
  }

  // ── Crypto helpers ────────────────────────────────────────────────────────
  private decryptBin(buf: Buffer, key: Buffer): Buffer {
    const nonce = buf.slice(CONTENT_NONCE_OFF, CONTENT_NONCE_OFF + 16);
    let off     = CONTENT_NONCE_OFF + 16;
    const ln    = buf.readUInt32BE(off); off += 4 + ln;
    const plen  = buf.readUInt32BE(off); off += 4;
    const ct    = buf.slice(off, off + plen); off += plen;
    const tag   = buf.slice(off, off + 16);
    const d     = crypto.createDecipheriv('aes-256-gcm', key, nonce);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(ct), d.final()]);
  }

  private verifyHmac(buf: Buffer): boolean {
    const stored   = buf.slice(HMAC_START, HMAC_START + 32);
    const covered  = buf.slice(DATA_START);
    const computed = crypto.createHmac('sha256', this.hmacKey).update(covered).digest();
    return stored.length === computed.length && crypto.timingSafeEqual(stored, computed);
  }

  // ── Clock integrity ───────────────────────────────────────────────────────
  private checkClock(parsed: ParsedLicenseCode): ActivationState | null {
    const now   = Date.now();
    const issued = parsed.expiresAt.getTime() - (365 * 24 * 60 * 60 * 1000); // approx issued 1yr before expiry
    if (now < issued - 60_000) return ActivationState.BLOCKED_CLOCK;
    const lv = this.getLastVerifiedAt();
    if (lv > 0 && now < lv - 120_000) return ActivationState.BLOCKED_CLOCK;
    return null;
  }

  private calcExpiry(parsed: ParsedLicenseCode): ExpiryWarningLevel {
    const d = Math.floor((parsed.expiresAt.getTime() - Date.now()) / 86_400_000);
    if (d < -(GRACE_HOURS / 24)) return ExpiryWarningLevel.EXPIRED;
    if (d < 0)            return ExpiryWarningLevel.GRACE;
    if (d <= URGENT_DAYS) return ExpiryWarningLevel.URGENT;
    if (d <= WARN_DAYS)   return ExpiryWarningLevel.WARNING;
    return ExpiryWarningLevel.NONE;
  }

  // ── lastVerifiedAt (encrypted, stored in globalState) ────────────────────
  async updateLastVerifiedAt(): Promise<void> {
    const k   = this.hmacKey.slice(0, 32);
    const n   = crypto.randomBytes(12);
    const c   = crypto.createCipheriv('aes-256-gcm', k, n);
    const enc = Buffer.concat([c.update(Buffer.from(String(Date.now()))), c.final()]);
    const tag = c.getAuthTag();
    await this.ctx.globalState.update(
      LV_KEY, Buffer.concat([n, enc, tag]).toString('base64'),
    );
  }

  private getLastVerifiedAt(): number {
    const s = this.ctx.globalState.get<string>(LV_KEY);
    if (!s) return 0;
    try {
      const b = Buffer.from(s, 'base64');
      const k = this.hmacKey.slice(0, 32);
      const d = crypto.createDecipheriv('aes-256-gcm', k, b.slice(0, 12));
      d.setAuthTag(b.slice(b.length - 16));
      return parseInt(Buffer.concat([d.update(b.slice(12, b.length - 16)), d.final()]).toString(), 10);
    } catch { return 0; }
  }

  // ── Code storage (OS keychain via VS Code SecretStorage) ─────────────────
  async getSavedCode():       Promise<string | undefined> { return this.ctx.secrets.get(SECRET_KEY); }
  async saveCode(c: string):  Promise<void>               { await this.ctx.secrets.store(SECRET_KEY, c); }
  async clearCode():          Promise<void> {
    await this.ctx.secrets.delete(SECRET_KEY);
    await this.ctx.globalState.update(LV_KEY, undefined);
  }
}
