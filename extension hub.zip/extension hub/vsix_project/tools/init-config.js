#!/usr/bin/env node
/**
 * init-config.js — First-time setup.
 * Generates config.json with all encryption secrets.
 * Run ONCE: node init-config.js
 * NEVER share config.json with anyone.
 */
'use strict';
const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');

const OUT = path.join(__dirname, 'config.json');

if (fs.existsSync(OUT)) {
  console.log('\n⚠  config.json already exists.');
  console.log('   Delete it manually and re-run if you want to regenerate.');
  console.log('   WARNING: Regenerating invalidates ALL existing licenses.\n');
  process.exit(0);
}

console.log('\n╔══════════════════════════════════════════╗');
console.log('║   SDLC Agents — First-Time Setup         ║');
console.log('╚══════════════════════════════════════════╝\n');
console.log('Generating encryption secrets...\n');

// Generate all secrets
const kContent     = crypto.randomBytes(32).toString('base64');
const buildSecretA = crypto.randomBytes(16).toString('hex');  // 32 hex chars
const buildSecretB = crypto.randomBytes(16).toString('hex');  // 32 hex chars

// Split buildSecretB into 4 equal fragments, each hex-encoded again
// (double hex encoding means the raw string is never visible in source)
const chunkLen = buildSecretB.length / 4;
const f1 = Buffer.from(buildSecretB.slice(0 * chunkLen, 1 * chunkLen)).toString('hex');
const f2 = Buffer.from(buildSecretB.slice(1 * chunkLen, 2 * chunkLen)).toString('hex');
const f3 = Buffer.from(buildSecretB.slice(2 * chunkLen, 3 * chunkLen)).toString('hex');
const f4 = Buffer.from(buildSecretB.slice(3 * chunkLen, 4 * chunkLen)).toString('hex');

// Derive magic bytes (bin file header) and HMAC key
const magicBytes = crypto
  .createHash('sha256').update('hdr' + buildSecretA).digest()
  .slice(0, 4).toString('hex');

const hmacKey = crypto
  .createHash('sha256').update('hmac' + buildSecretA + buildSecretB).digest()
  .toString('hex');

const config = {
  productId:            'sdlc-agents',
  contentKey:           kContent,
  contentKeyVersion:    1,
  buildSecretA,
  buildSecretB,
  buildSecretB_fragment1: f1,
  buildSecretB_fragment2: f2,
  buildSecretB_fragment3: f3,
  buildSecretB_fragment4: f4,
  magicBytes,
  hmacKey,
  accessCodePrefix:     'SDLC',
  signingKeyPath:       './signing-key.pem',
  generatedAt:          new Date().toISOString(),
};

fs.writeFileSync(OUT, JSON.stringify(config, null, 2));

console.log('✓ config.json saved\n');
console.log('══════════════════════════════════════════════════════════════════');
console.log('STEP A — Update licenseManager.ts (REQUIRED)');
console.log('');
console.log('Open: extension/src/licenseManager.ts');
console.log('Find the four _f1/_f2/_f3/_f4 lines (they appear TWICE in the file).');
console.log('Replace the placeholder hex strings with these values:\n');
console.log(`    const _f1 = Buffer.from('${f1}', 'hex').toString();`);
console.log(`    const _f2 = Buffer.from('${f2}', 'hex').toString();`);
console.log(`    const _f3 = Buffer.from('${f3}', 'hex').toString();`);
console.log(`    const _f4 = Buffer.from('${f4}', 'hex').toString();`);
console.log('');
console.log('Both occurrences must be updated (constructor + deriveManifestKey method).');
console.log('');
console.log('══════════════════════════════════════════════════════════════════');
console.log('STEP B — Create setenv.bat');
console.log('');
console.log('Copy setenv.template to setenv.bat and set:');
console.log(`    BUILD_SECRET_A=${buildSecretA}`);
console.log('    SIGNING_KEY_PASSWORD=<passphrase you set during generate-keys.js, or leave blank>');
console.log('');
console.log('══════════════════════════════════════════════════════════════════');
console.log('STEP C — Generate signing key (run from tools\\ folder)');
console.log('');
console.log('    node generate-keys.js');
console.log('');
console.log('══════════════════════════════════════════════════════════════════');
console.log('STEP D — Verify setup');
console.log('');
console.log('    node ../test-crypto.js');
console.log('');
console.log('All 15 tests must pass before you run build.bat\n');
