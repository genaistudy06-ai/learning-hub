/**
 * SDLC Learning API — Test Suite (filesystem backend)
 * Run: node test-api.js
 * Requires: server running on PORT 3000  (node server.js)
 */

'use strict';
require('dotenv').config();

const BASE    = `http://localhost:${process.env.PORT || 3000}`;
const API_KEY = process.env.API_KEY || 'dev-secret-key-change-this';
const PACK    = 'sdlc';
const AGENT   = 'sdlc:senior-backend-engineer';

let passed = 0, failed = 0;
let savedLearningId = null;

// ── HTTP helper ───────────────────────────────────────────────────────────────
async function req(method, url, body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
  };
  if (body) opts.body = JSON.stringify(body);
  const resp = await fetch(`${BASE}${url}`, opts);
  const data = await resp.json().catch(() => ({}));
  return { status: resp.status, data };
}

function pass(t)       { console.log(`  ✅  ${t}`); passed++; }
function fail(t, d)    { console.log(`  ❌  ${t}${d ? ' — ' + d : ''}`); failed++; }
function assert(ok, t, d) { ok ? pass(t) : fail(t, d); }

// ── Test runner ───────────────────────────────────────────────────────────────
async function run() {
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  SDLC Learning API — Test Suite (filesystem)');
  console.log(`  Server: ${BASE}   Pack: ${PACK}   Agent: ${AGENT}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // 1. Health
  console.log('[ HEALTH ]');
  {
    const r = await req('GET', '/health');
    assert(r.status === 200,       'GET /health = 200');
    assert(r.data.status === 'ok', 'status === ok');
    assert(!!r.data.dataDir,       'dataDir is present');
  }

  // 2. Auth guard
  console.log('\n[ AUTH GUARD ]');
  {
    const resp = await fetch(`${BASE}/learnings/${PACK}/${AGENT}`, {
      headers: { 'x-api-key': 'WRONG-KEY' },
    });
    assert(resp.status === 401, 'Wrong key → 401');
  }

  // 3. Empty store
  console.log('\n[ EMPTY STORE ]');
  {
    const r = await req('GET', `/learnings/${PACK}/${AGENT}`);
    assert(r.status === 200,                'GET learnings (empty) = 200');
    assert(Array.isArray(r.data.learnings), 'learnings is array');
    assert(r.data.total === 0,              `total === 0  (got ${r.data.total})`);
  }

  // 4. Save learnings
  console.log('\n[ SAVE LEARNINGS ]');
  {
    const r = await req('POST', `/learnings/${PACK}/${AGENT}`, {
      learnings: [
        {
          topic:      'Constructor injection',
          insight:    'Always use constructor injection in this codebase. Property injection is banned and breaks test isolation — the team has a strict convention on this.',
          source:     'auto',
          usageCount: 0,
        },
        {
          topic:      'API response envelope',
          insight:    'All API responses must use the { data, meta, errors } envelope structure. Never return a raw array or object without this wrapper. Hard team standard enforced in code review.',
          source:     'user',
          usageCount: 0,
        },
        {
          topic:      'Error handling async',
          insight:    'Always wrap service layer calls in try/catch and map exceptions to domain errors. Infrastructure exceptions must never bubble up to controllers. Use the AppException hierarchy.',
          source:     'auto',
          usageCount: 3,
        },
      ],
    });
    assert(r.status === 200,   'POST learnings = 200');
    assert(r.data.added === 3, `added === 3  (got ${r.data.added})`);
    assert(r.data.total === 3, `total === 3  (got ${r.data.total})`);
  }

  // 5. Retrieve — user-taught should score high
  console.log('\n[ RETRIEVE LEARNINGS ]');
  {
    const r = await req('GET', `/learnings/${PACK}/${AGENT}?k=5`);
    assert(r.status === 200,               'GET learnings = 200');
    assert(r.data.learnings.length > 0,    'results not empty');
    assert(r.data.total === 3,             `total === 3  (got ${r.data.total})`);
    savedLearningId = r.data.learnings.find(l => l.source === 'user')?.id;
    assert(!!savedLearningId, 'user-taught learning present in results');
    console.log(`    → learning id: ${savedLearningId}`);
  }

  // 6. Topic keyword filter
  console.log('\n[ TOPIC KEYWORD FILTER ]');
  {
    const r = await req('GET', `/learnings/${PACK}/${AGENT}?topic=constructor+injection`);
    assert(r.status === 200, 'GET with topic filter = 200');
    assert(Array.isArray(r.data.learnings), 'learnings is array');
    // May or may not have matches depending on keyword overlap — just check structure
  }

  // 7. Deduplication
  console.log('\n[ DEDUPLICATION ]');
  {
    const r = await req('POST', `/learnings/${PACK}/${AGENT}`, {
      learnings: [{
        topic:   'Constructor injection',   // exact topic match → should merge
        insight: 'Always use constructor injection — property injection is forbidden.',
        source:  'auto',
      }],
    });
    assert(r.data.added  === 0, `duplicate NOT added  (added=${r.data.added})`);
    assert(r.data.merged === 1, `duplicate merged     (merged=${r.data.merged})`);
    assert(r.data.total  === 3, `total still 3        (got ${r.data.total})`);
  }

  // 8. Mark used
  console.log('\n[ MARK USED ]');
  if (savedLearningId) {
    const r = await req('PATCH', `/learnings/${PACK}/${AGENT}/${savedLearningId}/used`);
    assert(r.status === 200,        'PATCH /used = 200');
    assert(r.data.ok === true,      'ok is true');
    assert(r.data.usageCount >= 1,  `usageCount >= 1  (got ${r.data.usageCount})`);
  } else {
    fail('PATCH /used', 'no savedLearningId from step 5');
  }

  // 9. List pack agents
  console.log('\n[ LIST PACK AGENTS ]');
  {
    const r = await req('GET', `/learnings/${PACK}`);
    assert(r.status === 200,             'GET /learnings/:pack = 200');
    assert(r.data.count >= 1,            `at least 1 agent  (got ${r.data.count})`);
    assert(Array.isArray(r.data.agents), 'agents is array');
    const found = r.data.agents.find(a => a.agentKey === AGENT);
    assert(!!found, `${AGENT} is listed`);
    if (found) {
      assert(found.userTaught >= 1, `userTaught >= 1  (got ${found.userTaught})`);
    }
  }

  // 10. Stats — record
  console.log('\n[ STATS — RECORD ]');
  {
    const r = await req('POST', `/stats/${PACK}/${AGENT}`, {
      week:                '2026-W17',
      invocations:         22,
      modelTier:           '1x',
      modelUsed:           'gpt-4o',
      manualOverrides:     3,
      debateCalls:         1,
      learningsAutoSaved:  5,
      learningsUserTaught: 2,
      learningsRecalled:   18,
      learningMode:        'central',
    });
    assert(r.status === 200,   'POST /stats = 200');
    assert(r.data.ok === true, 'stats recorded ok');
  }

  // 11. Stats — retrieve
  console.log('\n[ STATS — RETRIEVE ]');
  {
    const r = await req('GET', `/stats/${PACK}/${AGENT}?weeks=4`);
    assert(r.status === 200,             'GET /stats = 200');
    assert(Array.isArray(r.data.weeks),  'weeks is array');
    const w = r.data.weeks.find(w => w.week === '2026-W17');
    assert(!!w,                          '2026-W17 found');
    assert(w?.invocations === 22,        `invocations === 22  (got ${w?.invocations})`);
    assert(w?.learningMode === 'central','learningMode = central');
  }

  // 12. Stats — upsert same week
  console.log('\n[ STATS UPSERT ]');
  {
    const r = await req('POST', `/stats/${PACK}/${AGENT}`, {
      week:        '2026-W17',
      invocations: 25,   // updated value
      modelTier:   '1x',
    });
    assert(r.data.ok === true, 'upsert ok');
    const r2 = await req('GET', `/stats/${PACK}/${AGENT}?weeks=4`);
    const w  = r2.data.weeks.find(w => w.week === '2026-W17');
    assert(w?.invocations === 25, `invocations updated to 25  (got ${w?.invocations})`);
    assert(r2.data.weeks.filter(w => w.week === '2026-W17').length === 1, 'no duplicate weeks');
  }

  // 13. Quality gate — short insight rejected
  console.log('\n[ QUALITY GATE ]');
  {
    const r = await req('POST', `/learnings/${PACK}/${AGENT}`, {
      learnings: [{ topic: 'Short', insight: 'Too short', source: 'auto' }],
    });
    assert(r.data.added === 0, 'short insight rejected (added=0)');
  }

  // 14. Delete specific learning
  console.log('\n[ DELETE SPECIFIC ]');
  if (savedLearningId) {
    const r = await req('DELETE', `/learnings/${PACK}/${AGENT}/${savedLearningId}`);
    assert(r.status === 200,       'DELETE = 200');
    assert(r.data.removed === 1,   'removed = 1');
    assert(r.data.remaining === 2, `remaining === 2  (got ${r.data.remaining})`);
    // Verify
    const r2 = await req('GET', `/learnings/${PACK}/${AGENT}`);
    assert(r2.data.total === 2, `total now 2  (got ${r2.data.total})`);
  } else {
    fail('DELETE specific', 'no savedLearningId');
  }

  // 15. Delete non-existent learning
  console.log('\n[ DELETE NON-EXISTENT ]');
  {
    const r = await req('DELETE', `/learnings/${PACK}/${AGENT}/nonexistent-id-12345`);
    assert(r.status === 404, '404 for non-existent learning');
  }

  // 16. Clear all learnings
  console.log('\n[ CLEAR ALL ]');
  {
    const r = await req('DELETE', `/learnings/${PACK}/${AGENT}`);
    assert(r.status === 200,     'DELETE all = 200');
    assert(r.data.ok === true,   'ok is true');
    const r2 = await req('GET', `/learnings/${PACK}/${AGENT}`);
    assert(r2.data.total === 0,  'total is 0 after clear');
  }

  // ── Summary ───────────────────────────────────────────────────────────────
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`  Results: ${passed} passed  |  ${failed} failed  |  ${passed + failed} total`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  if (failed > 0) process.exit(1);
}

run().catch(err => {
  console.error('\nFatal test error:', err.message);
  process.exit(1);
});
