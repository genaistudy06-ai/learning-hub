// uiManager.ts — Status bar, notifications, webview panels
import * as vscode from 'vscode';
import { StateManager } from './stateManager';
import {
  ActivationState, ExpiryWarningLevel, LicenseFeatures,
} from './types';

export class UiManager {
  private statusBar: vscode.StatusBarItem;
  private readonly sm: StateManager;

  constructor(private readonly ctx: vscode.ExtensionContext, sm: StateManager) {
    this.sm = sm;
    this.statusBar = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Left, 100,
    );
    this.statusBar.command = 'sdlcAgents.showStatus';
    this.statusBar.tooltip = 'SDLC Agents — click for status';
    this.statusBar.show();
    ctx.subscriptions.push(this.statusBar);
    this.updateStatusBar(ActivationState.DORMANT);
  }

  // ── State change callback (called by StateManager) ────────────────────────
  onStateChange(state: ActivationState): void {
    this.updateStatusBar(state);
  }

  // ── Status bar label per state ────────────────────────────────────────────
  private updateStatusBar(state: ActivationState): void {
    const label = this.sm.productConfig.i5j6 ?? 'SDLC';

    switch (state) {
      case ActivationState.DORMANT:
        this.statusBar.text            = `$(circle-outline) ${label}`;
        this.statusBar.backgroundColor = undefined;
        this.statusBar.tooltip         = 'SDLC Agents — not activated. Click to activate.';
        break;

      case ActivationState.VALIDATING:
      case ActivationState.DECRYPTING:
      case ActivationState.INJECTING:
        this.statusBar.text            = `$(sync~spin) ${label}`;
        this.statusBar.backgroundColor = undefined;
        this.statusBar.tooltip         = 'SDLC Agents — activating…';
        break;

      case ActivationState.AWAITING_CODE:
        this.statusBar.text            = `$(key) ${label}`;
        this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBar.tooltip         = 'SDLC Agents — enter your access code to activate';
        break;

      case ActivationState.ACTIVE: {
        const cfg        = vscode.workspace.getConfiguration('sdlcAgents');
        const manualMode = cfg.get<boolean>('manualModelSelect', false);
        const modeLabel  = manualMode ? 'manual' : 'auto';
        this.statusBar.text            = `$(check) ${label} [${modeLabel}]`;
        this.statusBar.backgroundColor = undefined;
        this.statusBar.tooltip         = `SDLC Agents — active. Model: ${modeLabel}. Click for status.`;
        break;
      }

      case ActivationState.DEACTIVATING:
        this.statusBar.text            = `$(sync~spin) ${label}`;
        this.statusBar.backgroundColor = undefined;
        break;

      case ActivationState.BLOCKED_MACHINE:
        this.statusBar.text            = `$(error) ${label} — wrong machine`;
        this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBar.tooltip         = 'This code is licensed for a different machine. Contact your administrator.';
        break;

      case ActivationState.BLOCKED_CLOCK:
        this.statusBar.text            = `$(error) ${label} — clock issue`;
        this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBar.tooltip         = 'System clock issue detected. Check your date/time settings.';
        break;

      case ActivationState.BLOCKED_EXPIRED:
        this.statusBar.text            = `$(error) ${label} — expired`;
        this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBar.tooltip         = 'License expired. Contact your administrator for a new code.';
        break;

      case ActivationState.BLOCKED_INVALID:
      case ActivationState.BLOCKED_TAMPERED:
        this.statusBar.text            = `$(error) ${label} — invalid`;
        this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBar.tooltip         = 'Invalid or tampered access code.';
        break;

      default:
        this.statusBar.text            = `$(warning) ${label}`;
        this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    }
  }

  // ── Activation panel — shown when no code is saved ────────────────────────
  showActivationPanel(): void {
    const productName = this.sm.productConfig.productName;
    vscode.window.showInformationMessage(
      `${productName}: Enter your access code to activate agents.`,
      'Enter Code',
      'Get Machine ID',
    ).then(choice => {
      if (choice === 'Enter Code')    vscode.commands.executeCommand('sdlcAgents.activate');
      if (choice === 'Get Machine ID') vscode.commands.executeCommand('sdlcAgents.showMachineId');
    });
  }

  // ── Active notification ───────────────────────────────────────────────────
  showActiveNotification(
    expiryLevel:    ExpiryWarningLevel,
    daysRemaining:  number,
    features:       LicenseFeatures,
  ): void {
    const productName = this.sm.productConfig.productName;
    const learnNote   = features.selfLearning ? ' · self-learning active' : '';

    if (expiryLevel === ExpiryWarningLevel.NONE) {
      // Silent on normal activation — status bar is enough
      return;
    }

    if (expiryLevel === ExpiryWarningLevel.GRACE) {
      vscode.window.showWarningMessage(
        `${productName}: License in grace period — ${Math.abs(daysRemaining)} days overdue. Renew immediately.`,
        'OK',
      );
      return;
    }

    if (expiryLevel === ExpiryWarningLevel.URGENT) {
      vscode.window.showWarningMessage(
        `${productName}: License expires in ${daysRemaining} day${daysRemaining === 1 ? '' : 's'}! Contact your administrator.`,
        'OK',
      );
      return;
    }

    if (expiryLevel === ExpiryWarningLevel.WARNING) {
      vscode.window.showInformationMessage(
        `${productName}: License expires in ${daysRemaining} days.`,
        'OK',
      );
    }
  }

  // ── Expiry warning (called from recheck timer) ────────────────────────────
  showExpiryWarning(expiryLevel: ExpiryWarningLevel, daysRemaining: number): void {
    const productName = this.sm.productConfig.productName;
    this.updateStatusBar(ActivationState.ACTIVE); // keep active but update tooltip

    if (expiryLevel === ExpiryWarningLevel.URGENT) {
      this.statusBar.text            = `$(warning) ${this.sm.productConfig.i5j6} — ${daysRemaining}d left`;
      this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
      vscode.window.showWarningMessage(
        `${productName}: License expires in ${daysRemaining} day${daysRemaining === 1 ? '' : 's'}!`,
        'OK',
      );
    } else if (expiryLevel === ExpiryWarningLevel.WARNING) {
      this.statusBar.text = `$(warning) ${this.sm.productConfig.i5j6} — ${daysRemaining}d left`;
    } else if (expiryLevel === ExpiryWarningLevel.GRACE) {
      this.statusBar.text            = `$(error) ${this.sm.productConfig.i5j6} — grace period`;
      this.statusBar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
    }
  }

  // ── Blocked panel ─────────────────────────────────────────────────────────
  showBlocked(state: ActivationState, machineId: string): void {
    const productName = this.sm.productConfig.productName;

    const messages: Partial<Record<ActivationState, string>> = {
      [ActivationState.BLOCKED_MACHINE]:
        `${productName}: This access code is licensed for a different machine.\n\nYour Machine ID: ${machineId}\n\nPlease send this ID to your administrator to receive a new code.`,
      [ActivationState.BLOCKED_EXPIRED]:
        `${productName}: Your license has expired. Contact your administrator for a new access code.`,
      [ActivationState.BLOCKED_INVALID]:
        `${productName}: The access code is invalid. Please check the code and try again.`,
      [ActivationState.BLOCKED_TAMPERED]:
        `${productName}: Extension file integrity check failed. Please reinstall the extension.`,
      [ActivationState.BLOCKED_CLOCK]:
        `${productName}: System clock issue detected. Ensure your system date and time are correct.`,
    };

    const msg = messages[state] ?? `${productName}: Activation blocked (${state}).`;

    vscode.window.showErrorMessage(msg,
      ...(state === ActivationState.BLOCKED_MACHINE
        ? ['Copy Machine ID', 'Close']
        : ['Close']),
    ).then(choice => {
      if (choice === 'Copy Machine ID') {
        vscode.env.clipboard.writeText(machineId);
        vscode.window.showInformationMessage('Machine ID copied to clipboard.');
      }
    });
  }

  // ── Status panel webview ──────────────────────────────────────────────────
  showStatusPanel(): void {
    const state    = this.sm.currentState;
    const features = this.sm.features;
    const cfg      = vscode.workspace.getConfiguration('sdlcAgents');
    const panel    = vscode.window.createWebviewPanel(
      'sdlcStatus', 'SDLC Agents — Status',
      vscode.ViewColumn.Beside,
      { enableScripts: false },
    );

    const packList  = features?.agentPacks?.join(', ') ?? 'none';
    const learnMode = cfg.get<string>('learningMode', 'local');
    const modelMode = cfg.get<boolean>('manualModelSelect', false) ? 'Manual' : 'Auto';

    // Build learning stats per agent
    const agentKeys    = this.sm.getLearningAgentKeys();
    const lm           = (this.sm.agentManager as any).learningManager;
    const learningRows = agentKeys.map(key => {
      const s = lm?.stats(key) ?? { count: 0, userTaught: 0 };
      return `<tr>
        <td>${key}</td>
        <td>${s.count}</td>
        <td>${s.userTaught}</td>
      </tr>`;
    }).join('\n');

    panel.webview.html = `<!DOCTYPE html><html><body style="font-family:Arial;padding:20px;max-width:700px">
      <h2>$(check) SDLC Agents — Status</h2>
      <table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%">
        <tr><td><b>State</b></td><td>${state}</td></tr>
        <tr><td><b>Licensed Packs</b></td><td>${packList}</td></tr>
        <tr><td><b>Self-Learning</b></td><td>${features?.selfLearning ? 'Enabled' : 'Disabled'}</td></tr>
        <tr><td><b>Learning Mode</b></td><td>${learnMode}</td></tr>
        ${learnMode === 'central'
          ? `<tr><td><b>Central API</b></td><td>${cfg.get<string>('centralApiUrl') || '(not configured)'}</td></tr>`
          : ''}
        <tr><td><b>Model Mode</b></td><td>${modelMode}</td></tr>
        <tr><td><b>Extension Version</b></td><td>${this.sm.productConfig.productVersion}</td></tr>
      </table>

      ${agentKeys.length > 0 ? `
      <h3 style="margin-top:24px">Accumulated Learnings</h3>
      <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%">
        <tr style="background:#1a237e;color:white">
          <th>Agent</th><th>Total</th><th>User-Taught</th>
        </tr>
        ${learningRows}
      </table>` : '<p><i>No learnings stored yet.</i></p>'}

      <h3 style="margin-top:24px">Quick Commands</h3>
      <ul>
        <li>Ctrl+Shift+P → <b>SDLC Agents: Show Weekly Stats</b></li>
        <li>Ctrl+Shift+P → <b>SDLC Agents: Toggle Model Mode</b></li>
        <li>Ctrl+Shift+P → <b>SDLC Agents: Clear Learnings</b></li>
        <li>Ctrl+Shift+P → <b>SDLC Agents: Show Walkthrough</b></li>
      </ul>
    </body></html>`;
  }
}
