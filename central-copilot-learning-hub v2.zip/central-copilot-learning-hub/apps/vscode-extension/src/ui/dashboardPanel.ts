// ─── Dashboard Webview (Phase 2) ──────────────────────────────────────────────
import * as vscode from 'vscode';
import type { LearningHubClient } from '../services/apiClient';

export class DashboardPanel {
  static currentPanel: DashboardPanel | undefined;
  private readonly panel: vscode.WebviewPanel;
  private readonly client: LearningHubClient;
  private disposables: vscode.Disposable[] = [];

  static show(context: vscode.ExtensionContext, client: LearningHubClient) {
    const column = vscode.window.activeTextEditor?.viewColumn ?? vscode.ViewColumn.One;

    if (DashboardPanel.currentPanel) {
      DashboardPanel.currentPanel.panel.reveal(column);
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      'learningHubDashboard',
      '📚 Learning Hub Dashboard',
      column,
      { enableScripts: true, retainContextWhenHidden: true }
    );

    DashboardPanel.currentPanel = new DashboardPanel(panel, client);
  }

  private constructor(panel: vscode.WebviewPanel, client: LearningHubClient) {
    this.panel = panel;
    this.client = client;

    this.update();

    this.panel.onDidDispose(() => this.dispose(), null, this.disposables);
    this.panel.webview.onDidReceiveMessage(async msg => {
      if (msg.type === 'refresh') await this.update();
      if (msg.type === 'vote') {
        const config = vscode.workspace.getConfiguration('copilotLearningHub');
        const userId = config.get<string>('userId') ?? 'anonymous';
        await this.client.vote(msg.solutionId, userId, msg.action);
        await this.update();
      }
    }, null, this.disposables);
  }

  private async update() {
    try {
      const data = await this.client.getAnalytics() as any;
      this.panel.webview.html = this.buildHtml(data.snapshots ?? [data]);
    } catch {
      this.panel.webview.html = this.errorHtml();
    }
  }

  private buildHtml(snapshots: any[]): string {
    const skillCards = snapshots.map(s => `
      <div class="card">
        <h2>${s.skill.toUpperCase()} <span class="badge">${s.totalLearnings} learnings</span></h2>
        <div class="stats">
          <span class="stat active">✅ ${s.activeCount} active</span>
          <span class="stat suppressed">🚫 ${s.suppressedCount} suppressed</span>
          <span class="stat high">🏆 ${s.highConfidenceCount} high-conf</span>
        </div>
        <h4>Top Retrieved</h4>
        <ul>${(s.topRetrieved ?? []).slice(0,3).map((e: any) =>
          `<li><strong>${e.title}</strong> — 🔁 ${e.retrievalCount} | ⭐ ${e.communityScore?.toFixed(1)}</li>`
        ).join('')}</ul>
        <h4>Top Voted</h4>
        <ul>${(s.topVoted ?? []).slice(0,3).map((e: any) =>
          `<li><strong>${e.title}</strong> — 👍${e.upvotes} 👎${e.downvotes}</li>`
        ).join('')}</ul>
      </div>
    `).join('');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Learning Hub Dashboard</title>
  <style>
    body { font-family: var(--vscode-font-family); background: var(--vscode-editor-background); color: var(--vscode-editor-foreground); padding: 20px; margin: 0; }
    h1 { color: var(--vscode-textLink-foreground); }
    .card { background: var(--vscode-sideBar-background); border: 1px solid var(--vscode-panel-border); border-radius: 8px; padding: 16px; margin-bottom: 16px; }
    .badge { background: var(--vscode-badge-background); color: var(--vscode-badge-foreground); border-radius: 12px; padding: 2px 10px; font-size: 0.8em; margin-left: 8px; }
    .stats { display: flex; gap: 12px; margin: 8px 0; flex-wrap: wrap; }
    .stat { padding: 4px 10px; border-radius: 6px; font-size: 0.85em; font-weight: 600; }
    .active { background: rgba(0,200,0,0.15); }
    .suppressed { background: rgba(200,0,0,0.15); }
    .high { background: rgba(0,150,255,0.15); }
    ul { margin: 4px 0; padding-left: 18px; }
    li { margin: 4px 0; font-size: 0.9em; }
    .refresh-btn { background: var(--vscode-button-background); color: var(--vscode-button-foreground); border: none; padding: 8px 18px; border-radius: 6px; cursor: pointer; margin-bottom: 20px; font-size: 1em; }
    .refresh-btn:hover { opacity: 0.85; }
    .generated { font-size: 0.75em; opacity: 0.6; margin-bottom: 12px; }
  </style>
</head>
<body>
  <h1>📚 Central Copilot Learning Hub</h1>
  <button class="refresh-btn" onclick="refresh()">🔄 Refresh</button>
  <div class="generated">Generated: ${new Date().toLocaleString()}</div>
  ${skillCards}
  <script>
    const vscode = acquireVsCodeApi();
    function refresh() { vscode.postMessage({ type: 'refresh' }); }
  </script>
</body>
</html>`;
  }

  private errorHtml(): string {
    return `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:20px;">
      <h2>❌ Could not load dashboard</h2>
      <p>Check your API URL and credentials in settings.</p>
      <button onclick="acquireVsCodeApi().postMessage({type:'refresh'})">Retry</button>
    </body></html>`;
  }

  dispose() {
    DashboardPanel.currentPanel = undefined;
    this.panel.dispose();
    this.disposables.forEach(d => d.dispose());
  }
}
