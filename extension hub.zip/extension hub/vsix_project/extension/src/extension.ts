// extension.ts — VS Code extension entry point
import * as vscode from 'vscode';
import { StateManager } from './stateManager';
import { UiManager    } from './uiManager';
import { ActivationState } from './types';

let sm: StateManager | undefined;
let ui: UiManager    | undefined;

export async function activate(ctx: vscode.ExtensionContext): Promise<void> {
  sm = new StateManager(ctx);
  ui = new UiManager(ctx, sm);
  sm.setUiManager(ui);

  ctx.subscriptions.push(

    // ── Activation ──────────────────────────────────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.activate', async () => {
      await sm!.startActivationFlow();
    }),

    // ── Sign out ─────────────────────────────────────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.signOut', async () => {
      const ans = await vscode.window.showWarningMessage(
        'Sign out clears your saved access code. Continue?', 'Sign Out', 'Cancel',
      );
      if (ans === 'Sign Out') {
        await sm!.signOut();
        vscode.window.showInformationMessage('Signed out. Run "Activate" to re-activate.');
      }
    }),

    // ── Show machine ID (for getting a license code) ─────────────────────────
    vscode.commands.registerCommand('sdlcAgents.showMachineId', async () => {
      const id  = vscode.env.machineId;
      const ans = await vscode.window.showInformationMessage(
        `Your Machine ID: ${id}`, 'Copy to Clipboard', 'Close',
      );
      if (ans === 'Copy to Clipboard') {
        await vscode.env.clipboard.writeText(id);
        vscode.window.showInformationMessage('Machine ID copied.');
      }
    }),

    // ── Show status panel ────────────────────────────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.showStatus', () => {
      ui!.showStatusPanel();
    }),

    // ── Clear learnings — quick-pick per agent ───────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.clearLearnings', async () => {
      const keys = sm!.getLearningAgentKeys();
      if (!keys.length) {
        vscode.window.showInformationMessage('No learnings stored yet.');
        return;
      }

      const items: vscode.QuickPickItem[] = [
        { label: '$(trash) Clear ALL agents', description: 'Remove all learnings across every agent' },
        ...keys.map(k => ({ label: `$(robot) ${k}`, description: 'Clear learnings for this agent only' })),
      ];

      const picked = await vscode.window.showQuickPick(items, {
        title:       'Clear Agent Learnings',
        placeHolder: 'Select an agent to clear, or clear all',
      });
      if (!picked) return;

      if (picked.label.includes('Clear ALL')) {
        const confirm = await vscode.window.showWarningMessage(
          'Clear ALL learnings? This cannot be undone.', 'Clear All', 'Cancel',
        );
        if (confirm === 'Clear All') {
          sm!.clearAllLearnings();
          vscode.window.showInformationMessage('All learnings cleared.');
        }
      } else {
        const agentKey = picked.label.replace('$(robot) ', '');
        sm!.clearAgentLearnings(agentKey);
        vscode.window.showInformationMessage(`Learnings cleared for ${agentKey}.`);
      }
    }),

    // ── Weekly stats — formatted for v2 tracker copy-paste ───────────────────
    vscode.commands.registerCommand('sdlcAgents.showWeeklyStats', async () => {
      const stats = sm!.getWeeklyStats();

      // Build the display panel in a VS Code webview
      const panel = vscode.window.createWebviewPanel(
        'sdlcWeeklyStats',
        `Weekly Stats — ${stats.weekLabel}`,
        vscode.ViewColumn.Beside,
        { enableScripts: true },
      );

      // Agent ID to tracker column label mapping
      const AGENT_LABELS: Record<string, string> = {
        'sdlc-orchestrator':         'Orchestrator',
        'senior-backend-engineer':   'Backend Eng.',
        'senior-frontend-engineer':  'Frontend Eng.',
        'qa-automation-engineer':    'QA Automation',
        'security-architect':        'Security Arch.',
        'code-reviewer':             'Code Reviewer',
        'devops-engineer':           'DevOps Eng.',
        'project-manager':           'Project Mgr.',
        'performance-engineer':      'Performance Eng.',
      };

      const trackerRows: string[] = [];
      let otherCount = 0;

      for (const [agentId, count] of Object.entries(stats.invocations)) {
        const label = AGENT_LABELS[agentId];
        if (label) trackerRows.push(`<tr><td>${label}</td><td>${count}</td></tr>`);
        else otherCount += count;
      }

      const totalInvocations = stats.totalInvocations;
      const estHrsSaved = (totalInvocations * 9 / 60).toFixed(1); // 9 min avg

      panel.webview.html = `<!DOCTYPE html><html><body style="font-family:Arial;padding:20px">
        <h2>📋 Weekly Stats — ${stats.weekLabel}</h2>
        <p style="color:#666">${stats.weekStart} → ${stats.weekEnd}</p>

        <h3>Agent Logs (paste into Data Input cols V–AF)</h3>
        <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse">
          <tr style="background:#1a237e;color:white"><th>Column</th><th>Value</th></tr>
          <tr><td>Total Invocations</td><td><b>${totalInvocations}</b></td></tr>
          ${trackerRows.join('\n')}
          <tr><td>Other Agents</td><td>${otherCount}</td></tr>
          <tr><td>Est. Hrs Saved</td><td>${estHrsSaved}</td></tr>
        </table>

        <button onclick="copyTrackerData()" style="margin-top:12px;padding:8px 16px;background:#1a237e;color:white;border:none;cursor:pointer">
          Copy tracker-ready values
        </button>

        <hr style="margin-top:24px"/>
        <h3>Additional Stats</h3>
        <table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse">
          <tr style="background:#4a148c;color:white"><th>Metric</th><th>Value</th></tr>
          <tr><td>Model Tier</td><td>${stats.modelTier}</td></tr>
          <tr><td>Manual Overrides</td><td>${stats.manualOverrides}</td></tr>
          <tr><td>Debate Sessions</td><td>${stats.debateSessions}</td></tr>
          <tr><td>Auto-Learnings Saved</td><td>${stats.learningsAutoSaved}</td></tr>
          <tr><td>User-Taught Learnings</td><td>${stats.learningsUserTaught}</td></tr>
          <tr><td>Learnings Recalled</td><td>${stats.learningsRecalled}</td></tr>
          <tr><td>Learning Mode</td><td>${stats.learningMode}</td></tr>
        </table>

        <script>
          const vscode = acquireVsCodeApi();
          function copyTrackerData() {
            const values = [
              '${totalInvocations}',
              ${Object.entries(AGENT_LABELS).map(([id]) => `'${stats.invocations[id] ?? 0}'`).join(',')},
              '${otherCount}',
              '${estHrsSaved}'
            ].join('\\t');
            navigator.clipboard.writeText(values);
          }
        </script>
      </body></html>`;
    }),

    // ── Toggle model mode auto/manual ────────────────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.toggleModelMode', async () => {
      const cfg     = vscode.workspace.getConfiguration('sdlcAgents');
      const current = cfg.get<boolean>('manualModelSelect', false);
      await cfg.update('manualModelSelect', !current, vscode.ConfigurationTarget.Global);
      vscode.window.showInformationMessage(
        !current
          ? '$(wrench) Model selection: MANUAL — use the model picker in the Copilot chat input bar'
          : '$(zap) Model selection: AUTO — tier detected from your message content',
      );
    }),

    // ── Walkthrough (on demand only) ─────────────────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.showWalkthrough', () => {
      vscode.commands.executeCommand('workbench.action.openWalkthrough',
        'sdlc-agents.sdlc-agents#sdlcWalkthrough', false);
    }),

    // ── Reset weekly stats (new week) ────────────────────────────────────────
    vscode.commands.registerCommand('sdlcAgents.resetWeeklyStats', async () => {
      const ans = await vscode.window.showWarningMessage(
        'Reset weekly stats counters to zero?', 'Reset', 'Cancel',
      );
      if (ans === 'Reset') {
        sm!.resetWeeklyStats();
        vscode.window.showInformationMessage('Weekly stats reset.');
      }
    }),

    // ── Auto-activate on startup ──────────────────────────────────────────────
    vscode.workspace.onDidChangeWorkspaceFolders(async () => {
      // No-op: agents are in-memory participants, not workspace files
    }),

  );

  const cfg = vscode.workspace.getConfiguration('sdlcAgents');
  if (cfg.get<boolean>('autoActivate', true)) {
    setTimeout(() => sm!.startActivationFlow(), 1500);
  }
}

export async function deactivate(): Promise<void> {
  if (sm) await sm.deactivate();
  sm = undefined;
  ui = undefined;
}
