# Agent Libraries — Usage Documentation
# Converted to @-mention chat-based agent format
# Version: 2.0 | Generated from: others.zip

---

## Overview

This package contains **4 agent libraries**, each converted from GitHub Copilot chat-dropdown agents
to `@mention`-style chat agents. Each lib ships two files:

| File | Contents |
|------|----------|
| `agents.md` | All agent definitions with YAML frontmatter and full agent bodies |
| `instructions.md` | Shared context, rules, and guidelines inherited by all agents in the lib |

---

## Libraries at a Glance

| Library | Folder | Entry Point | Agents | Purpose |
|---------|--------|-------------|--------|---------|
| Ab Initio → PySpark | `ABPY/` | `@ABPYAnalyzer` | 7 | Convert Ab Initio graphs to PySpark jobs |
| Angular → React | `angular-to-react/` | `@MigrateOrchestrator` | 6 | Incremental Angular → React migration |
| Java → Python | `java-to-python/` | `@J2PyMaster` | 11 | Full Java codebase → Python conversion |
| Tez → Spark | `tez-migration/` | `@TezMaster` | 13 | Apache Tez → Apache Spark migration |

---

## Extension Setup

Each lib's files go into your extension's agent loader. Your extension reads `agents.md`,
splits on the YAML frontmatter boundaries (`---`), and registers each agent with its `name` field.
Users then invoke agents by typing `@AgentName` in chat.

The `instructions.md` file is loaded as shared context for all agents in the lib.

### File Structure for Your Extension

```
your-extension/
  libs/
    ABPY/
      agents.md        ← 7 agent definitions
      instructions.md  ← ABPY pipeline rules
    angular-to-react/
      agents.md        ← 6 agent definitions
      instructions.md  ← Migration rules + incremental migration rules
    java-to-python/
      agents.md        ← 11 agent definitions
      instructions.md  ← Global pipeline rules + quickstart
    tez-migration/
      agents.md        ← 13 agent definitions
      instructions.md  ← Global rules + quickstart
```

---

## Agent Format

Each agent in `agents.md` uses this structure:

```yaml
---
name: AgentName          ← @AgentName invocation key
description: >           ← When to invoke this agent (used by extension router)
  Invoke when...
tools:                   ← Tools the agent uses
  - codebase
  - file_search
  - read_file
  - create_file
  - replace_string_in_file
  - run_command
---

# Agent Title
[Agent body — role, directives, protocols, output templates]
```

---

## Fixes Applied During Conversion

### 1. Invocation Format (All Libs)
| Old Format | New Format |
|---|---|
| `@agent 01-analyzer-agent` | `@ABPYAnalyzer` |
| `#file:copilot-agents/master-agent.md` | `@J2PyMaster` / `@TezMaster` |
| Chat dropdown agent selection | Direct `@AgentName` in chat |

### 2. Missing Frontmatter Added
- **ABPY**: All 7 agents had no frontmatter — added `name`, `description`, `tools`
- **Java-to-Python**: All 11 agents had no frontmatter — added complete frontmatter
- **Tez**: All 13 agents had no frontmatter — added complete frontmatter
- **Angular-to-React**: Frontmatter already present — cleaned up `model: gpt-4o` conflicts

### 3. Tool Declarations Validated
All agents now declare correct tools:
- **Read-only agents** (auditors, reporters): `codebase, file_search, read_file`
- **Code-writing agents**: above + `create_file, replace_string_in_file`
- **Pipeline drivers** (master agents): above + `run_command`

### 4. Internal Cross-References Fixed
All agent-to-agent references updated to use new `@AgentName` format in:
- PROMPT TO USE sections
- Handoff block NEXT_AGENT fields
- Pipeline documentation
- Resume/retry instructions

### 5. Instructions Consolidated
- ABPY: Single `INSTRUCTIONS.md` → `instructions.md` with preamble
- Angular: 3 separate instruction files merged into single `instructions.md` (5 sections)
- Java-to-Python: `.copilot/instructions.md` + `QUICKSTART.md` → `instructions.md`
- Tez: `.copilot/instructions.md` + `QUICKSTART.md` → `instructions.md`

---

## Library 1 — ABPY (Ab Initio → PySpark)

### Agent Map

```
Ab Initio Files
      │
@ABPYAnalyzer          ← ENTRY POINT — 12-phase deep analysis
      │ HANDOFF BLOCK ①
@ABPYSchema            ← Layouts → StructType + config YAML
      │ HANDOFF BLOCK ②
      ├────────────────────────────────────┐
@ABPYConverter         ← PySpark job code  │ @ABPYOrchestrator ← KSH → workflow
      │ HANDOFF BLOCK ③                   │   (only if KSH_FILES_PRESENT=YES)
@ABPYValidator         ← Reconciliation tests
      │ HANDOFF BLOCK ④
@ABPYPerfSec           ← Performance + security hardening
      │ HANDOFF BLOCK ⑤
      └──────────────┐
              @ABPYSignoff ← Final 20-item gate (terminal)
```

### Agents

| Agent | @Name | Role |
|-------|-------|------|
| Ab Initio Graph Analyzer v2 | `@ABPYAnalyzer` | 12-phase analysis — entry point |
| Schema & Config Converter | `@ABPYSchema` | DML layouts → StructType schemas |
| PySpark Converter v2 | `@ABPYConverter` | Full-fidelity PySpark job generation |
| KSH Orchestration Converter | `@ABPYOrchestrator` | KSH → Databricks Workflow / Airflow DAG |
| Reconciliation Validator | `@ABPYValidator` | 7-class test suite proving PySpark == AbInitio |
| Performance & Security Reviewer | `@ABPYPerfSec` | Perf + security hardening |
| Conversion Sign-off | `@ABPYSignoff` | 20-item final gate (terminal) |

### Examples

#### Starting a new graph conversion
```
@ABPYAnalyzer

Analyze the following Ab Initio application completely.
Do NOT write any PySpark code.

Attached files:
- Graph files  : orders_processing.mp, customers_extract.mp
- DML files    : orders_layout.dml, customers_layout.dml
- Layout files : orders_layout.dml
- Param files  : orders_processing.mp (param)
- KSH scripts  : run_orders_pipeline.ksh

Business context:
- Source system      : Oracle
- Target platform    : Databricks
- Data volume        : 500M rows / 200GB per run
- SLA                : 45 minutes
- Processing type    : Batch
- Restart required   : YES

Run all 12 analysis phases. Flag every UNKNOWN explicitly.
Produce the complete HANDOFF BLOCK at the end.
```

#### Converting schemas (after analyzer handoff)
```
@ABPYSchema

[PASTE FULL HANDOFF BLOCK FROM @ABPYAnalyzer HERE]

Convert all Ab Initio layouts and parameter files.

Attached files:
- Layout files : orders_layout.dml, customers_layout.dml
- Param files  : orders_processing.mp

Generate:
1. src/pyspark/schemas/orders_schema.py
2. config/orders_processing_config.yaml
3. src/pyspark/utils/config_loader.py

Output the updated HANDOFF BLOCK for @ABPYConverter.
```

#### Converting the job (after schema handoff)
```
@ABPYConverter

[PASTE FULL HANDOFF BLOCK FROM @ABPYSchema HERE]

Convert the Ab Initio graph to a complete PySpark job.

Attached files:
- Graph file : orders_processing.mp
- DML files  : orders_layout.dml, customers_layout.dml

Generate:
1. src/pyspark/jobs/orders_processing.py
2. src/pyspark/utils/dml_functions.py
3. src/pyspark/utils/partition_utils.py
4. src/pyspark/utils/error_handler.py

Output the updated HANDOFF BLOCK for @ABPYValidator.
```

#### Orchestration conversion (parallel, only if KSH present)
```
@ABPYOrchestrator

[PASTE FULL HANDOFF BLOCK FROM @ABPYAnalyzer — KSH SECTION]

Convert the Ab Initio KSH orchestration scripts.

Attached KSH files: run_orders_pipeline.ksh, setup_env.ksh

Target platform: Databricks Workflow

Generate:
1. deployment/databricks_workflow_orders_pipeline.json
2. src/pyspark/utils/file_operations.py
3. src/pyspark/tasks/post_load_validation.py
4. config/pipeline_env_config.yaml

Output the HANDOFF BLOCK for @ABPYSignoff.
```

#### Validation (after converter handoff + tests must PASS before continuing)
```
@ABPYValidator

[PASTE FULL HANDOFF BLOCK FROM @ABPYConverter HERE]

Generate a complete reconciliation test suite.

Attached files:
- Job file    : src/pyspark/jobs/orders_processing.py
- Schema file : src/pyspark/schemas/orders_schema.py

Generate: src/pyspark/tests/test_orders_processing_reconciliation.py

Ensure all 7 test classes are included.
Output the updated HANDOFF BLOCK for @ABPYPerfSec.
```

#### Performance & security hardening
```
@ABPYPerfSec

[PASTE FULL HANDOFF BLOCK FROM @ABPYValidator HERE]

Review the converted job for performance and security.

Attached: src/pyspark/jobs/orders_processing.py

Data profile:
- Input records  : 500M
- Input size     : 200GB
- Cluster size   : 20 nodes × 32 cores × 64GB RAM
- SLA target     : 45 minutes

Run both checklists. Apply all CRITICAL and HIGH fixes inline.
Output the updated HANDOFF BLOCK for @ABPYSignoff.
```

#### Final sign-off
```
@ABPYSignoff

[PASTE HANDOFF BLOCK FROM @ABPYPerfSec HERE]
[IF KSH: ALSO PASTE HANDOFF BLOCK FROM @ABPYOrchestrator]

Final sign-off review.

Attached:
- Job file      : src/pyspark/jobs/orders_processing.py
- Schema files  : src/pyspark/schemas/orders_schema.py
- Config file   : config/orders_processing_config.yaml
- Test file     : src/pyspark/tests/test_orders_processing_reconciliation.py
- Test results  : [PASTE full pytest -v output]

Produce the 20-item checklist and conversion-log.md entry. GO or NO-GO.
```

---

## Library 2 — Angular → React Migration

### Agent Map

```
User
  │ @MigrateOrchestrator scaffold / migrate [module] / what's next
  ▼
@MigrateOrchestrator      ← ONLY entry point — drives everything
  │
  ├─▶ @MigrateScaffold    ← Run ONCE at project start
  │
  └─▶ [Per module pipeline]
        │ @MigrateAuditor     ← Pre-migration Angular analysis
        │ @MigrateCoder       ← Angular → React translation
        │ @MigrateTester      ← Vitest/Jest tests (100% coverage)
        │ @MigrateReviewer    ← 8 quality gates
        └─▶ Runability check (type-check + build + HTTP 200)
```

### Agents

| Agent | @Name | Role |
|-------|-------|------|
| MigrateOrchestrator | `@MigrateOrchestrator` | **ONLY entry point** — drives entire pipeline |
| MigrateScaffold | `@MigrateScaffold` | React project setup (run once) |
| MigrateAuditor | `@MigrateAuditor` | Pre-migration Angular analysis |
| MigrateCoder | `@MigrateCoder` | Angular → React translation |
| MigrateTester | `@MigrateTester` | Vitest/Jest tests + 100% coverage |
| MigrateReviewer | `@MigrateReviewer` | 8-gate quality review |

> **Important:** Sub-agents (`MigrateScaffold`, `MigrateAuditor`, `MigrateCoder`,
> `MigrateTester`, `MigrateReviewer`) are designed to be invoked by `@MigrateOrchestrator`.
> You CAN call them directly for targeted operations, but the orchestrator handles
> the full pipeline automatically.

### Examples

#### First time — scaffold the React project
```
@MigrateOrchestrator scaffold
```
The orchestrator will interview you about your project setup (CSS approach, bundler,
test runner, auth strategy, etc.) then invoke `@MigrateScaffold` to build the React foundation.

#### Migrate a specific module
```
@MigrateOrchestrator migrate feature-orders
```
Runs the full pipeline: Audit → Code → Test → Review → Runability check.

#### See what to migrate next
```
@MigrateOrchestrator what's next
```
Scores all unmigrated modules by complexity and dependency order.

#### Check overall migration status
```
@MigrateOrchestrator status
```

#### Rollback readiness check
```
@MigrateOrchestrator rollback feature-orders
```

#### Direct auditor invocation (targeted analysis)
```
@MigrateAuditor

Module: feature-orders
Source root: libs/feature-orders/src

Run a pre-migration audit. Produce AUDIT_SUMMARY_JSON.
```

#### Direct reviewer invocation (re-review after fixes)
```
@MigrateReviewer

Module: feature-orders
Mode: re-review
Gates failed previously: ESLint, Style & Assets

Re-run only the failed gates.
```

---

## Library 3 — Java → Python Migration

### Agent Map

```
@J2PyMaster
  │
  ├── Phase 0  → @J2PyAuditor      (Java codebase audit)
  ├── Phase 1  → @J2PyParser       (deep Java parse)
  ├── Phase 2  → @J2PyDepMapper    (dependency mapping)
  ├── Phase 3  → @J2PyGoNogo       ←── GATE 1: "GO {run_id}" or "STOP {run_id}"
  ├── Phase 4  → @J2PyTypePlanner  (type & pattern strategy)
  ├── Phase 5  → @J2PyConvExecutor (Python code generation)
  ├── Phase 6  → @J2PyTestGen      (pytest generation)
  ├── Phase 7  → @J2PyValidator    ←── GATE 2: "FINALIZE {run_id}" or "ABORT {run_id}"
  ├── Phase 8  → @J2PyReviewer     (review & cutover plan)
  └── Phase 9  → @J2PyReporter     (final report — terminal)
```

### Agents

| Agent | @Name | Phase | Role |
|-------|-------|-------|------|
| Pipeline Driver | `@J2PyMaster` | — | Entry point, drives all phases |
| Java Codebase Auditor | `@J2PyAuditor` | 0 | Build system + file inventory |
| Java Deep Parser | `@J2PyParser` | 1 | Class hierarchy + dependency graph |
| Dependency Mapper | `@J2PyDepMapper` | 2 | Java → Python dependency mapping |
| Go/No-Go Reporter | `@J2PyGoNogo` | 3 | Risk assessment + GATE 1 |
| Type Strategy Planner | `@J2PyTypePlanner` | 4 | Type system + pattern strategy |
| Conversion Executor | `@J2PyConvExecutor` | 5 | Python code generation |
| Test Generator | `@J2PyTestGen` | 6 | pytest test generation |
| Validator | `@J2PyValidator` | 7 | Import checks + pytest + GATE 2 |
| Reviewer | `@J2PyReviewer` | 8 | Code review + cutover plan |
| Final Reporter | `@J2PyReporter` | 9 | Final report (terminal) |

### Examples

#### Start a new migration
```
@J2PyMaster
Java source path: src/main/java
```

The master agent will:
1. Generate run ID (e.g., `J2PY-20260425-1430-A1B2`)
2. Run Phases 0–3 automatically
3. **PAUSE** and display the GO/NO-GO report:

```
┌─────────────────────────────────────────────┐
│  GO / NO-GO REPORT — Run ID: J2PY-20260425-1430-A1B2  │
├─────────────────────┬───────────────────────┤
│  Java files found   │ 47                    │
│  Estimated effort   │ 3–5 days              │
│  Hard blockers      │ 0                     │
│  Risk level         │ MEDIUM                │
│  Recommended action │ PROCEED WITH CAUTION  │
└─────────────────────┴───────────────────────┘
```

#### Approve conversion
```
GO J2PY-20260425-1430-A1B2
```

Phases 4–7 run automatically. Then GATE 2 pauses:

```
┌─────────────────────────────────────────────┐
│  VALIDATION REPORT — Run ID: J2PY-20260425-1430-A1B2  │
├─────────────────────┬───────────────────────┤
│  Files converted    │ 47                    │
│  Import checks      │ PASS                  │
│  pytest total       │ 312                   │
│  pytest passed      │ 308                   │
│  pytest failed      │ 4                     │
│  Files needing review│ 2                   │
└─────────────────────┴───────────────────────┘
```

#### Finalize (after reviewing validation report)
```
FINALIZE J2PY-20260425-1430-A1B2
```

#### Resume an interrupted run
```
@J2PyMaster
Run ID: J2PY-20260425-1430-A1B2. Resume Java-to-Python migration pipeline.
```

#### Run a specific phase directly
```
@J2PyConvExecutor

run_id: J2PY-20260425-1430-A1B2
Resume from Phase 5 — conversion executor.
```

---

## Library 4 — Tez → Spark Migration

### Agent Map

```
@TezMaster
  │
  ├── Phase 0  → @TezAuditor       (Tez evidence discovery)
  ├── Phase 1  → @TezPreBenchmark  (pre-conversion baseline)
  ├── Phase 2  → @TezReport        ←── GATE 1: "GO {run_id}" or "STOP {run_id}"
  ├── Phase 3  → @TezConfig        (Tez config → Spark config)
  ├── Phase 4  → @TezInterop       (Java interoperability plan)
  ├── Phase 5  → @TezConversion    (DAG topology → Spark)
  ├── Phase 6  → @TezOptimizer     (Spark optimization)
  ├── Phase 7  → @TezPlanDiff      (structural diff & risk)
  ├── Phase 8  → @TezExecution     (execute or dry-run)
  ├── Phase 9  → @TezDataContract  (output validation)
  ├── Phase 10 → @TezBenchmark     (performance comparison)
  ├── Phase 11 → @TezReview        ←── GATE 2: "FINALIZE {run_id}"
  └── Phase 12 → @TezReport        (final report — terminal)
```

### Agents

| Agent | @Name | Phase | Role |
|-------|-------|-------|------|
| Pipeline Orchestrator | `@TezMaster` | — | Entry point, drives all 13 phases |
| Tez Repository Archaeologist | `@TezAuditor` | 0 | Discover all Tez evidence |
| Pre-Benchmark Agent | `@TezPreBenchmark` | 1 | Capture Tez performance baseline |
| Report Agent | `@TezReport` | 2 & 12 | Initial GO/NO-GO + Final report |
| Config Agent | `@TezConfig` | 3 | Tez → Spark config mapping |
| Java Interop Agent | `@TezInterop` | 4 | Java class wrap/invoke strategy |
| Conversion Agent | `@TezConversion` | 5 | Tez DAG → Spark topology |
| Optimization Agent | `@TezOptimizer` | 6 | Spark-specific tuning |
| Plan Diff Agent | `@TezPlanDiff` | 7 | Structural risk assessment |
| Execution Agent | `@TezExecution` | 8 | Execute or dry-run |
| Data Contract Agent | `@TezDataContract` | 9 | Output schema + count validation |
| Benchmark Agent | `@TezBenchmark` | 10 | Perf comparison vs baseline |
| Review Agent | `@TezReview` | 11 | Review + cutover + rollback plan |

### Examples

#### Start a new migration
```
@TezMaster
Start Tez-to-Spark migration pipeline.
```

The master generates a run ID and runs Phases 0–2, then pauses at GATE 1:

```
✅ Phases 0-2 complete. Run ID: TEZ2SPK-20260425-1430-ABCD

Initial assessment: PROCEED — no hard blockers found
Top blockers: none

To continue to the migration build phases, reply:
  GO TEZ2SPK-20260425-1430-ABCD

To abort, reply:
  STOP TEZ2SPK-20260425-1430-ABCD
```

#### Approve migration build
```
GO TEZ2SPK-20260425-1430-ABCD
```

Phases 3–11 run automatically, pausing at GATE 2 with cutover recommendation.

#### Finalize and generate final report
```
FINALIZE TEZ2SPK-20260425-1430-ABCD
```

#### Resume an interrupted run
```
@TezMaster
Run ID: TEZ2SPK-20260425-1430-ABCD. Resume Tez-to-Spark migration pipeline.
```

#### Retry a failed phase
```
@TezConversion
run_id: TEZ2SPK-20260425-1430-ABCD
Retry Phase 5 — conversion agent.
```

---

## Handoff Block Protocol (ABPY Specific)

The ABPY library uses a HANDOFF BLOCK to pass state between agents.
This is the **only** shared state — agents do not share memory between sessions.

### Rules
1. Copy the ENTIRE block — never truncate
2. Paste at the TOP of the next prompt — before everything else
3. Never edit manually — only agents update it
4. Save each block to `conversion-notes.txt` immediately after receiving it

### What to do if an agent skips the HANDOFF BLOCK
```
You did not produce the HANDOFF BLOCK. Add it now.
```

---

## Common Troubleshooting

### ABPY: "Record count mismatch"
- Check `JOIN_MODES` in handoff — was NULL key handling set correctly?
- Sort-merge joins use standard equality for nulls (they drop), not `eqNullSafe()`

### ABPY: "UNRESOLVED_DML in handoff"
Stop. Do not proceed to `@ABPYConverter`. Resolve the DML function manually
(e.g., `checksum()`, `serial_number()`) before continuing.

### Angular: "first_boot_verified not true"
Run `@MigrateOrchestrator scaffold` before migrating any modules.
Do not proceed until `nx serve` returns HTTP 200.

### Angular: Missing font files (STC004 gate failure)
Copy the font files from the Angular `assets/fonts/` folder to
`apps/[react_app_name]/public/assets/fonts/`. Then re-run `@MigrateReviewer`.

### Java-to-Python: Build system not detected
Ensure `pom.xml` or `build.gradle` is accessible at the Java source path.
The auditor scans for build descriptors before any other analysis.

### Java-to-Python: Resume after network interruption
```
@J2PyMaster
Run ID: J2PY-YYYYMMDD-HHMM-XXXX. Resume Java-to-Python migration pipeline.
```
The master agent finds the last completed phase and continues from there.

### Tez: "NEEDS_REVIEW emitted"
A Tez agent found evidence it cannot automatically resolve.
Check `failures.log` for the exact reason. Resolve manually, then retry the phase.

### Tez: "INVALID_HANDOFF"
An upstream artifact is missing or corrupt. The agent emits `rollback_to`.
Re-run the indicated agent, then re-invoke the failed agent.

---

## Agent Tools Reference

| Tool | Purpose |
|------|---------|
| `codebase` | Search and navigate the workspace codebase |
| `file_search` | Find files by name or pattern |
| `read_file` | Read file contents |
| `create_file` | Create new files |
| `replace_string_in_file` | Edit existing files |
| `run_command` | Execute shell commands (lint, test, build, serve) |

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0 | 2026-04-25 | Converted from dropdown to @-mention format. Fixed frontmatter. Fixed all invocation refs. Consolidated instructions. |
| 1.0 | — | Original zip: ABPY, angular-to-react-v3, java-to-python, tez-migration |
