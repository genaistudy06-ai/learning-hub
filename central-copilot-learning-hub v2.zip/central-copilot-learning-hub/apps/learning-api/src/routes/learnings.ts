// ─── Learnings Routes ─────────────────────────────────────────────────────────
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { saveLearning } from '../services/saveService.js';
import { searchLearnings } from '../services/searchService.js';
import { castVote } from '../services/voteService.js';
import { defaultStorage } from '../storage/storageFactory.js';

const SaveSchema = z.object({
  title:        z.string().min(3).max(120),
  summary:      z.string().min(10).max(500),
  solutionText: z.string().min(20),
  tags:         z.array(z.string()).min(1).max(10),
  skill:        z.enum(['angular','java','python','devops','sql','qa','general']),
  personaHints: z.array(z.enum(['angular','java','python','devops','sql','qa','general'])),
  authorId:     z.string(),
  tenantId:     z.string().optional(),
  repoScope:    z.string().optional(),
});

const SearchSchema = z.object({
  query:     z.string().min(2),
  skill:     z.enum(['angular','java','python','devops','sql','qa','general']),
  persona:   z.enum(['angular','java','python','devops','sql','qa','general']),
  limit:     z.coerce.number().min(1).max(20).optional(),
  tenantId:  z.string().optional(),
  repoScope: z.string().optional(),
});

const VoteSchema = z.object({
  userId: z.string(),
  action: z.enum(['UPVOTE','DOWNVOTE','OUTDATED','DUPLICATE']),
});

export async function learningsRoutes(app: FastifyInstance) {

  // POST /learnings — save a new learning
  app.post('/learnings', async (req, reply) => {
    const parsed = SaveSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation failed', details: parsed.error.flatten() });
    }
    const result = await saveLearning(parsed.data);
    const statusCode = result.outcome === 'SECRET_REJECTED' ? 422
                     : result.outcome === 'DUPLICATE'       ? 409
                     : 201;
    return reply.status(statusCode).send(result);
  });

  // GET /learnings/search — fuzzy search
  app.get('/learnings/search', async (req, reply) => {
    const parsed = SearchSchema.safeParse(req.query);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation failed', details: parsed.error.flatten() });
    }
    const results = await searchLearnings(parsed.data);
    return reply.send({ results, count: results.length });
  });

  // GET /learnings/:id — fetch single solution
  app.get('/learnings/:id', async (req, reply) => {
    const { id } = req.params as { id: string };
    const sol = await defaultStorage.getSolution(id);
    if (!sol) return reply.status(404).send({ error: 'Not found' });
    return reply.send(sol);
  });

  // POST /learnings/:id/vote — cast a vote
  app.post('/learnings/:id/vote', async (req, reply) => {
    const { id } = req.params as { id: string };
    const parsed = VoteSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation failed', details: parsed.error.flatten() });
    }
    const result = await castVote(id, parsed.data.userId, parsed.data.action);
    return reply.send(result);
  });

  // GET /learnings/:id/history — Phase 2 version history
  app.get('/learnings/:id/history', async (req, reply) => {
    const { id } = req.params as { id: string };
    const history = await defaultStorage.getSolutionHistory(id);
    return reply.send({ history });
  });

  // GET /clusters/:clusterId — fetch cluster with all solutions
  app.get('/clusters/:clusterId', async (req, reply) => {
    const { clusterId } = req.params as { clusterId: string };
    const cluster = await defaultStorage.getCluster(clusterId);
    if (!cluster) return reply.status(404).send({ error: 'Cluster not found' });
    const solutions = await Promise.all(
      cluster.solutionIds.map(id => defaultStorage.getSolution(id))
    );
    return reply.send({ cluster, solutions: solutions.filter(Boolean) });
  });
}
