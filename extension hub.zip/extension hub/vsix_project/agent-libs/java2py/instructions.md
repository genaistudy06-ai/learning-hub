# Java → Python Migration — Master Instructions
# Lib: java-to-python | Version: 1.0
# File: instructions.md
#
# ALL AGENTS inherit these rules automatically.
# Do not repeat these rules in individual agent files.
#
# QUICK START:
#   Type @J2PyMaster in chat with the Java source path.
#   The master agent generates a run ID and drives all 10 phases.
#
# AGENT CHAIN:
#   @J2PyMaster → drives → [J2PyAuditor → J2PyParser → J2PyDepMapper → J2PyGoNogo]
#                           → [GATE 1: User types GO {run_id}]
#                           → [J2PyTypePlanner → J2PyConvExecutor → J2PyTestGen → J2PyValidator]
#                           → [GATE 2: User types FINALIZE {run_id}]
#                           → [J2PyReviewer → J2PyReporter]

═══════════════════════════════════════════════════════════════════
SECTION 1 — GLOBAL PIPELINE RULES (inherited by all agents)
═══════════════════════════════════════════════════════════════════

# Java → Python Migration Pipeline — Global Instructions
# Inherited automatically by ALL agents. Do not duplicate any rule below in agent files.

---

## Run ID Format

`J2PY-YYYYMMDD-HHMM-XXXX`
Example: `J2PY-20260423-0930-A1B2`

- Generate at pipeline start if not supplied by the user.
- Use as the folder name under `migration-artifacts/runs/{run_id}/`.
- Every artifact, log entry, and output file must carry this run_id.

---

## Artifact Folder Layout

```
migration-artifacts/
  runs/
    {run_id}/
      00-audit/
        audit-report.json
        file-inventory.json
      01-java-parse/
        class-map.json
        dependency-graph.json
      02-dependency-map/
        dependency-mapping.json
        requirements.txt
        pyproject.toml
      03-go-nogo/
        go-nogo-report.json
      04-type-strategy/
        type-mapping.json
        pattern-strategy.json
      05-conversion/
        src/                   ← converted Python source files (mirror of Java package structure)
        conversion-log.json
      06-tests/
        tests/                 ← generated pytest files
        test-plan.json
      07-validation/
        validation-report.json
        pytest-output.txt
      08-review/
        review-report.json
        cutover-plan.md
        rollback-plan.md
      09-final-report/
        final-report.md
        final-summary.json
```

---

## Canonical Agent Pipeline

| Phase | Agent File                        | Key Output Artifact             |
|-------|-----------------------------------|---------------------------------|
| 0     | @J2PyAuditor               | audit-report.json, file-inventory.json |
| 1     | @J2PyParser           | class-map.json, dependency-graph.json |
| 2     | @J2PyDepMapper     | dependency-mapping.json, requirements.txt |
| 3     | @J2PyGoNogo      | go-nogo-report.json → **GATE 1** |
| 4     | @J2PyTypePlanner | type-mapping.json, pattern-strategy.json |
| 5     | @J2PyConvExecutor   | converted Python source files  |
| 6     | @J2PyTestGen        | pytest test files, test-plan.json |
| 7     | @J2PyValidator             | validation-report.json → **GATE 2** |
| 8     | @J2PyReviewer              | review-report.json, cutover-plan.md |
| 9     | @J2PyReporter        | final-report.md                 |

---

## Approval Gates

### GATE 1 — After Go/No-Go Report (Phase 3)
```
STOP. Display GO/NO-GO summary to user.
Emit: "Reply GO {run_id} to begin conversion or STOP {run_id} to abort."
Do not proceed until explicit user reply is received.
```

### GATE 2 — After Validation (Phase 7)
```
STOP. Display validation pass/fail summary to user.
Emit: "Reply FINALIZE {run_id} to proceed to review and cutover, or ABORT {run_id} to stop."
Do not proceed until explicit user reply is received.
```

---

## Repository Discovery Rules

When scanning a Java project, agents must look for:

| What to Find                | File Patterns                                |
|-----------------------------|----------------------------------------------|
| Java source files           | `**/*.java`                                  |
| Maven build descriptor      | `pom.xml`                                    |
| Gradle build descriptor     | `build.gradle`, `build.gradle.kts`, `settings.gradle` |
| Test sources                | `**/test/**/*.java`, `**/*Test.java`, `**/*Tests.java`, `**/*Spec.java` |
| Resource / config files     | `**/resources/**`, `application.properties`, `application.yml` |
| Spring boot config          | `**/application*.properties`, `**/application*.yml` |
| Dockerfile                  | `Dockerfile*`                                |
| CI configs                  | `.github/`, `.gitlab-ci.yml`, `Jenkinsfile`  |
| README                      | `README.md`, `README.txt`                    |

---

## Handoff Verification (Every Agent Must Do This Before Proceeding)

Before consuming any upstream artifact:
1. File exists at the expected path and is non-empty.
2. `run_id` field matches the current run_id.
3. Required top-level fields are present and not placeholder/null values.
4. Upstream `status` field equals `SUCCESS`.

On any failure:
- Set own status to `BLOCKED`.
- Emit `INVALID_HANDOFF` with `rollback_to` pointing to the failed upstream agent.
- Stop immediately. Do not attempt to proceed or guess missing data.

---

## Resume Logic (Every Agent Must Check This First)

```
1. Check if own output artifact already exists at the canonical path.
2. If it exists AND is valid AND run_id matches:
   → Set resume_mode: true
   → Skip all execution steps
   → Jump directly to AFTER COMPLETION block
3. If it does not exist OR is corrupt OR run_id mismatch:
   → Regenerate from scratch
```

This makes every pipeline run restartable from any agent without re-running completed phases.

---

## Standard Output Contract (JSON — Every Agent Produces This)

```json
{
  "run_id": "J2PY-YYYYMMDD-HHMM-XXXX",
  "generated_by": "<agent-file-name>",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS | FAILED | NEEDS_REVIEW | BLOCKED",
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": ["path/to/upstream/artifact.json"],
  "artifacts_produced": ["path/to/this/artifact.json"],
  "blocking_issues": [],
  "warnings": [],
  "confidence_score": 0.0,
  "rollback_to": "<agent-file-name or null>",
  "next_agent": "<agent-file-name>"
}
```

---

## Java → Python Conversion Standards

All agents must apply these standards consistently:

### Package / Module Mapping
- Java package `com.example.service` → Python module `example/service/`
- Java `src/main/java/` → Python `src/`
- Java `src/test/java/` → Python `tests/`
- Each Java class becomes a `.py` file with snake_case filename.
- `MyClass.java` → `my_class.py`
- Method names: `camelCase` → `snake_case`
- Constants: `UPPER_CASE` stays `UPPER_CASE`

### Type Mapping
| Java Type           | Python Equivalent            |
|---------------------|------------------------------|
| `int`, `Integer`    | `int`                        |
| `long`, `Long`      | `int`                        |
| `double`, `Double`  | `float`                      |
| `float`, `Float`    | `float`                      |
| `boolean`, `Boolean`| `bool`                       |
| `String`            | `str`                        |
| `char`, `Character` | `str` (single char)          |
| `byte[]`            | `bytes`                      |
| `void`              | `None`                       |
| `Object`            | `Any` (from typing)          |
| `List<T>`           | `list[T]`                    |
| `Map<K,V>`          | `dict[K, V]`                 |
| `Set<T>`            | `set[T]`                     |
| `Optional<T>`       | `T \| None` or `Optional[T]` |
| `T[]`               | `list[T]`                    |
| `Callable<T>`       | `Callable[..., T]`           |

### OOP Pattern Mapping
| Java Pattern           | Python Pattern                                    |
|------------------------|---------------------------------------------------|
| `interface`            | `Protocol` (typing) or ABC                        |
| `abstract class`       | `ABC` with `@abstractmethod`                      |
| `enum`                 | `Enum` from `enum` module                         |
| `implements`           | Inherit from Protocol/ABC                         |
| `extends`              | Normal inheritance                                |
| Generics `<T>`         | `TypeVar` from typing                             |
| `static` method        | `@staticmethod`                                   |
| `static` field         | Class-level variable                              |
| `final` field          | Convention: no reassignment + type hint           |
| `synchronized`         | `threading.Lock()`                                |
| `instanceof`           | `isinstance()`                                    |
| Constructor overloading| `@classmethod` factory methods or default args    |

### Framework Mapping
| Java Framework         | Python Equivalent                                 |
|------------------------|---------------------------------------------------|
| Spring Boot (REST)     | FastAPI or Flask                                  |
| Spring DI / IoC        | dependency-injector or manual DI                  |
| Spring Data JPA        | SQLAlchemy + Alembic                              |
| Spring Security        | FastAPI auth / python-jose                        |
| Spring Kafka           | confluent-kafka-python or aiokafka                |
| Hibernate              | SQLAlchemy ORM                                    |
| JUnit 5                | pytest                                            |
| Mockito                | pytest-mock / unittest.mock                       |
| Log4j / SLF4J          | Python `logging` module                           |
| Jackson (JSON)         | `json` stdlib or `pydantic`                       |
| Lombok `@Data`         | `@dataclass` or pydantic `BaseModel`              |
| Lombok `@Builder`      | `@dataclass` with builder pattern                 |

---

## Failure Logging Format

Every agent must append failures to `migration-artifacts/runs/{run_id}/pipeline.log`:

```
[TIMESTAMP] [AGENT: agent-XX-name] [SEVERITY: ERROR|WARN|INFO] <message>
[TIMESTAMP] [AGENT: agent-XX-name] [HANDOFF: INVALID] upstream=<agent> reason=<reason>
```

---

## Hard Stops — Always Block Progress

These conditions must halt any agent immediately with status `BLOCKED`:

1. **Invalid handoff** — upstream artifact missing, corrupt, or status ≠ SUCCESS.
2. **Zero Java files found** — audit found no `.java` files in the specified path.
3. **Build system undetected** — neither `pom.xml` nor `build.gradle` found AND no `.java` files in root.
4. **Circular dependency detected** — agent-01 detected a cycle that cannot be broken without manual intervention.
5. **Conversion confidence < 0.5** — agent-05 produced output with confidence below threshold → flag NEEDS_REVIEW on every file, do not auto-approve.
6. **All validation tests fail** — 0 pytest tests pass → hard stop before Gate 2.

---

## How to Start

```
@J2PyMaster
Start Java-to-Python migration pipeline. Java source path: <path>
```

That is the only prompt the user needs to type.


═══════════════════════════════════════════════════════════════════
SECTION 2 — QUICKSTART GUIDE
═══════════════════════════════════════════════════════════════════

# Java → Python Migration Pipeline — QUICKSTART

Read once. Never need to read again.

---

## 1. How to Start

Paste this single prompt into GitHub Copilot Chat:

```
@J2PyMaster
Start Java-to-Python migration pipeline. Java source path: <path-to-your-java-project>
```

Replace `<path-to-your-java-project>` with the root folder of your Java project (where `pom.xml` or `build.gradle` lives).

The pipeline runs automatically through Phase 0–3, then pauses for your approval.

---

## 2. Approval Gates (the only times you type something)

### GATE 1 — After Go/No-Go Report (Phase 3)
The agent presents a risk/complexity table. You reply:

| Reply | Meaning |
|-------|---------|
| `GO J2PY-YYYYMMDD-HHMM-XXXX` | Proceed with conversion |
| `STOP J2PY-YYYYMMDD-HHMM-XXXX` | Abort — too risky |

### GATE 2 — After Validation (Phase 7)
The agent presents pytest results and health status. You reply:

| Reply | Meaning |
|-------|---------|
| `FINALIZE J2PY-YYYYMMDD-HHMM-XXXX` | Proceed to cutover plan |
| `ABORT J2PY-YYYYMMDD-HHMM-XXXX` | Stop — get repair guide |

---

## 3. How to Resume a Failed Run

If any agent fails or Copilot session times out mid-pipeline:

```
@J2PyMaster
Run ID: J2PY-YYYYMMDD-HHMM-XXXX. Resume Java-to-Python migration pipeline.
```

The master agent will detect which phase completed last and resume from the next one.
No work is repeated. No artifacts are overwritten.

To resume from a specific phase directly:

```
#file:copilot-agents/@J2PyConvExecutor
Run ID: J2PY-YYYYMMDD-HHMM-XXXX. Continue migration pipeline.
```

---

## 4. Where to Find Your Output

All outputs are in: `migration-artifacts/runs/{run_id}/`

| What you want               | Where to find it                                    |
|-----------------------------|-----------------------------------------------------|
| Converted Python source     | `05-conversion/src/`                                |
| pytest test files           | `06-tests/tests/`                                   |
| requirements.txt            | `02-dependency-map/requirements.txt`                |
| pyproject.toml              | `02-dependency-map/pyproject.toml`                  |
| Go/No-Go report             | `03-go-nogo/go-nogo-report.json`                    |
| Validation results          | `07-validation/validation-report.json`              |
| pytest output log           | `07-validation/pytest-output.txt`                   |
| Cutover plan                | `08-review/cutover-plan.md`                         |
| Rollback plan               | `08-review/rollback-plan.md`                        |
| Final report                | `09-final-report/final-report.md`                   |
| Pipeline log                | `pipeline.log`                                      |

---

## 5. Pipeline Phases at a Glance

```
Phase 0  Audit          → Scan project, detect build system, frameworks, complexity
Phase 1  Java Parser    → Deep parse: classes, methods, types, patterns, dependencies
Phase 2  Dep Mapper     → Map Maven/Gradle deps → Python packages + requirements.txt
Phase 3  Go/No-Go       → Risk assessment + effort estimate ──► GATE 1 (you decide)
Phase 4  Type Strategy  → Plan type mapping, OOP strategy, DI, routes, entities
Phase 5  Conversion     → Write all Python files (the main event)
Phase 6  Test Generator → Convert JUnit → pytest, generate skeletons for coverage
Phase 7  Validator      → Syntax check + mypy + ruff + pytest run ──► GATE 2 (you decide)
Phase 8  Reviewer       → Cutover plan, rollback plan, quality score
Phase 9  Final Reporter → Full report + next steps
```

---

## 6. Quick Reference — Python Project Setup After Migration

```bash
cd migration-artifacts/runs/{run_id}

# Install dependencies
pip install -r 02-dependency-map/requirements.txt
pip install -r 02-dependency-map/requirements-test.txt

# Configure environment
cp 08-review/cutover-plan.md .   # contains .env.template
# Fill in .env with your actual values

# Run DB migrations (if JPA/Hibernate was used)
alembic upgrade head

# Run tests
pytest 06-tests/tests/ -v

# Start the server
uvicorn src.main:app --reload --port 8080
```

---

*That's it. One start prompt. Two gate replies. One resume prompt if needed.*
