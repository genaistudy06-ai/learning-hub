# ABPY — Ab Initio → PySpark Conversion Framework
# Master Instructions | Version: 2.0
# File: instructions.md
#
# USAGE IN EXTENSION:
#   All agents automatically inherit these instructions when loaded from agents.md.
#   Users invoke agents by typing @ABPYAnalyzer, @ABPYSchema, etc. in chat.
#
# AGENT INVOCATION MAP:
#   @ABPYAnalyzer    → 01-analyzer-agent  (ENTRY POINT — always start here)
#   @ABPYSchema      → 02-schema-agent    (layouts → StructType + config YAML)
#   @ABPYConverter   → 03a-converter-agent (PySpark job code)
#   @ABPYOrchestrator→ 03b-orchestration-agent (KSH → workflow — only if KSH present)
#   @ABPYValidator   → 04-validator-agent  (reconciliation tests)
#   @ABPYPerfSec     → 05-performance-security-agent (hardening)
#   @ABPYSignoff     → 06-signoff-agent   (final gate — 20-item checklist)

# Ab Initio → PySpark Conversion Framework
# MASTER INSTRUCTIONS
# Version: 2.0
# File: instructions.md

---

## WHAT THIS FRAMEWORK IS

A structured multi-agent pipeline that converts enterprise Ab Initio applications
to production-grade PySpark — covering graphs, DML, KSH orchestration, memory management,
partition strategy, join semantics, error handling, and full reconciliation.

Each agent has one job. Agents do not guess. Agents do not skip.
The HANDOFF BLOCK connects every agent — it is the only shared state.

---

## FRAMEWORK ARCHITECTURE

```
.github/agents/  (or reference from your extension lib)
├── INSTRUCTIONS.md                        ← You are here — read first, always
├── ABPYAnalyzer.md                   ← Deep analysis — 12 phases
├── ABPYSchema.md                     ← Layouts → StructType + config YAML
├── ABPYConverter.md                 ← PySpark job code — full fidelity
├── ABPYOrchestrator.md             ← KSH → Databricks workflow / Airflow DAG
├── ABPYValidator.md                  ← Reconciliation test suite
├── ABPYPerfSec.md       ← Hardening — perf + security
└── ABPYSignoff.md                    ← Final gate — 20-item checklist
```

### Agent Dependency Map

```
                     Ab Initio Files
                           │
                    ┌──────▼──────┐
                    │ 01-analyzer │  ← ALWAYS start here
                    └──────┬──────┘
                     Handoff ①
                    ┌──────▼──────┐
                    │ 02-schema   │  ← Schemas + config
                    └──────┬──────┘
                     Handoff ②
             ┌─────────────┴──────────────┐
             │                            │
      ┌──────▼──────┐              ┌──────▼──────┐
      │ 03a-convert │              │ 03b-orchestr│  ← Run in parallel if KSH present
      └──────┬──────┘              └──────┬──────┘
       Handoff ③                    Handoff ③b
             │                            │
      ┌──────▼──────┐                     │
      │ 04-validator│                     │
      └──────┬──────┘                     │
       Handoff ④                          │
      ┌──────▼──────┐                     │
      │ 05-perf-sec │                     │
      └──────┬──────┘                     │
       Handoff ⑤                          │
             └──────────┬─────────────────┘
                    ┌──────▼──────┐
                    │ 06-signoff  │  ← Receives both streams
                    └─────────────┘
```

---

## STEP-BY-STEP USAGE

### PREREQS — Do Once

**1. Place all agent files under `.github/agents/  (or reference from your extension lib)` and commit.**

**2. VS Code setup:**
```
- Version: 1.99 or later
- Extension: GitHub.copilot-chat (latest)
- Open the repo root as your workspace
- Sign in to GitHub Copilot
```

**3. How to invoke an agent:**
```
Ctrl+Shift+I  →  type @ABPYAnalyzer (or any agent name) directly in chat
```

**4. How to attach files:**
```
Click the paperclip icon in Copilot Chat → select files
Attach source files at each step — agents do NOT share memory between sessions
```

---

### STEP 1 — ANALYZE  (`ABPYAnalyzer`)

**When:** Every new graph. No exceptions.
**What to attach:** All `.mp`, `.dml`, `.xfr`, `.ksh`, layout, and param files.

```
@ABPYAnalyzer

Analyze the following Ab Initio application completely.
Do NOT write any PySpark code.

Attached files:
- Graph files  : [ATTACH ALL .mp FILES]
- DML files    : [ATTACH ALL .dml FILES]
- Layout files : [ATTACH LAYOUT FILES]
- Param files  : [ATTACH .mp PARAM FILES]
- KSH scripts  : [ATTACH .ksh FILES — if any]

Business context:
- Source system      : [Oracle / DB2 / Flat Files / Mixed]
- Target platform    : [Databricks / EMR / on-prem Spark]
- Data volume        : [rows and GB per run]
- SLA                : [minutes]
- Processing type    : [Batch / Incremental / CDC]
- Restart required   : [YES / NO]

Run all 12 analysis phases. Flag every UNKNOWN explicitly.
Produce the complete HANDOFF BLOCK at the end.
```

**Gate before moving to Step 2:**
- [ ] Component inventory complete — count matches your visual graph inspection
- [ ] JOIN_MODES identified for every join (SORT-MERGE / LOCAL / DATABASE)
- [ ] ROLLUP_MODES identified for every rollup (HASH-BASED / SORT-BASED)
- [ ] KSH_FILES_PRESENT correctly set (YES → also run Step 3b)
- [ ] No HIGH severity risk has status UNKNOWN
- [ ] HANDOFF BLOCK produced

**Save the HANDOFF BLOCK to `conversion-notes.txt` now.**

---

### STEP 2 — SCHEMAS & CONFIG  (`ABPYSchema`)

**When:** After Step 1 HANDOFF BLOCK received.
**What to attach:** Same layout files + param files as Step 1.

```
@ABPYSchema

[PASTE FULL HANDOFF BLOCK FROM STEP 1 HERE]

Convert all Ab Initio layouts and parameter files.

Attached files:
- Layout files : [ATTACH .dml LAYOUT FILES]
- Param files  : [ATTACH .mp PARAM FILES]

Generate:
1. src/pyspark/schemas/[NAME]_schema.py for each layout
2. config/[JOB_NAME]_config.yaml
3. src/pyspark/utils/config_loader.py

Output the updated HANDOFF BLOCK for ABPYConverter.
```

**Gate before moving to Step 3:**
- [ ] Every Ab Initio layout has a corresponding `_schema.py` file
- [ ] No `inferSchema=True` anywhere
- [ ] All decimal fields use `DecimalType(p,s)` — no float/double on financial columns
- [ ] CHAR_PAD_FIELDS noted in handoff for converter to handle
- [ ] All secrets externalized (no literal credential values)
- [ ] HANDOFF BLOCK produced and saved

---

### STEP 3A — CONVERT  (`ABPYConverter`)

**When:** After Step 2 HANDOFF BLOCK received.
**What to attach:** Graph + DML files.

```
@ABPYConverter

[PASTE FULL HANDOFF BLOCK FROM STEP 2 HERE]

Convert the Ab Initio graph to a complete PySpark job.

Attached files:
- Graph file  : [ATTACH .mp FILE]
- DML files   : [ATTACH .dml FILES]

Before writing any code:
1. Read JOIN_MODES — apply correct pattern per join (SORT-MERGE / LOCAL / DATABASE)
2. Read ROLLUP_MODES — apply HASH vs SORT-BASED pattern
3. Read PARTITION_CHANGES — repartition at every DOP transition
4. Read ERROR_MODES — implement abort/skip/reject_limit per component
5. Read UNRESOLVED_DML — DO NOT approximate, flag and stop

Generate:
1. src/pyspark/jobs/[JOB_NAME].py
2. src/pyspark/utils/dml_functions.py
3. src/pyspark/utils/partition_utils.py
4. src/pyspark/utils/error_handler.py

Do NOT skip any component. Do NOT omit any reject port.
Output the updated HANDOFF BLOCK for ABPYValidator.
```

**Gate before moving to Step 4:**
- [ ] Every component from inventory has a PySpark equivalent
- [ ] SORT-MERGE joins: both sides repartitioned + sortWithinPartitions on same key
- [ ] LOCAL joins: F.broadcast() on the small side
- [ ] Each join with dual reject ports has BOTH left_anti and right_anti
- [ ] SORT-BASED rollups: upstream sort preserved as sortWithinPartitions before groupBy
- [ ] DOP=1 serial components: coalesce(1) NOT repartition(1)
- [ ] RejectAccumulator enforces MAX_ERRORS_GLOBAL
- [ ] Component-level reject_limits enforced
- [ ] CHAR_PAD_FIELDS: F.rpad() applied
- [ ] today() replaced with config.job.processing_date everywhere
- [ ] HANDOFF BLOCK produced and saved

---

### STEP 3B — ORCHESTRATION  (`ABPYOrchestrator`)

**When:** Run in parallel with Step 3A — ONLY if KSH_FILES_PRESENT=YES from Step 1.
**What to attach:** KSH files.

```
@ABPYOrchestrator

[PASTE FULL HANDOFF BLOCK FROM STEP 1 — KSH SECTION]

Convert the Ab Initio KSH orchestration scripts.

Attached KSH files: [ATTACH ALL .ksh / .sh FILES]

Target platform: [Databricks Workflow / Airflow DAG]

Generate:
1. deployment/[WORKFLOW_FILE]
2. src/pyspark/utils/file_operations.py
3. src/pyspark/tasks/post_load_[name].py (one per stored proc)
4. config/pipeline_env_config.yaml

Output the HANDOFF BLOCK for ABPYSignoff.
```

**Gate before moving to Step 6:**
- [ ] Every `ab_run` step is a workflow task
- [ ] Execution order matches KSH sequence exactly
- [ ] `-restart` steps are idempotent (dynamic partition overwrite or Delta MERGE)
- [ ] All stored proc calls preserved (JDBC or Spark SQL)
- [ ] All file operations preserved (archive/move/cleanup)
- [ ] PROCESSING_DATE is a workflow parameter, not hardcoded
- [ ] HANDOFF BLOCK produced and saved

---

### STEP 4 — VALIDATE  (`ABPYValidator`)

**When:** After Step 3A HANDOFF BLOCK received AND tests can be run.
**What to attach:** Job file + schema files.

```
@ABPYValidator

[PASTE FULL HANDOFF BLOCK FROM STEP 3A HERE]

Generate a complete reconciliation test suite.

Attached files:
- Job file    : [ATTACH src/pyspark/jobs/[JOB_NAME].py]
- Schema files: [ATTACH schema files]

Generate: src/pyspark/tests/test_[JOB_NAME]_reconciliation.py

Ensure all test classes are included:
- Record count (output + rejects per component)
- Schema match
- Data diff (zero tolerance)
- Aggregation totals (4dp)
- Null counts per column
- Duplicate key check
- Partition-level count validation
- Boundary value tests for DML expressions
- Dual reject port counts for SORT-MERGE joins

Output the updated HANDOFF BLOCK for ABPYPerfSec.
```

**Run tests — this is mandatory:**
```bash
pytest src/pyspark/tests/test_[JOB_NAME]_reconciliation.py -v --tb=short 2>&1 | tee test_results.txt
```

**Gate — DO NOT proceed to Step 5 if any test fails.**
Fix in Step 3A first. Document the root cause before re-running.

---

### STEP 5 — HARDEN  (`ABPYPerfSec`)

**When:** All Step 4 tests PASS.
**What to attach:** Final job file.

```
@ABPYPerfSec

[PASTE FULL HANDOFF BLOCK FROM STEP 4 HERE]

Review the converted job for performance and security.

Attached: [ATTACH src/pyspark/jobs/[JOB_NAME].py]

Data profile:
- Input records  : [from test run output]
- Input size     : [GB]
- Cluster size   : [nodes × cores × RAM]
- SLA target     : [minutes]

Run both checklists. Apply all CRITICAL and HIGH fixes inline.
Output the updated HANDOFF BLOCK for ABPYSignoff.
```

---

### STEP 6 — SIGN OFF  (`ABPYSignoff`)

**When:** Step 5 complete. If KSH present, Step 3B must also be complete.
**What to attach:** All final files + test results.

```
@ABPYSignoff

[PASTE HANDOFF BLOCK FROM STEP 5 HERE]
[IF KSH: ALSO PASTE HANDOFF BLOCK FROM STEP 3B]

Final sign-off review.

Attached:
- Job file      : [ATTACH final job .py]
- Schema files  : [ATTACH schema files]
- Config file   : [ATTACH config .yaml]
- Test file     : [ATTACH test file]
- Test results  : [PASTE full pytest -v output]
- Workflow file : [ATTACH if KSH was converted]

Produce the 20-item checklist and conversion-log.md entry.
GO or NO-GO with required actions if NO-GO.
```

---

## THE HANDOFF BLOCK — RULES

The HANDOFF BLOCK is the only shared state between agents.
Every agent produces one. Every agent reads the one from the previous step.

```
RULE 1: Copy the ENTIRE block — never truncate it
RULE 2: Paste at the TOP of the next prompt — before everything else
RULE 3: Never edit manually — only agents update it
RULE 4: Save each one to conversion-notes.txt immediately

RULE 5: If an agent skips the HANDOFF BLOCK output, say:
        "You did not produce the HANDOFF BLOCK. Add it now."

RULE 6: Do not carry a FAIL test status into Step 5 or 6.
        Fix → re-run → PASS → then proceed.

RULE 7: If UNRESOLVED_DML exists in the handoff:
        Stop. Resolve it manually or escalate.
        Do NOT let the converter approximate silently.
```

---

## WHAT EACH AGENT DOES AND DOES NOT DO

| Agent | Does | Does NOT Do |
|---|---|---|
| 01-analyzer | Reads all Ab Initio files, extracts DOP/join/sort/error metadata | Write any code |
| 02-schema | Converts layouts to StructType, params to YAML | Write job logic |
| 03a-converter | Writes PySpark job with full fidelity | Change business logic, touch orchestration |
| 03b-orchestration | Converts KSH to workflow definition | Convert graph components |
| 04-validator | Generates test suite | Modify job code |
| 05-perf-security | Reviews and fixes execution/security | Change business logic |
| 06-signoff | Reviews output, produces checklist | Generate any code |

---

## EFFICIENCY RULES

**One graph per session.** Don't attempt to convert multiple graphs in one Copilot thread.
Start a fresh chat for each graph.

**For large graphs (20+ components):**
Break into logical subgraphs:
- Ingestion layer (scans, initial reformats)
- Transform layer (joins, rollups, filters)
- Output layer (dedup, write components)

Run the full 6-agent pipeline on each subgraph independently.
Create a final orchestration job that calls each subgraph job in sequence.

**When a step goes wrong:**
Go back to the previous agent — not forward.
Add the error to your prompt:
```
The output had this problem: [describe exactly]
Fix only this issue. Reproduce everything else unchanged.
```

**Use `@workspace` to reference existing files:**
```
@ABPYConverter @workspace
[HANDOFF BLOCK]
Reference schema files already in src/pyspark/schemas/
```

**Run the analyzer on KSH files BEFORE graph files.** KSH reveals the execution order
and restart requirements that affect how graph conversion is structured.

**Flag UNRESOLVED_DML immediately.** Do not let agent 03a proceed with an approximation
for `checksum()`, `serial_number()`, or custom `reformat_string()` patterns.
These need human review or Ab Initio documentation before conversion.

---

## COMMON FAILURE MODES AND FIXES

| Failure | Root Cause | Fix |
|---|---|---|
| Record count mismatch | NULL keys dropped by join | Check JOIN_MODES — was it sort-merge with NULL EXCLUDE? Standard equality, not eqNullSafe |
| Sum mismatch on decimal fields | Float arithmetic precision loss | All DecimalType fields must use `.cast(DecimalType(18,4))` after every arithmetic operation |
| Duplicate records in output | Dedup not preserved correctly | Check SORT_CONSUMERS — was there a sort-dedup feeding this? Use row_number() window pattern |
| Output file ordering wrong | Sort not preserved | Check SORT_CONSUMERS — sort feeding output must be preserved, not skipped |
| Right-side records missing | Dual reject port not implemented | Sort-merge joins need BOTH left_anti AND right_anti |
| Job too slow | Missing co-partition before sort-merge join | Both sides must repartition on same hash key before sortWithinPartitions |
| Job OOM | Sort-based rollup without sortWithinPartitions | SORT-BASED rollup needs repartition + sortWithinPartitions before groupBy |
| Restart corrupts data | Idempotent write not implemented | -restart flag → dynamic partition overwrite or Delta MERGE |
| today() returns wrong date | Used F.current_date() | Replace with config.job.processing_date everywhere |
| CHAR field mismatch | Padding stripped | Apply F.rpad() to all CHAR_PAD_FIELDS before writing output |

---

## OUTPUT STRUCTURE — WHAT GETS GENERATED

After completing all steps:

```
src/
└── pyspark/
    ├── jobs/
    │   └── [JOB_NAME].py                        ← Agent 03a
    ├── schemas/
    │   ├── [INPUT_NAME]_schema.py                ← Agent 02
    │   └── [OUTPUT_NAME]_schema.py               ← Agent 02
    ├── utils/
    │   ├── config_loader.py                      ← Agent 02
    │   ├── spark_utils.py                        ← Agent 05
    │   ├── partition_utils.py                    ← Agent 03a
    │   ├── error_handler.py                      ← Agent 03a
    │   ├── dml_functions.py                      ← Agent 03a
    │   └── file_operations.py                    ← Agent 03b
    ├── tasks/
    │   └── post_load_[name].py                   ← Agent 03b
    └── tests/
        └── test_[JOB_NAME]_reconciliation.py     ← Agent 04

config/
├── [JOB_NAME]_config.yaml                        ← Agent 02
└── pipeline_env_config.yaml                      ← Agent 03b

deployment/
└── [WORKFLOW_FILE]                               ← Agent 03b (Databricks JSON or Airflow DAG)

docs/
└── conversion-log.md                             ← Agent 06
```

---

## QUICK REFERENCE — WHICH AGENT FOR WHAT

| Situation | Agent |
|---|---|
| Starting a new graph | 01 |
| Found a new DML file after analysis | 01 — re-run with the new file attached |
| Schema field type wrong | 02 |
| Config param missing | 02 |
| Component missing from job | 03a |
| Reject port not written | 03a |
| Join producing wrong count | 03a — check JOIN_MODES, NULL handling, dual rejects |
| Sort-merge join slow | 03a — verify co-partition on same key |
| Rollup producing wrong totals | 03a — check ROLLUP_MODES, sort-based vs hash-based |
| serial_number() behavior differs on restart | 03a — document deviation, flag in conversion-log |
| KSH script not converted | 03b |
| Stored proc call missing | 03b |
| Restart/idempotency needed | 03b |
| Need more tests | 04 |
| Test failing — data diff | 03a (debug) → 04 (re-run) |
| Job missing SLA | 05 |
| Security violation | 05 |
| Final review before production | 06 |
| Need to document a behavioral deviation | 06 |

---

*End of Master Instructions*
*Copilot: When any agent references INSTRUCTIONS.md, treat all rules in this file as binding.*
