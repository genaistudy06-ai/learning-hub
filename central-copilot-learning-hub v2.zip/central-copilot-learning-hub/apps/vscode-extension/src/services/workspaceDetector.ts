// ─── Workspace Detector ───────────────────────────────────────────────────────
import * as vscode from 'vscode';
import type { Skill, WorkspaceSignals } from '../../../../shared/types';

const EXT_SKILL_MAP: Record<string, Skill> = {
  '.ts': 'angular', '.html': 'angular', '.scss': 'angular',
  '.java': 'java',
  '.py': 'python',
  '.yaml': 'devops', '.yml': 'devops', '.dockerfile': 'devops',
  '.sql': 'sql',
  '.spec.ts': 'qa', '.test.ts': 'qa', '.spec.java': 'qa',
};

const KEYWORD_SKILL_MAP: Array<[RegExp, Skill]> = [
  [/angular|ng-|@component|ngrx/i, 'angular'],
  [/java|spring|maven|gradle/i, 'java'],
  [/python|django|flask|fastapi|pandas/i, 'python'],
  [/docker|kubernetes|helm|ci\/cd|pipeline|terraform/i, 'devops'],
  [/select|insert|update|delete|join|query/i, 'sql'],
  [/test|spec|assert|mock|stub|cypress/i, 'qa'],
];

export async function detectWorkspaceSignals(): Promise<WorkspaceSignals> {
  const editor = vscode.window.activeTextEditor;
  const activeFileExtension = editor?.document.fileName.split('.').pop();

  const workspaceFolders = vscode.workspace.workspaceFolders ?? [];
  const filesPresent: string[] = [];

  for (const folder of workspaceFolders) {
    try {
      const found = await vscode.workspace.findFiles(
        new vscode.RelativePattern(folder, '**/*.{ts,java,py,yaml,yml,sql}'),
        '**/node_modules/**',
        50
      );
      filesPresent.push(...found.map(f => f.fsPath));
    } catch { /* ignore */ }
  }

  const selection = editor?.document.getText(editor.selection);
  const promptKeywords = selection
    ? selection.split(/\s+/).filter(w => w.length > 3)
    : [];

  // Check for .github/copilot-instructions.md
  const instructionFiles = await vscode.workspace.findFiles(
    '**/.github/copilot-instructions.md', '**/node_modules/**', 1
  );
  const instructionFileName = instructionFiles[0]?.fsPath;

  const repoName = workspaceFolders[0]?.name;

  return { activeFileExtension, filesPresent, promptKeywords, instructionFileName, repoName };
}

export function inferSkill(signals: WorkspaceSignals): Skill {
  // 1. Try active file extension
  if (signals.activeFileExtension) {
    const extSkill = EXT_SKILL_MAP[`.${signals.activeFileExtension}`];
    if (extSkill) return extSkill;
  }

  // 2. Try keyword matching against prompt + file paths
  const haystack = [
    ...signals.promptKeywords,
    ...signals.filesPresent.map(f => f.split('/').pop() ?? ''),
  ].join(' ');

  for (const [pattern, skill] of KEYWORD_SKILL_MAP) {
    if (pattern.test(haystack)) return skill;
  }

  // 3. Fallback
  return 'general';
}
