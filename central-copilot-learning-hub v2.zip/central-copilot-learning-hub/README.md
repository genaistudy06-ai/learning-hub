# 📚 Central Copilot Learning Hub

A full-stack VS Code extension + REST API that lets engineering teams **save, search, vote on, and share** GitHub Copilot learnings — organised by skill, clustered automatically, and protected against secrets.

---

## 🏗️ Architecture

```
central-copilot-learning-hub/
├── shared/               # Types shared across all apps
├── apps/
│   ├── vscode-extension/ # VS Code extension (chat participant + commands)
│   └── learning-api/     # Fastify REST API (storage + search + votes)
└── github-app/           # Phase 3 — GitHub App for PR suggestions
```

---

## 🚀 Phase 1 — Core Extension + API

### 1. Set up the storage repo (GitHub)

Create a **private GitHub repo** (e.g. `your-org/copilot-learning-store`) with:
```
indexes/
solutions/
clusters/
votes/
```
You can leave the folders empty; the API will create files on first save.

Generate a **fine-grained PAT** with `Contents: Read & Write` on that repo.

### 2. Start the API

```bash
cd apps/learning-api
cp ../../.env.example .env
# Fill in GITHUB_TOKEN, GITHUB_OWNER, GITHUB_REPO
npm install
npm run dev
```

API runs at **http://localhost:3000**

#### Key endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET    | `/health` | Health check |
| POST   | `/api/v1/learnings` | Save a learning |
| GET    | `/api/v1/learnings/search?query=&skill=&persona=` | Search |
| POST   | `/api/v1/learnings/:id/vote` | Cast a vote |
| GET    | `/api/v1/learnings/:id` | Get a solution |
| GET    | `/api/v1/clusters/:id` | Get a cluster |

### 3. Install the VS Code Extension

```bash
cd apps/vscode-extension
npm install
npm run compile
```

Then press **F5** in VS Code to launch a development host, or:

```bash
npm run package   # produces .vsix
code --install-extension central-copilot-learning-hub-1.0.0.vsix
```

#### Configure in VS Code settings (`Ctrl+,`)
| Setting | Description |
|---------|-------------|
| `copilotLearningHub.apiUrl` | API URL (default `http://localhost:3000/api/v1`) |
| `copilotLearningHub.apiKey` | API key (leave blank in dev) |
| `copilotLearningHub.userId` | Your user/employee ID |
| `copilotLearningHub.offlineMode` | Enable offline queue |

### 4. Use the chat participant

Open GitHub Copilot Chat and type `@learning-hub`:

```
@learning-hub /search angular lazy loading
@learning-hub /save Fix NgRx state reset | Use initialState in reducer | const reducer = createReducer(initialState, ...) | angular,ngrx
@learning-hub /vote <solutionId> UPVOTE
@learning-hub /skill
```

### 5. Command Palette commands

- `Learning Hub: Save Learning` — guided save with input boxes
- `Learning Hub: Search Learning Hub` — quick-pick search
- `Learning Hub: Open Learning Hub Dashboard` — analytics webview
- `Learning Hub: Sync Offline Queue` — manual sync

---

## 📊 Phase 2 — Analytics + Version History

Analytics endpoints go live automatically once the API is running:

```
GET /api/v1/analytics           → All skills snapshot
GET /api/v1/analytics/angular   → Single skill snapshot
GET /api/v1/learnings/:id/history → Version history
```

Open the **Dashboard** via command palette to see:
- Active / Suppressed / High-Confidence counts per skill
- Top retrieved and top voted learnings

---

## 🏢 Phase 3 — Multi-tenant + GitHub App PR Suggestions

### Multi-tenant setup

```
POST /api/v1/tenants
{
  "orgName": "Acme Corp",
  "storageProvider": "s3",
  "storageConfig": { "bucket": "acme-learnings", "region": "us-east-1" },
  "plan": "enterprise"
}
```

Pass `tenantId` in all save/search requests to isolate data.

### GitHub App (PR suggestions)

1. Create a GitHub App in your org
2. Set webhook URL to `https://your-server:3001/webhook`
3. Subscribe to **Pull requests** events
4. Set env vars:

```bash
cd github-app
GITHUB_WEBHOOK_SECRET=... GITHUB_APP_TOKEN=... npm run dev
```

On every PR open/sync, the app searches the learning hub and posts matching learnings as a PR comment.

---

## 🔒 Security

- **Secret scanner** runs on every save — rejects learnings containing AWS keys, tokens, passwords, JWTs, connection strings, etc.
- Never store credentials in `solutionText`
- Use fine-grained PATs with minimum required permissions
- Rotate `GITHUB_WEBHOOK_SECRET` regularly

---

## 🏷️ Badge System

| Badge | Condition |
|-------|-----------|
| 🆕 New | No votes yet |
| 🏆 Highly Trusted | Score ≥ 10, ≥ 5 upvotes |
| ✅ Trusted | Score ≥ 4 |
| ⚖️ Mixed Reviews | Score 0–3 |
| ⚠️ Low Confidence | Score < 0 (auto-suppressed at ≤ -5) |

Score = `upvotes × 1.0 − downvotes × 1.5`

---

## 🧩 Skill Detection

Skill is auto-detected from the active editor's file extension and workspace file scan:

| Extension | Detected Skill |
|-----------|---------------|
| `.ts` / `.html` / `.scss` | `angular` |
| `.java` | `java` |
| `.py` | `python` |
| `.yaml` / `.yml` / `Dockerfile` | `devops` |
| `.sql` | `sql` |
| `.spec.ts` / `.test.java` | `qa` |
