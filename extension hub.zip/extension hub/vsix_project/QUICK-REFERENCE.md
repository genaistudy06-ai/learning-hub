# SDLC Agents v4 — Quick Reference

## First-time build from source
```bash
cd tools && node init-config.js          # 1. Generate secrets → prints _f1/_f2/_f3/_f4
```

> **IMPORTANT — Update secrets in ALL THREE files** (must all match):
> - `extension/src/licenseManager.ts` — replace `_f1/_f2/_f3/_f4` in the **constructor** (line ~65)
> - `extension/src/licenseManager.ts` — replace `_f1/_f2/_f3/_f4` in **`deriveContentKey()`** (line ~190)
> - `tools/license-gen.js` — replace `_f1/_f2/_f3/_f4` (line ~50)
>
> All three must have identical values or you will get **"Access code is invalid or has been tampered with"**.

```bash
# → Copy setenv.template to setenv.bat, fill in BUILD_SECRET_A + SIGNING_KEY_PASSWORD
node generate-keys.js                    # 2. Generate RSA signing key
cd ../extension && npm install           # 3. Install dependencies
cd .. && setenv.bat                      # 4. Load secrets into environment
build.bat                                # 5. Encode all packs + compile + sign + package
```

---

## Encode agent packs manually (if not using build.bat)

> Run these **after** `init-config.js` and **before** generating license codes.
> All `.bin` files in `extension/dat/` are placeholder stubs until this step is done.
> Skipping this step causes **"Activation failed. Please try again."** even with a valid code.

```bash
cd tools
set BUILD_SECRET_A=<your value from config.json>

# Main SDLC packs (core, engineering, governance, data, migration → a7e2.bin … e5a1.bin)
node dat-encoder.js --agents ../all-agents.md --instructions ../instructions.md

# Ab Initio to PySpark
node dat-encoder.js --input ../agent-libs/abpy/agents.md --pack-id abpy --output ../extension/dat/f6b1.bin --namespace abpy --instructions ../agent-libs/abpy/instructions.md

# Angular to React
node dat-encoder.js --input ../agent-libs/ang2react/agents.md --pack-id ang2react --output ../extension/dat/g7c2.bin --namespace ang2react --instructions ../agent-libs/ang2react/instructions.md

# Java to Python
node dat-encoder.js --input ../agent-libs/java2py/agents.md --pack-id java2py --output ../extension/dat/h8d3.bin --namespace java2py --instructions ../agent-libs/java2py/instructions.md

# Tez to Spark
node dat-encoder.js --input ../agent-libs/tez2spark/agents.md --pack-id tez2spark --output ../extension/dat/i9e4.bin --namespace tez2spark --instructions ../agent-libs/tez2spark/instructions.md
```

After encoding, verify each `.bin` is larger than a few KB (not 4 bytes).

---

## Rebuild after changing agents or agent libs
```bash
setenv.bat && build.bat
```

## Add a new agent lib (no TypeScript edits needed)
```bash
# 1. Create agent-libs\mylib\agents.md  (+ instructions.md optional)
# 2. Add encoding block to build.bat   (copy any existing lib block)
# 3. Add entry to extension\product.config.json  f1a2 array + g3h4 display names
# 4. Bump c5d6 version and rebuild
setenv.bat && build.bat
```

---

## Generate a license code

### Correct syntax
```bash
cd tools
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs <pack1,pack2,...>
```

> **Note:** The flags are `--machine-id` and `--expiry` (not `generate`, not `--machine`, not `--expires`).

### Get the machine ID
In VS Code → Command Palette → **SDLC Agents: Show Machine ID**

---

## License examples

### SDLC agents only
```bash
node license-gen.js \
  --machine-id <machineId> \
  --expiry 2026-12-31 \
  --packs core,engineering,data,governance \
  --self-learning
```

### Ab Initio to PySpark only  (@abpy)
```bash
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs abpy
```

### Angular to React only  (@ang2react)
```bash
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs ang2react
```

### Java to Python only  (@java2py)
```bash
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs java2py
```

### Tez to Spark only  (@tez2spark)
```bash
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs tez2spark
```

### Multiple migration libs on the same machine
```bash
# Two libs
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs abpy,ang2react

# All four migration libs
node license-gen.js --machine-id <machineId> --expiry 2026-12-31 --packs abpy,ang2react,java2py,tez2spark

# SDLC core + all migration libs
node license-gen.js \
  --machine-id <machineId> \
  --expiry 2026-12-31 \
  --packs core,engineering,data,governance,migration,abpy,ang2react,java2py,tez2spark \
  --self-learning
```

### Verify a code
```bash
node license-gen.js --verify SDLC-XXXXXXXX-XXXXXXXX-XXXXXXXXXXXX --machine-id <machineId>
```

### Bulk codes from CSV
```bash
node license-gen.js --bulk team.csv --output codes.csv
```

CSV format (header required):
```
name,machineId,expiry,packs,selfLearning,customStandards
Alice,a3f9c2b1...,2026-12-31,abpy+ang2react,false,false
Bob,7d2e4a8f...,2026-12-31,java2py,false,false
```

---

## Available pack names

| Pack name    | Namespace       | Description                                    | License bit |
|---|---|---|---|
| `core`       | `@sdlc-agents`  | SDLC core agents (PM, architect, scrum master) | 0 |
| `engineering`| `@sdlc-agents`  | Backend, frontend, QA, DevOps engineers        | 1 |
| `governance` | `@sdlc-agents`  | ARB, security, code review                     | 2 |
| `data`       | `@sdlc-agents`  | Data engineer, DB engineer, AbInitio, PySpark  | 3 |
| `migration`  | `@sdlc-agents`  | SDLC migration agents                          | 4 |
| `abpy`       | `@abpy`         | Ab Initio to PySpark (7 agents)                | 5 |
| `ang2react`  | `@ang2react`    | Angular to React (6 agents)                    | 6 |
| `java2py`    | `@java2py`      | Java to Python (11 agents)                     | 7 |
| `tez2spark`  | `@tez2spark`    | Tez to Spark (13 agents)                       | 8 |

---

## How to invoke migration agents

Migration agents do not appear in the dropdown. Type them directly in GitHub Copilot Chat:

```
@abpy.abpy-analyzer              <- Ab Initio to PySpark entry point
@ang2react.migrate-orchestrator  <- Angular to React entry point
@java2py.j2py-master             <- Java to Python entry point
@tez2spark.tez-master            <- Tez to Spark entry point
```

See `docs/AGENT-LIBS.md` for the full agent list and pipeline usage for each lib.

---

## Troubleshooting activation errors

| Error message | Cause | Fix |
|---|---|---|
| **"Access code is invalid or has been tampered with"** | `_f1/_f2/_f3/_f4` mismatch between `license-gen.js` and `licenseManager.ts` | Update all three locations with the same values from `init-config.js`. Regenerate the code after fixing. |
| **"This code is licensed for a different machine"** | Code was generated for a different `machineId` | Re-run `license-gen.js` with the correct `--machine-id` from **SDLC Agents: Show Machine ID** |
| **"Activation failed. Please try again."** | `.bin` files are 4-byte placeholders — `dat-encoder.js` was never run | Run all `dat-encoder.js` commands in the **Encode agent packs** section above, then rebuild and re-package. |
| **"Activation failed. Please try again."** (after encoding) | `_f1/_f2/_f3/_f4` in `licenseManager.ts` don't match `config.json` secrets used when encoding `.bin` files | Re-run `dat-encoder.js` after fixing the fragment values, or re-run `init-config.js` (warning: invalidates all existing codes). |
| **"System clock issue detected"** | System clock is behind the license issue date | Check system date/time settings. |
| **"License expired"** | Code expiry date has passed | Generate a new code with a future `--expiry` date. |

---

## Start central learning API (local dev)
```bash
cd api && npm install && cp .env.example .env && node server.js
node test-api.js   # run tests
```

## Key directories
| Path | Purpose |
|------|---------|
| `extension/src/` | TypeScript source |
| `extension/dat/` | Encrypted agent pack .bin files (must be encoded by dat-encoder.js) |
| `extension/keys/` | RSA signature files (generated by sign-build.js) |
| `tools/` | Build tools — never ship |
| `tools/config.json` | Generated secrets — never commit or share |
| `api/` | Central learning API — Node.js |
| `agent-libs/abpy/` | Ab Initio to PySpark agent source + instructions |
| `agent-libs/ang2react/` | Angular to React agent source + instructions |
| `agent-libs/java2py/` | Java to Python agent source + instructions |
| `agent-libs/tez2spark/` | Tez to Spark agent source + instructions |
| `docs/AGENT-LIBS.md` | Migration agent lib full documentation |
| `all-agents.md` | Main SDLC agent definitions (22 agents) |
| `instructions.md` | Global instructions injected into every SDLC agent |
