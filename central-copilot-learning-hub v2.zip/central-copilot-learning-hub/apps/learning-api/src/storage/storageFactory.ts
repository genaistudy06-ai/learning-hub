// ─── Storage Factory (Phase 3) ────────────────────────────────────────────────
// Returns the correct storage adapter based on env config or tenant config.

import { GitHubStorageAdapter } from './githubAdapter.js';
import { S3StorageAdapter } from './s3Adapter.js';
import type { StorageProvider } from '../../../../shared/types.js';

export type StorageAdapter = GitHubStorageAdapter | S3StorageAdapter;

export function createStorageAdapter(
  provider: StorageProvider = 'github',
  config?: Record<string, string>
): StorageAdapter {
  switch (provider) {
    case 'github':
      return new GitHubStorageAdapter({
        token: config?.token ?? process.env.GITHUB_TOKEN!,
        owner: config?.owner ?? process.env.GITHUB_OWNER!,
        repo:  config?.repo  ?? process.env.GITHUB_REPO!,
        branch: config?.branch ?? process.env.GITHUB_BRANCH ?? 'main',
      });

    case 's3':
    case 'r2':
      return new S3StorageAdapter({
        bucket: config?.bucket ?? process.env.S3_BUCKET!,
        region: config?.region ?? process.env.AWS_REGION ?? 'us-east-1',
        prefix: config?.prefix,
        accessKeyId: config?.accessKeyId ?? process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: config?.secretAccessKey ?? process.env.AWS_SECRET_ACCESS_KEY,
      });

    default:
      throw new Error(`Unsupported storage provider: ${provider}`);
  }
}

// Default shared adapter (Phase 1 & 2)
export const defaultStorage = createStorageAdapter(
  (process.env.STORAGE_PROVIDER as StorageProvider) ?? 'github'
);
