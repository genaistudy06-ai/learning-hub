## Teach Agents Your Project Rules

Use `/learn` to teach any agent a fact that should always apply to your codebase:

```
@sdlc-agents.db-engineer /learn Always use BRIN indexes for append-only audit tables in this project
@sdlc-agents.senior-backend-engineer /learn All API responses use { data, meta, errors } envelope
@sdlc-agents.python-engineer /learn This project uses FastAPI with async/await throughout — never sync
```

User-taught learnings have higher priority than auto-extracted ones and are never auto-pruned.
