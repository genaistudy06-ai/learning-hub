// ─── S3 Storage Adapter (Phase 3) ────────────────────────────────────────────
import {
  S3Client, GetObjectCommand, PutObjectCommand, ListObjectsV2Command
} from '@aws-sdk/client-s3';
import type { SkillIndex, Solution, Cluster, VoteRecord, Skill } from '../../../../shared/types.js';

export interface S3StorageConfig {
  bucket: string;
  region: string;
  prefix?: string;
  accessKeyId?: string;
  secretAccessKey?: string;
}

export class S3StorageAdapter {
  private s3: S3Client;
  private bucket: string;
  private prefix: string;

  constructor(cfg: S3StorageConfig) {
    this.bucket = cfg.bucket;
    this.prefix = cfg.prefix ?? 'learning-hub/';
    this.s3 = new S3Client({
      region: cfg.region,
      ...(cfg.accessKeyId && {
        credentials: {
          accessKeyId: cfg.accessKeyId,
          secretAccessKey: cfg.secretAccessKey!,
        },
      }),
    });
  }

  private key(path: string): string {
    return `${this.prefix}${path}`;
  }

  private async readJson<T>(path: string): Promise<T | null> {
    try {
      const res = await this.s3.send(new GetObjectCommand({
        Bucket: this.bucket,
        Key: this.key(path),
      }));
      const body = await res.Body?.transformToString();
      return body ? JSON.parse(body) : null;
    } catch (e: any) {
      if (e.name === 'NoSuchKey') return null;
      throw e;
    }
  }

  private async writeJson<T>(path: string, data: T): Promise<void> {
    await this.s3.send(new PutObjectCommand({
      Bucket: this.bucket,
      Key: this.key(path),
      Body: JSON.stringify(data, null, 2),
      ContentType: 'application/json',
    }));
  }

  async getSkillIndex(skill: Skill): Promise<SkillIndex | null> {
    return this.readJson(`indexes/${skill}-index.json`);
  }

  async saveSkillIndex(index: SkillIndex): Promise<void> {
    await this.writeJson(`indexes/${index.skill}-index.json`, {
      ...index, version: (index.version ?? 0) + 1, updatedAt: new Date().toISOString(),
    });
  }

  async getSolution(solutionId: string): Promise<Solution | null> {
    return this.readJson(`solutions/${solutionId}.json`);
  }

  async saveSolution(solution: Solution): Promise<void> {
    await this.writeJson(`solutions/${solution.id}.json`, solution);
  }

  async listSolutionIds(): Promise<string[]> {
    const res = await this.s3.send(new ListObjectsV2Command({
      Bucket: this.bucket,
      Prefix: this.key('solutions/'),
    }));
    return (res.Contents ?? [])
      .map(o => o.Key?.replace(this.key('solutions/'), '').replace('.json', '') ?? '')
      .filter(Boolean);
  }

  async getCluster(clusterId: string): Promise<Cluster | null> {
    return this.readJson(`clusters/${clusterId}.json`);
  }

  async saveCluster(cluster: Cluster): Promise<void> {
    await this.writeJson(`clusters/${cluster.id}.json`, cluster);
  }

  async listClusters(skill?: Skill): Promise<Cluster[]> {
    const res = await this.s3.send(new ListObjectsV2Command({
      Bucket: this.bucket,
      Prefix: this.key('clusters/'),
    }));
    const ids = (res.Contents ?? [])
      .map(o => o.Key?.replace(this.key('clusters/'), '').replace('.json', '') ?? '')
      .filter(Boolean);
    const clusters = await Promise.all(ids.map(id => this.getCluster(id)));
    const valid = clusters.filter((c): c is Cluster => c !== null);
    return skill ? valid.filter(c => c.skill === skill) : valid;
  }

  async getVoteRecord(solutionId: string): Promise<VoteRecord | null> {
    return this.readJson(`votes/${solutionId}.json`);
  }

  async saveVoteRecord(record: VoteRecord): Promise<void> {
    await this.writeJson(`votes/${record.solutionId}.json`, record);
  }
}
