## Talk to Your First Agent

Open Copilot Chat (`Ctrl+Shift+I`) and type `@sdlc-agents.` to see all available agents.

**Try these to start:**
```
@sdlc-agents.sdlc-orchestrator start project "My App"
@sdlc-agents.senior-backend-engineer implement UserService with CRUD
@sdlc-agents.db-engineer optimise this slow query
@sdlc-agents.python-engineer implement a FastAPI endpoint for payments
```
