// ─── Badge Engine ─────────────────────────────────────────────────────────────
import type { Badge, LearningStatus } from '../../../../shared/types.js';

export interface VoteSummary {
  upvotes: number;
  downvotes: number;
  retrievalCount: number;
}

/** Score = upvotes * 1.0 - downvotes * 1.5  (weighted per PRD) */
export function computeCommunityScore(v: VoteSummary): number {
  return v.upvotes * 1.0 - v.downvotes * 1.5;
}

export function computeBadge(v: VoteSummary): Badge {
  const total = v.upvotes + v.downvotes;
  const score = computeCommunityScore(v);

  if (total === 0) return 'New';
  if (score >= 10 && v.upvotes >= 5) return 'Highly Trusted';
  if (score >= 4)                    return 'Trusted';
  if (score < 0)                     return 'Low Confidence';
  return 'Mixed Reviews';
}

export function computeStatus(v: VoteSummary, retrievals: number): LearningStatus {
  const score = computeCommunityScore(v);
  if (score >= 15 && retrievals >= 10) return 'HIGH_CONFIDENCE';
  if (score <= -5)                     return 'SUPPRESSED';
  return 'ACTIVE';
}
