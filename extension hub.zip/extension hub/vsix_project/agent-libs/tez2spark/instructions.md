# Tez → Spark Migration — Master Instructions
# Lib: tez-migration | Version: 1.0
# File: instructions.md
#
# ALL AGENTS inherit these rules automatically.
# Do not repeat these rules in individual agent files.
#
# QUICK START:
#   Type @TezMaster in chat to start.
#   The master agent generates a run ID and drives all 13 phases.
#
# PIPELINE GATES:
#   GATE 1 (after Phase 2): User replies "GO {run_id}" to begin migration build
#   GATE 2 (after Phase 11): User replies "FINALIZE {run_id}" to generate final report
#
# RESUME:
#   @TezMaster
#   Run ID: TEZ2SPK-YYYYMMDD-HHMM-ABCD. Resume Tez-to-Spark migration pipeline.

═══════════════════════════════════════════════════════════════════
SECTION 1 — GLOBAL PIPELINE RULES (inherited by all agents)
═══════════════════════════════════════════════════════════════════

# Global Copilot Instructions — Tez-to-Spark Migration

## Purpose
Drive a safe, restartable Tez-to-Spark migration using the repository as the sole source of truth.
All agents inherit the rules in this file — they are not repeated in individual agent files.

---

## Working Model
- Discover all evidence directly from the repository. Never require a separate input folder.
- Persist all artifacts under `migration-artifacts/runs/{run_id}/`.
- Never modify Java business-logic classes (processors, combiners, partitioners, helpers) unless the user explicitly confirms a code change after review.
- Every claim must point to repository evidence or an upstream artifact. Never fabricate metrics or config values. Mark inferred values explicitly.

## Run ID Format
`TEZ2SPK-YYYYMMDD-HHMM-ABCD`  
Generate one at pipeline start if the user has not supplied one.

## Artifact Layout
```
migration-artifacts/
  runs/
    {run_id}/
      audit.json
      pre-benchmark.json
      report-initial.json
      sparkconf.json
      interop-plan.json
      spark-plan.json
      optimized-spark-plan.json
      plan-diff.json
      execution-report.json
      data-contract-results.json
      benchmark-results.json
      review.json
      report-final.json
      failures.log
```

## Canonical Agent Pipeline
| # | Agent file | Output artifact |
|---|---|---|
| 0 | TezAuditor | audit.json |
| 1 | TezPreBenchmark | pre-benchmark.json |
| 2 | TezReport | report-initial.json |
| 3 | TezConfig | sparkconf.json |
| 4 | TezInterop | interop-plan.json |
| 5 | TezConversion | spark-plan.json |
| 6 | TezOptimizer | optimized-spark-plan.json |
| 7 | TezPlanDiff | plan-diff.json |
| 8 | TezExecution | execution-report.json |
| 9 | TezDataContract | data-contract-results.json |
| 10 | TezBenchmark | benchmark-results.json |
| 11 | TezReview | review.json |
| 12 | TezReport | report-final.json |

## Approval Gates (pipeline pauses here for human GO / NO-GO)
- After Phase 2 (report-initial.json): GO / NO-GO before migration build begins.
- After Phase 11 (review.json): Cutover approval before final report.

---

## Rules All Agents Must Follow

### Repository Discovery
Before any analysis:
1. Scan the repo for the minimum file set relevant to this agent.
2. Record each discovered file: `path`, `file_type`, `reason`, `evidence_excerpt`.
3. If required evidence cannot be found, emit `NEEDS_REVIEW` and stop (do not proceed on guesses).

Priority targets:
- `tez-site.xml`, `hive-site.xml`, `core-site.xml`, `mapred-site.xml`
- DAG construction code, `org.apache.tez` imports, `Processor`, `Vertex`, `Edge`, `DAG`, `TezConfiguration`
- Custom UDF, UDAF, SerDe, partitioner, combiner classes
- `pom.xml`, `build.gradle`, dependency lock files
- Shell scripts, Airflow, Oozie, scheduler configs
- SQL files, Hive scripts, ETL jobs
- YARN, ATS, Tez, Spark, and job logs
- Test baselines and golden output fixtures

### Handoff Verification
Before consuming any upstream artifact:
- Confirm file exists and is non-empty.
- Confirm `run_id` matches.
- Confirm required fields are present and free of placeholder values.
- Confirm upstream `status` is `SUCCESS`.
- On failure → emit `INVALID_HANDOFF`, state `rollback_to`, and stop.

### Resume and Rollback
- If the target output artifact already exists and is valid → set `resume_mode: true` and reuse it.
- If it exists but is corrupt or incomplete → regenerate.
- Always include `rollback_to` in output.

### Standard Output Contract (every agent)
```json
{
  "run_id": "TEZ2SPK-YYYYMMDD-HHMM-ABCD",
  "generated_by": "<agent-name>",
  "status": "SUCCESS | FAILED | NEEDS_REVIEW | BLOCKED",
  "validation_passed": true,
  "resume_mode": false,
  "repo_scan_paths": [],
  "artifacts_consumed": [],
  "artifacts_produced": [],
  "blocking_issues": [],
  "warnings": [],
  "confidence_score": 0.0,
  "rollback_to": "<agent-name>",
  "next_agent": "<agent-name>"
}
```

### Failure Logging
Append to `migration-artifacts/runs/{run_id}/failures.log`:
```
[TIMESTAMP] AGENT={agent} STATE={state} FAILURE={type} REASON={exact_reason} ROLLBACK_TO={agent}
```

### Hard Stops — Do not continue if:
- No credible Tez evidence in the repo
- Upstream artifact validation fails
- Critical data mismatch found
- Rollback plan is missing
- Performance regression exceeds agreed threshold

---

## How to Start
Invoke the master agent with a single prompt:

```
@TezMaster
Start Tez-to-Spark migration pipeline.
```

The master agent generates the run ID, drives the pipeline, pauses at approval gates, and emits the exact next prompt after each phase.


═══════════════════════════════════════════════════════════════════
SECTION 2 — QUICKSTART GUIDE
═══════════════════════════════════════════════════════════════════

# QUICKSTART — Tez-to-Spark Migration

## Setup (one-time)
1. Open the source repository in VS Code.
2. Ensure `.copilot/instructions.md` and all files in `copilot-agents/` are present.
3. Create the output root: `migration-artifacts/runs/`

---

## Start a full migration run — one prompt

Paste this into GitHub Copilot Chat:

```
@TezMaster
Start Tez-to-Spark migration pipeline.
```

The master agent will:
- Generate a run ID automatically
- Run Phases 0–2 (audit → benchmark → initial report)
- **Pause and ask for GO / NO-GO**
- On GO, run Phases 3–11 (config → conversion → execution → validation → review)
- **Pause and ask for cutover approval**
- On FINALIZE, produce the final report

You type **3 prompts total** for a full pipeline run:
1. `@TezMaster` → Start
2. `GO {run_id}` → Approve migration build
3. `FINALIZE {run_id}` → Approve final report

---

## Supply your own run ID (optional)

```
@TezMaster
Start Tez-to-Spark migration pipeline. Run ID: TEZ2SPK-20260414-1030-A1B2
```

---

## Run a single agent standalone

Each agent is self-contained and will emit the next prompt at completion:

```
#file:copilot-agents/TezAuditor
Run ID: TEZ2SPK-20260414-1030-A1B2. Run this agent.
```

After completion, copy the exact prompt the agent emits and paste it to continue.

---

## Resume an interrupted run

```
@TezMaster
Resume migration pipeline. Run ID: TEZ2SPK-20260414-1030-A1B2
```

The master agent will check which artifacts exist, validate them, and continue from the next incomplete phase.

---

## Retry a failed agent

```
#file:copilot-agents/{failed-agent}.md
Run ID: {run_id}. Retry this agent.
```

---

## Output location
All artifacts are written to:
```
migration-artifacts/runs/{run_id}/
```

See `.copilot/instructions.md` for the full artifact layout, agent pipeline table, and global rules.

---

## Best first test
Start with one bounded Tez workflow:
- One DAG or small DAG family
- Limited custom Java
- Known output schema
- Stable test fixtures or golden outputs if available
