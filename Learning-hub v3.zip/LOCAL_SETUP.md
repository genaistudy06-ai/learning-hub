# 🚀 Central Copilot Learning Hub — Local Setup Guide

This guide gets both the **API** and the **VS Code Extension** running locally in minutes.
No GitHub token, no S3 bucket, no database — data is stored as JSON files.

---

## Prerequisites

| Tool | Version | Install |
|---|---|---|
| Node.js | 18 or higher | https://nodejs.org |
| npm | 8 or higher | (comes with Node.js) |
| VS Code | 1.90 or higher | https://code.visualstudio.com |
| GitHub Copilot | Any | VS Code Extensions marketplace |

---

## Part 1 — Run the Local API

### Step 1 — Go to the API directory

```bash
cd central-copilot-learning-hub/apps/learning-api
```

### Step 2 — Copy the local environment file

```bash
cp .env.local .env
```

The `.env.local` file sets `STORAGE_PROVIDER=local`, which stores all data as
JSON files in `./local-data/` — **no credentials needed**.

### Step 3 — Install dependencies

```bash
npm install
```

### Step 4 — Start the API

```bash
npm run dev
```

You should see:

```
📁 Using LOCAL JSON file storage (./local-data) — local dev only
🚀 Central Copilot Learning Hub API running on http://0.0.0.0:3000
```

### Step 5 — Verify the API is working

Open a new terminal and run:

```bash
# Health check
curl http://localhost:3000/health

# Expected response:
# {"status":"ok","version":"1.0.0","timestamp":"..."}
```

```bash
# Test saving a learning
curl -s -X POST http://localhost:3000/api/v1/learnings \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test learning from curl",
    "summary": "This is a test to verify the local API works correctly",
    "solutionText": "Just run curl and check the response — if you see solutionId it worked!",
    "tags": ["test"],
    "skill": "general",
    "personaHints": ["general"],
    "authorId": "local-dev-user"
  }' | python3 -m json.tool
```

```bash
# Test searching
curl -s "http://localhost:3000/api/v1/learnings/search?query=test&skill=general&persona=general" \
  | python3 -m json.tool
```

> **Data lives at:** `apps/learning-api/local-data/` — you can inspect the JSON files directly.

---

## Part 2 — Install the VS Code Extension (VSIX)

The VSIX is pre-built. You just need to install it.

### Step 6 — Install the VSIX in VS Code

**Option A — Command line (fastest):**

```bash
code --install-extension \
  central-copilot-learning-hub/apps/vscode-extension/central-copilot-learning-hub-1.0.0.vsix
```

**Option B — VS Code UI:**

1. Open VS Code
2. Press `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac)
3. Type `Extensions: Install from VSIX...`
4. Select the file: `apps/vscode-extension/central-copilot-learning-hub-1.0.0.vsix`
5. Click **Install**

### Step 7 — Reload VS Code

Press `Ctrl+Shift+P` → `Developer: Reload Window`

---

## Part 3 — Configure the Extension

The extension is **pre-configured** to talk to `http://localhost:3000/api/v1` by
default, so it works with the local API out of the box.

To verify or change settings:

1. Press `Ctrl+,` to open Settings
2. Search for `copilotLearningHub`
3. Check these values:

| Setting | Default (local) | Notes |
|---|---|---|
| `apiUrl` | `http://localhost:3000/api/v1` | Points to your local API |
| `apiKey` | _(empty)_ | Leave blank for local dev |
| `userId` | `local-dev-user` | Any string works locally |

---

## Part 4 — Use the Extension

### Starting the chat

1. Open GitHub Copilot Chat (`Ctrl+Shift+I`)
2. Type `@learning-hub` once to invoke the participant
3. After that first invocation, the participant is **sticky** — it stays active
   for the rest of the conversation so you never need to type `@` again

### Available commands — type naturally, no `/` needed

| What you type | What happens |
|---|---|
| `search angular lazy loading` | Searches for relevant learnings |
| `save Fix X \| Summary \| Solution code \| angular,routing` | Saves a new learning |
| `vote abc-123 UPVOTE` | Votes on a learning |
| `scaffold` | Creates `.github` folder structure |
| `skill` | Shows auto-detected skill from your workspace |

> **Tip:** Slash commands (`/search`, `/save`, etc.) also work if you prefer them.

### Command Palette commands (no chat needed)

Press `Ctrl+Shift+P` and search "Learning Hub":

- **Learning Hub: Save Learning to Hub** — guided save with input boxes
- **Learning Hub: Search Learning Hub** — quick-pick search
- **Learning Hub: Open Learning Hub Dashboard** — webview panel
- **Learning Hub: Scaffold .github Folder** — create `.github` structure

---

## Rebuilding the VSIX (if you change extension code)

If you modify any extension source files, rebuild the VSIX:

```bash
cd central-copilot-learning-hub/apps/vscode-extension

# Install dependencies (first time only)
npm install

# Compile TypeScript
npm run compile

# Package as VSIX
npm run package
# This creates central-copilot-learning-hub-1.0.0.vsix

# Install the new VSIX
code --install-extension central-copilot-learning-hub-1.0.0.vsix
```

Then reload VS Code (`Ctrl+Shift+P` → `Developer: Reload Window`).

---

## Troubleshooting

### API won't start — "Cannot find module"

```bash
cd apps/learning-api && npm install
```

### Extension not appearing in Copilot Chat

- Make sure GitHub Copilot extension is installed and you're signed in
- Reload VS Code after installing the VSIX
- Check Output panel: `View → Output → Central Copilot Learning Hub`

### "API unreachable" in chat

- Verify the API is running: `curl http://localhost:3000/health`
- Check the `copilotLearningHub.apiUrl` setting is `http://localhost:3000/api/v1`
- Enable **offline mode** in settings to queue saves locally when API is down

### Search returns no results

This is normal on a fresh install — the database is empty.
Save a few learnings first, then search.

### Where is my local data?

```
apps/learning-api/local-data/
├── solutions/      ← one JSON file per learning
├── clusters/       ← cluster groupings
├── indexes/        ← skill search indexes (angular, java, python, etc.)
├── votes/          ← vote records
└── manifests/      ← cluster manifests per skill
```

You can edit these JSON files directly for testing.

---

## Switching to a Real Backend Later

When you're ready to move off local storage, edit `apps/learning-api/.env`:

**GitHub (free, no infra):**
```env
STORAGE_PROVIDER=github
GITHUB_TOKEN=ghp_your_pat_here
GITHUB_OWNER=your-org
GITHUB_REPO=copilot-learning-store
GITHUB_BRANCH=main
```

**AWS S3 or Cloudflare R2:**
```env
STORAGE_PROVIDER=s3
S3_BUCKET=learning-hub-store
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
```

No code changes needed — just swap the env vars and restart the API.

---

## Quick Start Checklist

- [ ] Node.js 18+ installed
- [ ] `cd apps/learning-api && cp .env.local .env && npm install && npm run dev`
- [ ] `curl http://localhost:3000/health` returns `{"status":"ok",...}`
- [ ] VSIX installed in VS Code
- [ ] VS Code reloaded
- [ ] Copilot Chat open, typed `@learning-hub` once
- [ ] Tested `search test` — hub responds
- [ ] Tested `save My first learning | Testing the hub | It works! | general`
