// stateManager.ts — Activation state machine
// Code-only activation — no idx.bin, no .github writes.
import * as vscode from 'vscode';
import * as fs     from 'fs';
import * as path   from 'path';
import { LicenseManager } from './licenseManager';
import { AgentManager, AgentStatsCallback } from './agentManager';
import { UiManager      } from './uiManager';
import {
  ActivationState, ExpiryWarningLevel,
  LicenseFeatures, ProductConfig, WeeklyAgentStats,
} from './types';

const RECHECK_MS = 4 * 60 * 60 * 1000; // 4 hours

export class StateManager {
  private _state:    ActivationState = ActivationState.DORMANT;
  private _features: LicenseFeatures | undefined;
  private _timer:    NodeJS.Timeout | undefined;
  private _ui:       UiManager | undefined;

  // Weekly stats counters — reset each Monday
  private statsInvocations:      Record<string, number> = {};
  private statsDebate:           number = 0;
  private statsModelCalls:       Record<string, number> = {};
  private statsManualOverrides:  number = 0;
  private statsLearningsAuto:    number = 0;
  private statsLearningsUser:    number = 0;
  private statsLearningsRecalled:number = 0;
  private statsWeekStart:        Date   = this.currentWeekStart();

  readonly licenseManager: LicenseManager;
  agentManager:            AgentManager;
  readonly productConfig:  ProductConfig;

  constructor(private readonly ctx: vscode.ExtensionContext) {
    this.productConfig   = this.loadConfig();
    this.licenseManager  = new LicenseManager(ctx, this.productConfig);
    this.agentManager    = new AgentManager(ctx, this.productConfig, false, this.makeStatsCallback());
  }

  private makeStatsCallback(): AgentStatsCallback {
    return {
      recordInvocation: (id)             => this.recordInvocation(id),
      recordDebate:     ()               => this.recordDebate(),
      recordModelCall:  (id, isManual)   => this.recordModelCall(id, isManual),
      recordLearning:   (src)            => this.recordLearning(src),
      recordRecalled:   (n)              => this.recordLearningsRecalled(n),
    };
  }

  setUiManager(ui: UiManager): void { this._ui = ui; }

  get currentState(): ActivationState          { return this._state;    }
  get features():     LicenseFeatures | undefined { return this._features; }

  // ── Main activation flow (code-only) ─────────────────────────────────────
  async startActivationFlow(): Promise<void> {
    this.to(ActivationState.VALIDATING);
    try {
      // Run one-time migrations for version upgrades
      const prevVersion = this.ctx.globalState.get<string>('extensionVersion');
      const currVersion = this.productConfig.productVersion;
      if (prevVersion !== currVersion) {
        const lm = (this.agentManager as any).learningManager;
        if (lm) lm.runMigrations(prevVersion);
        await this.ctx.globalState.update('extensionVersion', currVersion);
      }

      // Verify extension file integrity
      const fileCheck = await this.licenseManager.verifyExtensionFiles();
      if (!fileCheck.valid) {
        this.to(ActivationState.BLOCKED_TAMPERED);
        this._ui?.showBlocked(ActivationState.BLOCKED_TAMPERED, '');
        return;
      }

      // Get or prompt for code
      const code = await this.getOrPromptCode();
      if (!code) {
        this.to(ActivationState.AWAITING_CODE);
        this._ui?.showActivationPanel();
        return;
      }

      // Validate code
      const machineId = vscode.env.machineId;
      const result    = await this.licenseManager.validateCode(code, machineId);

      if (!result.valid) {
        this.handleFailure(result.state, machineId, code);
        return;
      }

      this._features = result.features;

      // Re-initialise AgentManager with selfLearning flag from license
      const selfLearning = this._features!.selfLearning;
      this.agentManager  = new AgentManager(this.ctx, this.productConfig, selfLearning, this.makeStatsCallback());

      // Decrypt and inject agents
      this.to(ActivationState.DECRYPTING);
      const packs = await this.licenseManager.decryptAgentPacks(code, machineId, this._features!);

      this.to(ActivationState.INJECTING);
      await this.agentManager.injectAgents(packs);

      await this.licenseManager.updateLastVerifiedAt();
      this.to(ActivationState.ACTIVE);
      this._ui?.showActiveNotification(result.expiryLevel!, result.daysRemaining!, this._features!);
      this.startRecheckTimer();

    } catch (err) {
      if (typeof __IS_PRODUCTION__ !== 'undefined' && !__IS_PRODUCTION__) {
        console.error('[SDLC] activation error:', err);
      }
      vscode.window.showErrorMessage(`${this.productConfig.productName}: Activation failed. Please try again.`);
      this.to(ActivationState.DORMANT);
    }
  }

  async deactivate(): Promise<void> {
    this.to(ActivationState.DEACTIVATING);
    this.stopTimer();
    await this.agentManager.cleanupAgents();
    this._features = undefined;
  }

  async signOut(): Promise<void> {
    await this.licenseManager.clearCode();
    await this.deactivate();
    this.to(ActivationState.DORMANT);
  }

  // ── Learning management ───────────────────────────────────────────────────
  clearAllLearnings(): void {
    const lm = (this.agentManager as any).learningManager;
    if (!lm) return;
    for (const key of lm.listAgentKeys()) {
      lm.clear(key);
    }
  }

  clearAgentLearnings(agentKey: string): void {
    const lm = (this.agentManager as any).learningManager;
    if (lm) lm.clear(agentKey);
  }

  getLearningAgentKeys(): string[] {
    const lm = (this.agentManager as any).learningManager;
    return lm ? lm.listAgentKeys() : [];
  }

  // ── Stats tracking ────────────────────────────────────────────────────────
  recordInvocation(agentId: string): void {
    this.statsInvocations[agentId] = (this.statsInvocations[agentId] ?? 0) + 1;
  }

  recordDebate(): void { this.statsDebate++; }

  recordModelCall(modelId: string, isManual: boolean): void {
    this.statsModelCalls[modelId] = (this.statsModelCalls[modelId] ?? 0) + 1;
    if (isManual) this.statsManualOverrides++;
  }

  recordLearning(source: 'auto' | 'user'): void {
    if (source === 'auto') this.statsLearningsAuto++;
    else                   this.statsLearningsUser++;
  }

  recordLearningsRecalled(count: number): void {
    this.statsLearningsRecalled += count;
  }

  // ── Weekly stats export — v2 tracker format ───────────────────────────────
  getWeeklyStats(): WeeklyAgentStats {
    const now     = new Date();
    const wStart  = this.statsWeekStart;
    const wEnd    = new Date(wStart.getTime() + 6 * 24 * 60 * 60 * 1000);

    // ISO week label
    const weekLabel = `${wStart.getFullYear()}-W${String(this.isoWeekNumber(wStart)).padStart(2, '0')}`;

    // Determine dominant model tier
    const tierCounts = { '0x': 0, '1x': 0, '3x': 0 };
    for (const [modelId, count] of Object.entries(this.statsModelCalls)) {
      const tier = modelId.toLowerCase().includes('mini') ? '0x'
                 : (modelId.toLowerCase().includes('o1') || modelId.toLowerCase().includes('opus')) ? '3x'
                 : '1x';
      tierCounts[tier] += count;
    }
    const modelTier = (Object.entries(tierCounts).sort((a, b) => b[1] - a[1])[0][0]) as '0x' | '1x' | '3x';

    const cfg = vscode.workspace.getConfiguration('sdlcAgents');
    const learningMode = cfg.get<string>('learningMode', 'local') as 'local' | 'central';

    return {
      weekLabel,
      weekStart:            wStart.toISOString().slice(0, 10),
      weekEnd:              wEnd.toISOString().slice(0, 10),
      invocations:          { ...this.statsInvocations },
      totalInvocations:     Object.values(this.statsInvocations).reduce((a, b) => a + b, 0),
      debateSessions:       this.statsDebate,
      modelUsage:           { ...this.statsModelCalls },
      modelTier,
      manualOverrides:      this.statsManualOverrides,
      learningsAutoSaved:   this.statsLearningsAuto,
      learningsUserTaught:  this.statsLearningsUser,
      learningsRecalled:    this.statsLearningsRecalled,
      learningsPruned:      0, // populated by learningManager on prune
      learningMode,
      centralApiOk:         learningMode === 'central' ? null : null,
    };
  }

  resetWeeklyStats(): void {
    this.statsInvocations      = {};
    this.statsDebate           = 0;
    this.statsModelCalls       = {};
    this.statsManualOverrides  = 0;
    this.statsLearningsAuto    = 0;
    this.statsLearningsUser    = 0;
    this.statsLearningsRecalled= 0;
    this.statsWeekStart        = this.currentWeekStart();
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  private async getOrPromptCode(): Promise<string | undefined> {
    const saved = await this.licenseManager.getSavedCode();
    if (saved) return saved;

    const prefix = this.productConfig.accessCodePrefix;
    const input  = await vscode.window.showInputBox({
      title:          `${this.productConfig.productName} — Enter Access Code`,
      prompt:         `Format: ${prefix}-XXXXXXXX-XXXXXXXX-XXXXXXXXXXXX`,
      placeHolder:    `${prefix}-XXXXXXXX-XXXXXXXX-XXXXXXXXXXXX`,
      ignoreFocusOut: true,
      validateInput: (v: string) => {
        const n = v.toUpperCase().trim();
        if (!n) return null;
        const pattern = new RegExp(`^${prefix}-[A-F0-9]{8}-[A-F0-9]{8}-[A-F0-9]{12}$`);
        return pattern.test(n) ? null : `Format: ${prefix}-XXXXXXXX-XXXXXXXX-XXXXXXXXXXXX`;
      },
    });
    if (!input) return undefined;
    const code = input.toUpperCase().trim();
    await this.licenseManager.saveCode(code);
    return code;
  }

  private handleFailure(state: ActivationState, machineId: string, code: string): void {
    this.to(state);
    switch (state) {
      case ActivationState.BLOCKED_INVALID:
      case ActivationState.BLOCKED_TAMPERED:
        this.licenseManager.clearCode();
        vscode.window.showErrorMessage(
          `${this.productConfig.productName}: Access code is invalid or has been tampered with.`,
          'Try Again',
        ).then(c => { if (c === 'Try Again') this.startActivationFlow(); });
        break;
      case ActivationState.BLOCKED_MACHINE:
        vscode.window.showErrorMessage(
          `${this.productConfig.productName}: This code is licensed for a different machine. Contact your administrator.`,
        );
        break;
      case ActivationState.BLOCKED_CLOCK:
        vscode.window.showErrorMessage(
          `${this.productConfig.productName}: System clock issue detected. Check your date and time settings.`,
          'Retry',
        ).then(c => { if (c === 'Retry') this.startActivationFlow(); });
        break;
      default:
        this._ui?.showBlocked(state, machineId);
    }
  }

  private startRecheckTimer(): void {
    this.stopTimer();
    this._timer = setInterval(async () => {
      if (this._state !== ActivationState.ACTIVE) return;
      const code = await this.licenseManager.getSavedCode();
      if (!code) {
        await this.deactivate();
        this.to(ActivationState.AWAITING_CODE);
        this._ui?.showActivationPanel();
        return;
      }
      const r = await this.licenseManager.validateCode(code, vscode.env.machineId);
      if (!r.valid) {
        await this.deactivate();
        this.handleFailure(r.state, vscode.env.machineId, code);
      } else if (r.expiryLevel !== ExpiryWarningLevel.NONE) {
        this._ui?.showExpiryWarning(r.expiryLevel!, r.daysRemaining!);
      }
    }, RECHECK_MS);
  }

  private stopTimer(): void {
    if (this._timer) { clearInterval(this._timer); this._timer = undefined; }
  }

  private to(s: ActivationState): void {
    this._state = s;
    this._ui?.onStateChange(s);
  }

  private loadConfig(): ProductConfig {
    const p    = path.join(__dirname, '..', 'product.config.json');
    const raw  = JSON.parse(fs.readFileSync(p, 'utf-8'));
    // Map obfuscated keys to friendly interface properties
    return {
      ...raw,
      productId:         raw.a1f3,
      productName:       raw.b2e4,
      productVersion:    raw.c5d6,
      accessCodePrefix:  raw.e7f8,
      agentPacks:        raw.f1a2,
      agentDisplayNames: raw.g3h4,
      statusBarLabel:    raw.i5j6,
      activationCommand: raw.k7l8,
    } as ProductConfig;
  }

  private currentWeekStart(): Date {
    const d   = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff));
  }

  private isoWeekNumber(d: Date): number {
    const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
    return Math.ceil(((date.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  }
}

declare const __IS_PRODUCTION__: boolean;
