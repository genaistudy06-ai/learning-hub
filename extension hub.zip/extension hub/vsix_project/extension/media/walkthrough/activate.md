## Activate Your License

Run the activation command and paste your access code when prompted.

**Format:** `SDLC-XXXXXXXX-XXXXXXXX-XXXXXXXXXXXX`

Your administrator generates this code using your Machine ID.  
To get your Machine ID: **Ctrl+Shift+P → SDLC Agents: Show My Machine ID**
