@echo off
setlocal enabledelayedexpansion

echo.
echo =============================================
echo   SDLC Agents VSIX  ^|  Build Script
echo =============================================
echo.

rem ── Set all paths upfront ──────────────────────────────────────────────────
set ROOT=%~dp0
if "!ROOT:~-1!"=="\" set ROOT=!ROOT:~0,-1!

set TOOLS_DIR=!ROOT!\tools
set EXT_DIR=!ROOT!\extension
set AGENTS_FILE=!ROOT!\all-agents.md
set INSTR_FILE=!ROOT!\instructions.md

rem ── Agent lib source paths ──────────────────────────────────────────────────
set ABPY_AGENTS=!ROOT!\agent-libs\abpy\agents.md
set ABPY_INSTR=!ROOT!\agent-libs\abpy\instructions.md
set ANG2REACT_AGENTS=!ROOT!\agent-libs\ang2react\agents.md
set ANG2REACT_INSTR=!ROOT!\agent-libs\ang2react\instructions.md
set JAVA2PY_AGENTS=!ROOT!\agent-libs\java2py\agents.md
set JAVA2PY_INSTR=!ROOT!\agent-libs\java2py\instructions.md
set TEZ2SPARK_AGENTS=!ROOT!\agent-libs\tez2spark\agents.md
set TEZ2SPARK_INSTR=!ROOT!\agent-libs\tez2spark\instructions.md

rem ── Agent lib bin output paths ───────────────────────────────────────────────
set ABPY_BIN=!EXT_DIR!\dat\f6b1.bin
set ANG2REACT_BIN=!EXT_DIR!\dat\g7c2.bin
set JAVA2PY_BIN=!EXT_DIR!\dat\h8d3.bin
set TEZ2SPARK_BIN=!EXT_DIR!\dat\i9e4.bin

rem ── Check Node.js ──────────────────────────────────────────────────────────
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Node.js is not installed.
    echo Install from: https://nodejs.org  ^(choose the LTS version^)
    echo.
    pause & exit /b 1
)

rem ── Check BUILD_SECRET_A ───────────────────────────────────────────────────
if "!BUILD_SECRET_A!"=="" (
    echo ERROR: BUILD_SECRET_A is not set.
    echo.
    echo Did you run setenv.bat first?
    echo Copy setenv.template to setenv.bat, fill in your values, then run it.
    echo.
    pause & exit /b 1
)

echo [OK] Node.js found
echo [OK] BUILD_SECRET_A is set
echo.

rem ── Check all-agents.md ────────────────────────────────────────────────────
if not exist "!AGENTS_FILE!" (
    echo ERROR: all-agents.md not found.
    echo Expected at: !AGENTS_FILE!
    echo.
    pause & exit /b 1
)

rem ── Step 1: Encode main SDLC agents pack ────────────────────────────────────
echo [1/6] Encoding main SDLC agents into encrypted bin files...
pushd "!TOOLS_DIR!"

if exist "!INSTR_FILE!" (
    node dat-encoder.js --agents "!AGENTS_FILE!" --instructions "!INSTR_FILE!"
) else (
    echo   Note: instructions.md not found -- encoding agents without global instructions.
    node dat-encoder.js --agents "!AGENTS_FILE!"
)

if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: dat-encoder.js failed on main SDLC pack.
    echo   - Make sure tools\config.json exists ^(run: node tools\init-config.js^)
    echo   - Make sure all-agents.md is in the project root
    pause & exit /b 1
)
popd
echo.

rem ── Step 2: Encode ABPY agent lib (@abpy) ────────────────────────────────────
echo [2/6] Encoding ABPY agent lib ^(@abpy -- Ab Initio to PySpark^)...
if not exist "!ABPY_AGENTS!" (
    echo   SKIP: agent-libs\abpy\agents.md not found
) else (
    pushd "!TOOLS_DIR!"
    if exist "!ABPY_INSTR!" (
        node dat-encoder.js --input "!ABPY_AGENTS!" --pack-id abpy --output "!ABPY_BIN!" --instructions "!ABPY_INSTR!" --namespace abpy
    ) else (
        node dat-encoder.js --input "!ABPY_AGENTS!" --pack-id abpy --output "!ABPY_BIN!" --namespace abpy
    )
    if !ERRORLEVEL! neq 0 (
        popd
        echo.
        echo ERROR: dat-encoder.js failed on abpy pack.
        pause & exit /b 1
    )
    popd
)
echo.

rem ── Step 3: Encode Angular-React agent lib (@ang2react) ───────────────────────
echo [3/6] Encoding Angular-React agent lib ^(@ang2react^)...
if not exist "!ANG2REACT_AGENTS!" (
    echo   SKIP: agent-libs\ang2react\agents.md not found
) else (
    pushd "!TOOLS_DIR!"
    if exist "!ANG2REACT_INSTR!" (
        node dat-encoder.js --input "!ANG2REACT_AGENTS!" --pack-id ang2react --output "!ANG2REACT_BIN!" --instructions "!ANG2REACT_INSTR!" --namespace ang2react
    ) else (
        node dat-encoder.js --input "!ANG2REACT_AGENTS!" --pack-id ang2react --output "!ANG2REACT_BIN!" --namespace ang2react
    )
    if !ERRORLEVEL! neq 0 (
        popd
        echo.
        echo ERROR: dat-encoder.js failed on ang2react pack.
        pause & exit /b 1
    )
    popd
)
echo.

rem ── Step 4: Encode Java-Python agent lib (@java2py) ───────────────────────────
echo [4/6] Encoding Java-Python agent lib ^(@java2py^)...
if not exist "!JAVA2PY_AGENTS!" (
    echo   SKIP: agent-libs\java2py\agents.md not found
) else (
    pushd "!TOOLS_DIR!"
    if exist "!JAVA2PY_INSTR!" (
        node dat-encoder.js --input "!JAVA2PY_AGENTS!" --pack-id java2py --output "!JAVA2PY_BIN!" --instructions "!JAVA2PY_INSTR!" --namespace java2py
    ) else (
        node dat-encoder.js --input "!JAVA2PY_AGENTS!" --pack-id java2py --output "!JAVA2PY_BIN!" --namespace java2py
    )
    if !ERRORLEVEL! neq 0 (
        popd
        echo.
        echo ERROR: dat-encoder.js failed on java2py pack.
        pause & exit /b 1
    )
    popd
)
echo.

rem ── Step 5: Encode Tez-Spark agent lib (@tez2spark) ───────────────────────────
echo [5/6] Encoding Tez-Spark agent lib ^(@tez2spark^)...
if not exist "!TEZ2SPARK_AGENTS!" (
    echo   SKIP: agent-libs\tez2spark\agents.md not found
) else (
    pushd "!TOOLS_DIR!"
    if exist "!TEZ2SPARK_INSTR!" (
        node dat-encoder.js --input "!TEZ2SPARK_AGENTS!" --pack-id tez2spark --output "!TEZ2SPARK_BIN!" --instructions "!TEZ2SPARK_INSTR!" --namespace tez2spark
    ) else (
        node dat-encoder.js --input "!TEZ2SPARK_AGENTS!" --pack-id tez2spark --output "!TEZ2SPARK_BIN!" --namespace tez2spark
    )
    if !ERRORLEVEL! neq 0 (
        popd
        echo.
        echo ERROR: dat-encoder.js failed on tez2spark pack.
        pause & exit /b 1
    )
    popd
)
echo.

rem ── Step 6: Build extension ──────────────────────────────────────────────────
echo [6/6] Compiling TypeScript, bundling, signing, and packaging VSIX...
echo       ^(This takes 60-90 seconds -- obfuscation is slow by design^)

rem ── 6a: TypeScript compile + webpack bundle ──────────────────────────────────
echo   [6a] Compiling TypeScript...
pushd "!EXT_DIR!"
call npm run build
if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: Build failed. Common fixes:
    echo   - Run: cd extension ^&^& npm install
    echo   - Check _f1/_f2/_f3/_f4 values in src\licenseManager.ts
    echo   - Check TypeScript errors above
    pause & exit /b 1
)
popd
echo.

rem ── 6b: Sign the build ───────────────────────────────────────────────────────
echo   [6b] Signing extension files...
if not exist "!TOOLS_DIR!\signing-key.pem" (
    echo ERROR: tools\signing-key.pem not found.
    echo Run: node tools\generate-keys.js
    echo.
    pause & exit /b 1
)
pushd "!TOOLS_DIR!"
node sign-build.js --key signing-key.pem --ext "!EXT_DIR!" --password "!SIGNING_KEY_PASSWORD!"
if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: Signing failed.
    echo   - Check SIGNING_KEY_PASSWORD in setenv.bat ^(blank is OK if key has no passphrase^)
    echo   - Regenerate keys: node tools\generate-keys.js
    pause & exit /b 1
)
popd
echo.

rem ── 6c: Package VSIX ─────────────────────────────────────────────────────────
echo   [6c] Packaging as VSIX...
if not exist "!EXT_DIR!\package.json" (
    echo ERROR: Cannot find extension\package.json
    pause & exit /b 1
)

if not exist "!EXT_DIR!\node_modules\@vscode\vsce\vsce" (
    echo vsce not found -- running npm install...
    pushd "!EXT_DIR!"
    call npm install
    popd
)

pushd "!EXT_DIR!"
node node_modules\@vscode\vsce\vsce package --no-dependencies
if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: vsce package failed.
    echo   - Run: cd extension ^&^& npm install
    echo   - Make sure publisher in extension\package.json is not "your-name"
    pause & exit /b 1
)
popd

rem ── Done ─────────────────────────────────────────────────────────────────────
echo.
echo =============================================
echo   BUILD COMPLETE
echo =============================================
echo.
for %%f in ("!EXT_DIR!\*.vsix") do (
    echo   Output: %%f
    echo   Size:   %%~zf bytes
)
echo.
echo Agent libs included in this build:
echo   @sdlc-agents  -- core SDLC pipeline agents
echo   @abpy         -- Ab Initio to PySpark  ^(bit 5^)
echo   @ang2react    -- Angular to React       ^(bit 6^)
echo   @java2py      -- Java to Python         ^(bit 7^)
echo   @tez2spark    -- Tez to Spark           ^(bit 8^)
echo.
echo Next steps:
echo   1. Install the .vsix in VS Code
echo   2. Generate a license for your machine:
echo        cd tools
echo        node license-gen.js --machineId YOUR_ID --days 365 --packs abpy,ang2react
echo   3. In VS Code: run command  SDLC Agents: Activate
echo.
echo To add a new agent lib later:
echo   1. Create agent-libs\mylib\agents.md  ^(+ instructions.md optional^)
echo   2. Add encoding step to this build.bat  ^(copy one of the lib blocks above^)
echo   3. Add pack entry to extension\product.config.json  ^(f1a2 array + g3h4 names^)
echo   4. Run build.bat again
echo.
pause
