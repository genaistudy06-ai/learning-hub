// ─── Tenant Routes (Phase 3) ──────────────────────────────────────────────────
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { randomUUID } from 'crypto';
import type { Tenant } from '../../../../shared/types.js';

// In production replace with a DB-backed tenant store
const TENANT_STORE = new Map<string, Tenant>();

const CreateTenantSchema = z.object({
  orgName:         z.string().min(2),
  storageProvider: z.enum(['github','s3','azure','r2','postgres']),
  storageConfig:   z.record(z.string()),
  plan:            z.enum(['team','enterprise']),
});

export async function tenantRoutes(app: FastifyInstance) {

  // POST /tenants — register a new tenant
  app.post('/tenants', async (req, reply) => {
    const parsed = CreateTenantSchema.safeParse(req.body);
    if (!parsed.success) return reply.status(400).send({ error: 'Validation failed', details: parsed.error.flatten() });

    const tenant: Tenant = {
      id: randomUUID(),
      orgName: parsed.data.orgName,
      storageProvider: parsed.data.storageProvider,
      storageConfig: parsed.data.storageConfig,
      plan: parsed.data.plan,
      createdAt: new Date().toISOString(),
    };

    TENANT_STORE.set(tenant.id, tenant);
    return reply.status(201).send({ tenantId: tenant.id, message: 'Tenant registered' });
  });

  // GET /tenants/:tenantId
  app.get('/tenants/:tenantId', async (req, reply) => {
    const { tenantId } = req.params as { tenantId: string };
    const tenant = TENANT_STORE.get(tenantId);
    if (!tenant) return reply.status(404).send({ error: 'Tenant not found' });
    // Never return storageConfig secrets
    const { storageConfig: _omit, ...safe } = tenant;
    return reply.send(safe);
  });

  // GET /tenants — list all (admin only in production)
  app.get('/tenants', async (_req, reply) => {
    const tenants = [...TENANT_STORE.values()].map(({ storageConfig: _omit, ...safe }) => safe);
    return reply.send({ tenants });
  });
}
