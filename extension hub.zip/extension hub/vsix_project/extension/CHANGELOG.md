# SDLC Agents Changelog

## 3.0.0

- 17 enterprise SDLC agents across three packs: core, engineering, governance
- Self-learning memory system — agents improve output with each session
- Custom standards injection — agents read your coding-standards.md and component-library.md
- Framework auto-detection — frontend agent supports React 18/19, Next.js, Angular 18+, Vue 3
- Multi-mode invocation — solo, sequential pipeline, partial chain, parallel workstreams
- OWASP ASVS Level 2 embedded in all code-producing agents
- Proactive signals — agents surface issues you did not explicitly ask about
- Offline licence system with machine ID binding and 3-anchor clock tamper detection
- Config shield — 2-layer protection prevents instruction extraction
