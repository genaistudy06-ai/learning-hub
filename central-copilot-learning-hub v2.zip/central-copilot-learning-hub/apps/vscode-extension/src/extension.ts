// ─── Extension Entrypoint ─────────────────────────────────────────────────────
import * as vscode from 'vscode';
import { LearningHubClient } from './services/apiClient';
import { OfflineQueue } from './offline/offlineQueue';
import { registerChatParticipant } from './participant/chatParticipant';
import { DashboardPanel } from './ui/dashboardPanel';
import { detectWorkspaceSignals, inferSkill } from './services/workspaceDetector';
import {
  DEFAULT_GITHUB_STRUCTURE,
  scaffoldGithubFolder,
  parseFolderStructureJson,
  formatScaffoldSummary,
} from './services/githubFolderScaffolder';

let queue: OfflineQueue;

export function activate(context: vscode.ExtensionContext) {
  console.log('Central Copilot Learning Hub — activated');

  const config = vscode.workspace.getConfiguration('copilotLearningHub');
  const apiUrl  = config.get<string>('apiUrl')  ?? 'http://localhost:3000/api/v1';
  const apiKey  = config.get<string>('apiKey')  ?? '';
  const userId  = config.get<string>('userId')  ?? 'anonymous';

  const client = new LearningHubClient(apiUrl, apiKey);
  queue  = new OfflineQueue(context, client);

  // ── Chat Participant ────────────────────────────────────────────────────────
  registerChatParticipant(context, client, queue);

  // ── Commands ────────────────────────────────────────────────────────────────

  // Save Learning (command palette / keybinding)
  context.subscriptions.push(
    vscode.commands.registerCommand('copilotLearningHub.saveLearning', async () => {
      const title = await vscode.window.showInputBox({ prompt: 'Learning title', placeHolder: 'e.g. Angular lazy loading fix' });
      if (!title) return;

      const summary = await vscode.window.showInputBox({ prompt: 'One-line summary', placeHolder: 'e.g. Use arrow function in loadChildren' });
      if (!summary) return;

      const editor = vscode.window.activeTextEditor;
      const solutionText = editor?.document.getText(editor.selection) ||
        await vscode.window.showInputBox({ prompt: 'Paste your solution / learning', placeHolder: 'Code snippet or explanation' }) ?? '';

      if (!solutionText) return;

      const signals = await detectWorkspaceSignals();
      const skill   = inferSkill(signals);
      const tenantId = config.get<string>('tenantId') ?? undefined;

      const saveReq = {
        title, summary, solutionText,
        tags: [skill],
        skill, personaHints: [skill],
        authorId: userId,
        tenantId,
        repoScope: signals.repoName,
      };

      try {
        const online = await client.healthCheck();
        if (!online && config.get<boolean>('offlineMode')) {
          await queue.enqueue(saveReq);
          vscode.window.showInformationMessage('📦 Learning queued offline.');
          return;
        }

        const res = await client.saveLearning(saveReq);

        if (res.outcome === 'SECRET_REJECTED') {
          vscode.window.showErrorMessage(`🔐 Secrets detected: ${res.secretFields?.join(', ')}. Please redact and retry.`);
        } else if (res.outcome === 'DUPLICATE') {
          vscode.window.showWarningMessage('♻️ Duplicate learning detected. Please vote on the existing one.');
        } else {
          vscode.window.showInformationMessage(`✅ Learning saved! (${res.outcome}) ID: ${res.solutionId}`);
        }
      } catch (err: any) {
        vscode.window.showErrorMessage(`❌ Save failed: ${err.message}`);
      }
    })
  );

  // Search Learnings
  context.subscriptions.push(
    vscode.commands.registerCommand('copilotLearningHub.searchLearnings', async () => {
      const query = await vscode.window.showInputBox({ prompt: 'Search learning hub', placeHolder: 'e.g. spring boot datasource config' });
      if (!query) return;

      const signals  = await detectWorkspaceSignals();
      const skill    = inferSkill(signals);
      const tenantId = config.get<string>('tenantId') ?? undefined;

      try {
        const { results, count } = await client.search({ query, skill, persona: skill, tenantId });

        if (count === 0) {
          vscode.window.showInformationMessage(`No results for "${query}". Contribute one with /save!`);
          return;
        }

        // Quick-pick result selection
        const items = results.flatMap(r =>
          r.solutions.map(s => ({
            label: `${s.title}`,
            description: `${s.badge} | ⭐ ${s.communityScore.toFixed(1)}`,
            detail: s.summary,
            solutionId: s.id,
            solutionText: s.solutionText,
          }))
        );

        const pick = await vscode.window.showQuickPick(items, { matchOnDescription: true, matchOnDetail: true });
        if (!pick) return;

        // Show solution in untitled doc
        const doc = await vscode.workspace.openTextDocument({
          content: `// Learning Hub — ${pick.label}\n// ${pick.detail}\n\n${pick.solutionText}`,
          language: skill === 'java' ? 'java' : skill === 'python' ? 'python' : 'typescript',
        });
        await vscode.window.showTextDocument(doc);
      } catch (err: any) {
        vscode.window.showErrorMessage(`❌ Search failed: ${err.message}`);
      }
    })
  );

  // Show Dashboard
  context.subscriptions.push(
    vscode.commands.registerCommand('copilotLearningHub.showDashboard', () => {
      DashboardPanel.show(context, client);
    })
  );

  // Manual offline sync
  context.subscriptions.push(
    vscode.commands.registerCommand('copilotLearningHub.syncOfflineQueue', async () => {
      vscode.window.withProgress(
        { location: vscode.ProgressLocation.Notification, title: 'Syncing offline queue...' },
        async () => {
          const { synced, failed } = await queue.sync();
          vscode.window.showInformationMessage(`Sync complete — ✅ ${synced} synced, ❌ ${failed} failed.`);
        }
      );
    })
  );

  // Scaffold .github folder
  context.subscriptions.push(
    vscode.commands.registerCommand('copilotLearningHub.scaffoldGithubFolder', async () => {
      const workspaceFolders = vscode.workspace.workspaceFolders;
      if (!workspaceFolders?.length) {
        vscode.window.showErrorMessage('❌ No workspace folder open. Please open a project first.');
        return;
      }

      // Let the user choose: use the built-in default template, or paste custom JSON
      const choice = await vscode.window.showQuickPick(
        [
          { label: '$(repo) Use default template', description: 'Scaffold the built-in .github structure', value: 'default' },
          { label: '$(json) Paste custom JSON',    description: 'Supply your own { "path": "content" } map', value: 'custom' },
        ],
        { title: 'Scaffold .github Folder', placeHolder: 'Choose a structure source' }
      );
      if (!choice) return;

      let structure = DEFAULT_GITHUB_STRUCTURE;

      if (choice.value === 'custom') {
        const raw = await vscode.window.showInputBox({
          prompt: 'Paste JSON folder structure',
          placeHolder: '{ "copilot-instructions.md": "# My instructions", "workflows/ci.yml": "name: CI\\n..." }',
          validateInput: v => {
            try { JSON.parse(v); return null; } catch { return 'Must be valid JSON'; }
          },
        });
        if (!raw) return;
        const parsed = parseFolderStructureJson(raw);
        if (!parsed) return;
        structure = parsed;
      }

      // Ask about overwrite
      const overwritePick = await vscode.window.showQuickPick(
        [
          { label: 'Skip existing files', value: false },
          { label: 'Overwrite existing files', value: true },
        ],
        { title: 'Overwrite policy' }
      );
      if (!overwritePick) return;

      const workspaceRoot = workspaceFolders[0].uri;
      const result = await scaffoldGithubFolder(workspaceRoot, structure, overwritePick.value as boolean);
      const summary = formatScaffoldSummary(result);

      if (result.errors.length) {
        const detail = result.errors.map(e => `${e.file}: ${e.reason}`).join('\n');
        vscode.window.showWarningMessage(`⚠️ Scaffold complete with errors — ${summary}`, 'Show errors').then(v => {
          if (v) vscode.window.showInformationMessage(detail);
        });
      } else {
        vscode.window.showInformationMessage(`📁 .github scaffold complete — ${summary}`);
      }

      // Reveal .github in the explorer
      if (result.created.length) {
        await vscode.commands.executeCommand('revealInExplorer',
          vscode.Uri.joinPath(workspaceRoot, '.github'));
      }
    })
  );

  // ── Auto-sync offline queue ─────────────────────────────────────────────────
  if (config.get<boolean>('offlineMode')) {
    queue.startAutoSync();
  }

  // ── Config change listener ──────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration('copilotLearningHub.offlineMode')) {
        const enabled = vscode.workspace.getConfiguration('copilotLearningHub').get<boolean>('offlineMode');
        enabled ? queue.startAutoSync() : queue.stopAutoSync();
      }
    })
  );

  vscode.window.showInformationMessage('📚 Central Copilot Learning Hub is ready!');
}

export function deactivate() {
  queue?.stopAutoSync();
}
