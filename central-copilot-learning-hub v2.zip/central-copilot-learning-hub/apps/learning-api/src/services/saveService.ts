// ─── Save Service ─────────────────────────────────────────────────────────────
import { randomUUID } from 'crypto';
import type {
  SaveRequest, SaveResponse, Solution, Cluster, IndexEntry
} from '../../../../shared/types.js';
import { scanForSecrets } from './secretScanner.js';
import { findCluster, isDuplicate } from './clusterEngine.js';
import { computeBadge, computeCommunityScore, computeStatus } from './badgeEngine.js';
import { defaultStorage } from '../storage/storageFactory.js';

export async function saveLearning(
  req: SaveRequest,
  storage = defaultStorage
): Promise<SaveResponse> {

  // 1. Secret scan
  const scan = scanForSecrets(req.solutionText);
  if (!scan.clean) {
    return {
      outcome: 'SECRET_REJECTED',
      secretFields: scan.findings.map(f => f.name),
      message: `Learning rejected: contains ${scan.findings.map(f => f.name).join(', ')}. Please redact before saving.`,
    };
  }

  // 2. Load existing data
  const existingClusters = await storage.listClusters(req.skill);
  const clusterDescriptions = new Map(
    existingClusters.map(c => [c.id, c.description])
  );

  // 3. Dedup check — load solutions in same-skill clusters
  const existingSolutions: Array<{ title: string; summary: string; tags: string[] }> = [];
  for (const cluster of existingClusters) {
    for (const solId of cluster.solutionIds) {
      const sol = await storage.getSolution(solId);
      if (sol) existingSolutions.push(sol);
    }
  }

  if (isDuplicate(req, existingSolutions)) {
    return {
      outcome: 'DUPLICATE',
      message: 'A very similar learning already exists. Vote on the existing one instead.',
    };
  }

  // 4. Cluster matching
  const clusterMatch = findCluster(req, existingClusters, clusterDescriptions);

  const now = new Date().toISOString();
  const solutionId = randomUUID();

  let cluster: Cluster;

  if (clusterMatch.matched && clusterMatch.cluster) {
    // Add to existing cluster
    cluster = clusterMatch.cluster;
    cluster.solutionIds.push(solutionId);
    cluster.updatedAt = now;
    await storage.saveCluster(cluster);
  } else {
    // Create new cluster
    const clusterId = randomUUID();
    cluster = {
      id: clusterId,
      description: `${req.title} — ${req.summary}`,
      skill: req.skill,
      solutionIds: [solutionId],
      tenantId: req.tenantId,
      createdAt: now,
      updatedAt: now,
    };
    await storage.saveCluster(cluster);
  }

  // 5. Persist solution
  const solution: Solution = {
    id: solutionId,
    clusterId: cluster.id,
    title: req.title,
    summary: req.summary,
    solutionText: req.solutionText,
    tags: req.tags,
    skill: req.skill,
    personaHints: req.personaHints,
    authorId: req.authorId,
    tenantId: req.tenantId,
    repoScope: req.repoScope,
    upvotes: 0,
    downvotes: 0,
    communityScore: 0,
    status: 'ACTIVE',
    retrievalCount: 0,
    version: 1,
    history: [],
    createdAt: now,
    updatedAt: now,
  };
  await storage.saveSolution(solution);

  // 6. Update skill index
  const indexEntry: IndexEntry = {
    id: solutionId,
    clusterId: cluster.id,
    title: req.title,
    summary: req.summary,
    tags: req.tags,
    communityScore: 0,
    upvotes: 0,
    downvotes: 0,
    status: 'ACTIVE',
    retrievalCount: 0,
    personaHints: req.personaHints,
    skill: req.skill,
    authorId: req.authorId,
    tenantId: req.tenantId,
    repoScope: req.repoScope,
    createdAt: now,
    updatedAt: now,
  };

  const existingIndex = await storage.getSkillIndex(req.skill);
  const updatedIndex = existingIndex ?? {
    skill: req.skill,
    updatedAt: now,
    version: 0,
    learnings: [],
  };
  updatedIndex.learnings.push(indexEntry);
  updatedIndex.updatedAt = now;
  await storage.saveSkillIndex(updatedIndex);

  return {
    outcome: clusterMatch.matched ? 'ADD_SOLUTION' : 'NEW_CLUSTER',
    solutionId,
    clusterId: cluster.id,
    message: clusterMatch.matched
      ? `Added to existing cluster "${cluster.description}"`
      : `Created new cluster for "${req.title}"`,
  };
}
