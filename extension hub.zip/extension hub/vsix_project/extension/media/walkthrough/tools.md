## Agents Read and Write Your Code

Agents with the right tools can automatically:
- **Read** your project files and directory structure
- **Create** new files in your workspace
- **Edit** existing code
- **Run** terminal commands and read their output
- **Check** VS Code diagnostics (errors, type issues)

Just ask naturally — agents pick the right tools for the task.
