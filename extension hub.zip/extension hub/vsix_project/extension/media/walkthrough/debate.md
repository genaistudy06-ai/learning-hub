## Structured Debate for Hard Decisions

Use `/debate` when you need a rigorous analysis of a complex architectural choice:

```
@sdlc-agents.enterprise-architect /debate Event sourcing vs CRUD for our order service?
@sdlc-agents.solution-architect /debate Should we use a monorepo or separate repos for our microservices?
@sdlc-agents.db-engineer /debate PostgreSQL vs MongoDB for our document-heavy workload?
```

Debate mode runs 3 LM calls (Advocate → Challenger → Arbitrator) and shows the token cost before proceeding.
