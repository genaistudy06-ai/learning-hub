// ─── Shared Types — All Phases ────────────────────────────────────────────────

export type Skill = 'angular' | 'java' | 'python' | 'devops' | 'sql' | 'qa' | 'general';
export type LearningStatus = 'ACTIVE' | 'SUPPRESSED' | 'DEPRECATED' | 'HIGH_CONFIDENCE';
export type VoteAction = 'UPVOTE' | 'DOWNVOTE' | 'OUTDATED' | 'DUPLICATE';
export type SaveOutcome = 'NEW_CLUSTER' | 'ADD_SOLUTION' | 'DUPLICATE' | 'SECRET_REJECTED';
export type StorageProvider = 'github' | 's3' | 'azure' | 'r2' | 'postgres';
export type Badge = 'New' | 'Highly Trusted' | 'Trusted' | 'Mixed Reviews' | 'Low Confidence';

// ─── Phase 3: Multi-tenant ────────────────────────────────────────────────────
export interface Tenant {
  id: string;
  orgName: string;
  storageProvider: StorageProvider;
  storageConfig: Record<string, string>;
  plan: 'team' | 'enterprise';
  createdAt: string;
}

// ─── Index & Storage ──────────────────────────────────────────────────────────
export interface IndexEntry {
  id: string;
  clusterId: string;
  title: string;
  summary: string;
  tags: string[];
  communityScore: number;
  upvotes: number;
  downvotes: number;
  status: LearningStatus;
  retrievalCount: number;
  personaHints: Skill[];
  skill: Skill;
  authorId: string;
  tenantId?: string;
  repoScope?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SkillIndex {
  skill: Skill;
  updatedAt: string;
  version: number;
  etag?: string;
  compressed?: boolean;
  learnings: IndexEntry[];
}

export interface Solution {
  id: string;
  clusterId: string;
  title: string;
  summary: string;
  solutionText: string;
  tags: string[];
  skill: Skill;
  personaHints: Skill[];
  authorId: string;
  tenantId?: string;
  repoScope?: string;
  upvotes: number;
  downvotes: number;
  communityScore: number;
  status: LearningStatus;
  retrievalCount: number;
  version: number;
  history?: SolutionVersion[];
  createdAt: string;
  updatedAt: string;
}

export interface SolutionVersion {
  version: number;
  solutionText: string;
  authorId: string;
  changedAt: string;
  changeSummary?: string;
}

export interface Cluster {
  id: string;
  description: string;
  skill: Skill;
  solutionIds: string[];
  tenantId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface VoteRecord {
  solutionId: string;
  votes: Array<{
    userId: string;
    action: VoteAction;
    weight: number;
    timestamp: string;
  }>;
}

export interface SaveRequest {
  title: string;
  summary: string;
  solutionText: string;
  tags: string[];
  skill: Skill;
  personaHints: Skill[];
  authorId: string;
  tenantId?: string;
  repoScope?: string;
}

export interface SaveResponse {
  outcome: SaveOutcome;
  solutionId?: string;
  clusterId?: string;
  existingId?: string;
  secretFields?: string[];
  message: string;
}

export interface SearchRequest {
  query: string;
  skill: Skill;
  persona: Skill;
  limit?: number;
  tenantId?: string;
  repoScope?: string;
}

export interface SearchResult {
  cluster: Cluster;
  solutions: Array<Solution & { badge: Badge; matchScore: number }>;
  topMatchScore: number;
}

export interface WorkspaceSignals {
  activeFileExtension?: string;
  filesPresent: string[];
  promptKeywords: string[];
  instructionFileName?: string;
  repoName?: string;
}

export interface AnalyticsSnapshot {
  skill: Skill;
  totalLearnings: number;
  activeCount: number;
  suppressedCount: number;
  deprecatedCount: number;
  highConfidenceCount: number;
  topRetrieved: IndexEntry[];
  topVoted: IndexEntry[];
  coverageBySkill: Record<string, number>;
  generatedAt: string;
}

export interface PRSuggestion {
  prNumber: number;
  repo: string;
  relatedLearnings: IndexEntry[];
  suggestedAt: string;
}

export interface OfflineQueueItem {
  id: string;
  learning: SaveRequest;
  status: 'PENDING' | 'SYNCING' | 'FAILED';
  retryCount: number;
  createdAt: string;
  lastAttemptAt?: string;
}
